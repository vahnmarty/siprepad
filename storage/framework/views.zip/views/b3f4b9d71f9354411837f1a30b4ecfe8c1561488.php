<div class="header">
    <a href="<?php echo e(url('/')); ?>" class="hdr-logo">
        <img src="<?php echo e(asset('frontend_assets/images/lg2.png')); ?>" alt="" />
    </a>
    <div class="dropdown admin">
        <button class="btn dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown"
            aria-expanded="false">
            <span class="profile-icon">
                
                    <img src="https://ui-avatars.com/api/?name=<?php echo e(Auth::guard('customer')->user()->Pro_First_Name); ?>&rounded=true&color=192960&background=random" alt="" />
                
            </span>
           
            <em><?php echo e(Auth::guard('customer')->user()->Pro_First_Name); ?></em>
        </button>
        <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
            <li>
                <a class="dropdown-item" href="<?php echo e(route('edit-profile')); ?>">
                    <span>
                        <img src="<?php echo e(asset('frontend_assets/images/p1.svg')); ?>" alt="" />
                    </span>Edit Personal Info
                </a>
            </li>
            <li>
                <a class="dropdown-item" href="<?php echo e(route('change-password')); ?>">
                    <span>
                        <img src="<?php echo e(asset('frontend_assets/images/p2.png')); ?>" alt="" />
                    </span>Change Password
                </a>
            </li>

            <li>
                <a class="dropdown-item" href="<?php echo e(route('user.logout')); ?>">
                    <span>
                        <img src="<?php echo e(asset('frontend_assets/images/p3.png')); ?>" alt="" />
                    </span>Logout
                </a>
            </li>
        </ul>
    </div>
</div>
<?php /**PATH /var/www/html/admission-portal-web-1854/resources/views/layouts/header.blade.php ENDPATH**/ ?>