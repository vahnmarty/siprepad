
<div class="notification_action"> 
 <?php if($notification == '1'): ?> 
  <a href="<?php echo e(url('/admin/user/notify/')); ?>/<?php echo e(App\Models\Profile::NOTIFICATION_ON); ?>/<?php echo e($notification); ?>"style="color: white; background: linear-gradient(180deg, #19a74d 0%, #002664 100%) !important;"class="btn btn-on mb-3">Notification On</a> 
 <?php else: ?> 
 <a href="<?php echo e(url('/admin/user/notify/')); ?>/<?php echo e(App\Models\Profile::NOTIFICATION_OFF); ?>/<?php echo e($notification); ?>" style="color:white" class="btn btn-off mb-3">Notification Off</a> 
 <?php endif; ?> 
 <?php if($registeration == '1'): ?> 
  <a href="<?php echo e(url('admin/user/registerable')); ?>/<?php echo e(App\Models\Profile::Registeration_OFF); ?>/<?php echo e($registeration); ?>"style="color: white; background: linear-gradient(180deg, #19a74d 0%, #002664 100%) !important;"class="btn btn-on mb-3">Registeration On</a> 
 <?php else: ?> 
 <a href="<?php echo e(url('admin/user/registerable')); ?>/<?php echo e(App\Models\Profile::Registeration_ON); ?>/<?php echo e($registeration); ?>" style="color:white" class="btn btn-off mb-3">Registeration Off</a> 
 <?php endif; ?> 
<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.admin.table','data' => []]); ?>
<?php $component->withName('admin.table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('search', null, []); ?> 
     <?php $__env->endSlot(); ?>
    
     <?php $__env->slot('perPage', null, []); ?> 
        <label>Show
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.admin.dropdown','data' => ['wire:model' => 'perPage','class' => 'custom-select custom-select-sm form-control form-control-sm']]); ?>
<?php $component->withName('admin.dropdown'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:model' => 'perPage','class' => 'custom-select custom-select-sm form-control form-control-sm']); ?>
                <?php $__currentLoopData = $perPageList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.admin.dropdown-item','data' => ['value' => $page['value'],'text' => $page['text']]]); ?>
<?php $component->withName('admin.dropdown-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($page['value']),'text' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($page['text'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?> entries
        </label>
     <?php $__env->endSlot(); ?>
     <?php $__env->slot('thead', null, []); ?> 
        <tr role="row">
            <th tabindex="0" aria-controls="kt_table_1" rowspan="1" colspan="1" style="width: 15%;"
                aria-sort="ascending" aria-label="Agent: activate to sort column descending">Student First Name<i
                    class="fa fa-fw fa-sort pull-right" style="cursor: pointer;"
                    wire:click="sortByName('first_name')"></i>
            </th>

            <th tabindex="0" aria-controls="kt_table_1" rowspan="1" colspan="1" style="width: 15%;"
                aria-label="Company Email: activate to sort column ascending">Student Last Name<i
                    class="fa fa-fw fa-sort pull-right" style="cursor: pointer;"
                    wire:click="sortByName('last_name')"></i></th>


            <th tabindex="0" aria-controls="kt_table_1" rowspan="1" colspan="1" style="width: 20%;"
                aria-label="Company Agent: activate to sort column ascending">Student Email
            </th>

            <th tabindex="0" aria-controls="kt_table_1" rowspan="1" colspan="1" style="width: 20%;"
                aria-label="Company Agent: activate to sort column ascending">Student Phone
            </th>
              <th tabindex="0" aria-controls="kt_table_1" style="width: 10%;"
                aria-label="Company Agent: activate to sort column ascending">Status
            </th>
            <th tabindex="0" aria-controls="kt_table_1" style="width: 10%;"
                aria-label="Company Agent: activate to sort column ascending">Decision
            </th>

            <th class="align-center" rowspan="1" colspan="1" style="width: 30%;" aria-label="Actions">Actions</th>
        </tr>

        <tr class="filter">
            <th>
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.admin.input','data' => ['type' => 'search','wire:model.defer' => 'searchFirstName','placeholder' => '','autocomplete' => 'off','class' => 'form-control-sm form-filter']]); ?>
<?php $component->withName('admin.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['type' => 'search','wire:model.defer' => 'searchFirstName','placeholder' => '','autocomplete' => 'off','class' => 'form-control-sm form-filter']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            </th>
            <th>
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.admin.input','data' => ['type' => 'search','wire:model.defer' => 'searchLastName','placeholder' => '','autocomplete' => 'off','class' => 'form-control-sm form-filter']]); ?>
<?php $component->withName('admin.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['type' => 'search','wire:model.defer' => 'searchLastName','placeholder' => '','autocomplete' => 'off','class' => 'form-control-sm form-filter']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            </th>
            <th>
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.admin.input','data' => ['type' => 'search','wire:model.defer' => 'searchEmail','placeholder' => '','autocomplete' => 'off','class' => 'form-control-sm form-filter']]); ?>
<?php $component->withName('admin.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['type' => 'search','wire:model.defer' => 'searchEmail','placeholder' => '','autocomplete' => 'off','class' => 'form-control-sm form-filter']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            </th>
            <th>
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.admin.input','data' => ['type' => 'search','wire:model.defer' => 'searchPhone ','placeholder' => '','autocomplete' => 'off','class' => 'form-control-sm form-filter']]); ?>
<?php $component->withName('admin.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['type' => 'search','wire:model.defer' => 'searchPhone ','placeholder' => '','autocomplete' => 'off','class' => 'form-control-sm form-filter']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            </th>
            <th></th>
            <th></th>
            <th>
              
                <div class="row">
                    <div class="col-5">
                           <button class="btn btn-brand kt-btn btn-sm kt-btn--icon" wire:click="search">
                          Search
                        </button>
                    </div>
                    <div class="col-4">
                        <button class="btn btn-secondary kt-btn btn-sm kt-btn--icon" wire:click="resetSearch">Reset</button>
                    </div>
                </div>
            </th>
        </tr>
     <?php $__env->endSlot(); ?>

             
    <?php
        $lastId = null;
        $rowClass = 'grey';
    ?>
     <?php $__env->slot('tbody', null, []); ?> 
        <?php $__empty_1 = true; $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php
                //if userid changed from last iteration, store new userid and change color
                if ($lastId !== $student['Application_ID']) {
                    $lastId = $student['Application_ID'];
                    if ($rowClass == 'grey') {
                        $rowClass = 'white';
                    } else {
                        $rowClass = 'grey';
                    }
                }
            ?>
   <?php
                    $getApplication = App\Models\Application::where('Application_ID', $student['Application_ID'])
                    ->get()->first();
                    
                    $getStudent = App\Models\StudentInformation::where('Application_ID', $getApplication->Application_ID)
                    ->where('Profile_ID', $getApplication->Profile_ID)->first();
                    
                    $getApplicationStatus = App\Models\StudentApplicationStatus::where('application_id', $getApplication->Application_ID)
                    ->where('profile_id', $getApplication->Profile_ID)->first();
                    
                   
                ?>
                
                
                
            <tr role="row" class="odd <?php echo e($rowClass); ?>">
                <td><?php echo e(ucfirst($student['First_Name']) ?? '---'); ?></td>
                <td><?php echo e(ucfirst($student['Last_Name']) ?? '---'); ?></td>
                <td><?php echo e($student['Personal_Email'] ?? '---'); ?></td>
                <td><?php echo e($student['Mobile_Phone'] ?? '---'); ?></td>
                <td>
                    <input type='hidden' class='profile_id' name='profile_id' value="<?php echo e($getApplication->Profile_ID); ?>">
              		<input type='hidden' class='app_id'  name='app_id' value='<?php echo e($getApplication->Application_ID); ?>'>
					<input type='hidden' class='first_name'  name='first_name' value="<?php echo e($student['First_Name']); ?>">
					<input type='hidden' class='last_name' name='first_name' value="<?php echo e($student['Last_Name']); ?>">
					<input type='hidden' class='dob' name='dob' value="<?php echo e($student['Birthday']); ?>">
					<input type='hidden' class='email' name='email' value="<?php echo e($student['Personal_Email']); ?>">
					   
					<?php if($getApplicationStatus): ?>
						<?php if($getStudent->S1_Personal_Email == $student['Personal_Email'] &&  $getStudent->S1_First_Name == $student['First_Name']
						&& $getStudent->S1_Last_Name == $student['Last_Name'] && $getStudent->S1_Birthdate == $student['Birthday']): ?>
							<?php $studentProfile = 'student_one'; ?>
						<?php elseif($getStudent->S2_Personal_Email == $student['Personal_Email'] &&  $getStudent->S2_First_Name == $student['First_Name']
						&& $getStudent->S2_Last_Name == $student['Last_Name'] && $getStudent->S2_Birthdate == $student['Birthday']): ?>
							<?php $studentProfile = 'student_two'; ?>
						<?php elseif($getStudent->S3_Personal_Email == $student['Personal_Email'] &&  $getStudent->S3_First_Name == $student['First_Name']
						&& $getStudent->S3_Last_Name == $student['Last_Name'] && $getStudent->S3_Birthdate == $student['Birthday']): ?>
							<?php $studentProfile = 'student_three'; ?>
						<?php endif; ?>
						<?php if($studentProfile == 'student_one'): ?>
							<?php switch($getApplicationStatus->s1_application_status):
                                case (1): ?>
                                <select name='candidate-status' required class='state_select-box'>
                                    <option value='' disabled>Select</option>
                                    <option value='<?php echo e(App\Models\Application::TYPE_ACCEPTED); ?>' selected>Accepted</option>
                                    <option value='<?php echo e(App\Models\Application::TYPE_WAIT_LISTED); ?>'>Wait Listed</option>
                                    <option value='<?php echo e(App\Models\Application::TYPE_NOT_ACCEPTED); ?>'>Not Accepted</option>
                                </select>
                                <?php break; ?>
                                <?php case (2): ?>
                                <select name='candidate-status' required class='state_select-box'>
                                    <option value=''disabled>Select</option>
                                    <option value='<?php echo e(App\Models\Application::TYPE_ACCEPTED); ?>'>Accepted</option>
                                    <option value='<?php echo e(App\Models\Application::TYPE_WAIT_LISTED); ?>' selected>Wait Listed</option>
                                    <option value='<?php echo e(App\Models\Application::TYPE_NOT_ACCEPTED); ?>'>Not Accepted</option>
                                </select>
                                <?php break; ?>
                                <?php case (3): ?>
                                <select name='candidate-status' required class='state_select-box'>
                                    <option value=''disabled>Select</option>
                                    <option value='<?php echo e(App\Models\Application::TYPE_ACCEPTED); ?>'>Accepted</option>
                                    <option value='<?php echo e(App\Models\Application::TYPE_WAIT_LISTED); ?>'>Wait Listed</option>
                                    <option value='<?php echo e(App\Models\Application::TYPE_NOT_ACCEPTED); ?>' selected>Not Accepted</option>
            					<?php break; ?> 
            					<?php default: ?>
        						<select name='candidate-status' required class='state_select-box'>
                                    <option value='' selected disabled>Select</option>
                                    <option value='<?php echo e(App\Models\Application::TYPE_ACCEPTED); ?>'>Accepted</option>
                                    <option value='<?php echo e(App\Models\Application::TYPE_WAIT_LISTED); ?>'>Wait Listed</option>
                                    <option value='<?php echo e(App\Models\Application::TYPE_NOT_ACCEPTED); ?>'>Not Accepted</option>
                                </select>
                            <?php endswitch; ?>
						<?php endif; ?> 
						<?php if($studentProfile == 'student_two'): ?>
							<?php switch($getApplicationStatus->s2_application_status):
                                case (1): ?>
                                <select name='candidate-status' required class='state_select-box'>
                                    <option value='' disabled>Select</option>
                                    <option value='<?php echo e(App\Models\Application::TYPE_ACCEPTED); ?>' selected>Accepted</option>
                                    <option value='<?php echo e(App\Models\Application::TYPE_WAIT_LISTED); ?>'>Wait Listed</option>
                                    <option value='<?php echo e(App\Models\Application::TYPE_NOT_ACCEPTED); ?>'>Not Accepted</option>
                                </select>
                                <?php break; ?>
                                <?php case (2): ?>
                                <select name='candidate-status' required class='state_select-box'>
                                    <option value=''disabled>Select</option>
                                    <option value='<?php echo e(App\Models\Application::TYPE_ACCEPTED); ?>'>Accepted</option>
                                    <option value='<?php echo e(App\Models\Application::TYPE_WAIT_LISTED); ?>' selected>Wait Listed</option>
                                    <option value='<?php echo e(App\Models\Application::TYPE_NOT_ACCEPTED); ?>'>Not Accepted</option>
                                </select>
                                <?php break; ?>
                                <?php case (3): ?>
                                <select name='candidate-status' required class='state_select-box'>
                                    <option value=''disabled>Select</option>
                                    <option value='<?php echo e(App\Models\Application::TYPE_ACCEPTED); ?>'>Accepted</option>
                                    <option value='<?php echo e(App\Models\Application::TYPE_WAIT_LISTED); ?>'>Wait Listed</option>
                                    <option value='<?php echo e(App\Models\Application::TYPE_NOT_ACCEPTED); ?>' selected>Not Accepted</option>
            					<?php break; ?> 
            					<?php default: ?>
        						<select name='candidate-status' required class='state_select-box'>
                                    <option value='' selected disabled>Select</option>
                                    <option value='<?php echo e(App\Models\Application::TYPE_ACCEPTED); ?>'>Accepted</option>
                                    <option value='<?php echo e(App\Models\Application::TYPE_WAIT_LISTED); ?>'>Wait Listed</option>
                                    <option value='<?php echo e(App\Models\Application::TYPE_NOT_ACCEPTED); ?>'>Not Accepted</option>
                                </select>
                            <?php endswitch; ?>
						<?php endif; ?> 
						<?php if($studentProfile == 'student_three'): ?>
							<?php switch($getApplicationStatus->s3_application_status):
                                case (1): ?>
                                <select name='candidate-status' required class='state_select-box'>
                                    <option value='' disabled>Select</option>
                                    <option value='<?php echo e(App\Models\Application::TYPE_ACCEPTED); ?>' selected>Accepted</option>
                                    <option value='<?php echo e(App\Models\Application::TYPE_WAIT_LISTED); ?>'>Wait Listed</option>
                                    <option value='<?php echo e(App\Models\Application::TYPE_NOT_ACCEPTED); ?>'>Not Accepted</option>
                                </select>
                                <?php break; ?>
                                <?php case (2): ?>
                                <select name='candidate-status' required class='state_select-box'>
                                    <option value=''disabled>Select</option>
                                    <option value='<?php echo e(App\Models\Application::TYPE_ACCEPTED); ?>'>Accepted</option>
                                    <option value='<?php echo e(App\Models\Application::TYPE_WAIT_LISTED); ?>' selected>Wait Listed</option>
                                    <option value='<?php echo e(App\Models\Application::TYPE_NOT_ACCEPTED); ?>'>Not Accepted</option>
                                </select>
                                <?php break; ?>
                                <?php case (3): ?>
                                <select name='candidate-status' required class='state_select-box'>
                                    <option value=''disabled>Select</option>
                                    <option value='<?php echo e(App\Models\Application::TYPE_ACCEPTED); ?>'>Accepted</option>
                                    <option value='<?php echo e(App\Models\Application::TYPE_WAIT_LISTED); ?>'>Wait Listed</option>
                                    <option value='<?php echo e(App\Models\Application::TYPE_NOT_ACCEPTED); ?>' selected>Not Accepted</option>
            					<?php break; ?> 
            					<?php default: ?>
        						<select name='candidate-status' required class='state_select-box'>
                                    <option value='' selected disabled>Select</option>
                                    <option value='<?php echo e(App\Models\Application::TYPE_ACCEPTED); ?>'>Accepted</option>
                                    <option value='<?php echo e(App\Models\Application::TYPE_WAIT_LISTED); ?>'>Wait Listed</option>
                                    <option value='<?php echo e(App\Models\Application::TYPE_NOT_ACCEPTED); ?>'>Not Accepted</option>
                                </select>
                            <?php endswitch; ?>
						<?php endif; ?> 
					<?php else: ?>
					<select name='candidate-status' required class='state_select-box'>
                        <option value='' selected >Select</option>
                        <option value='<?php echo e(App\Models\Application::TYPE_ACCEPTED); ?>'>Accepted</option>
                        <option value='<?php echo e(App\Models\Application::TYPE_WAIT_LISTED); ?>'>Wait Listed</option>
                        <option value='<?php echo e(App\Models\Application::TYPE_NOT_ACCEPTED); ?>'>Not Accepted</option>
                    </select>
				<?php endif; ?>
                 </td>
                 <td>
                <?php if($getApplicationStatus): ?>
						<?php if($getStudent->S1_Personal_Email == $student['Personal_Email'] &&  $getStudent->S1_First_Name == $student['First_Name']
						&& $getStudent->S1_Last_Name == $student['Last_Name'] && $getStudent->S1_Birthdate == $student['Birthday']): ?>
							<?php $studentProfile = 'student_one'; ?>
						<?php elseif($getStudent->S2_Personal_Email == $student['Personal_Email'] &&  $getStudent->S2_First_Name == $student['First_Name']
						&& $getStudent->S2_Last_Name == $student['Last_Name'] && $getStudent->S2_Birthdate == $student['Birthday']): ?>
							<?php $studentProfile = 'student_two'; ?>
						<?php elseif($getStudent->S3_Personal_Email == $student['Personal_Email'] &&  $getStudent->S3_First_Name == $student['First_Name']
						&& $getStudent->S3_Last_Name == $student['Last_Name'] && $getStudent->S3_Birthdate == $student['Birthday']): ?>
							<?php $studentProfile = 'student_three'; ?>
						<?php endif; ?>
						
                <?php if($studentProfile == 'student_one'): ?>
				<?php switch($getApplicationStatus->s1_candidate_status):
				case (0): ?>
                        <?php echo e("No Response"); ?>

                        <?php break; ?>
                          <?php case (1): ?>
                          <?php echo e("Accepted"); ?>

                           <?php break; ?>
                        <?php case (2): ?>
                        <?php echo e("Rejected"); ?>

                         <?php break; ?>
                        <?php case (3): ?>
                        <?php echo e("Notification Read"); ?>

                          <?php endswitch; ?>
                           <?php endif; ?>
                           
				<?php if($studentProfile == 'student_two'): ?>
							<?php switch($getApplicationStatus->s2_candidate_status):
							case (0): ?>
                        <?php echo e("No Response"); ?>

                        <?php break; ?>
                          <?php case (1): ?>

                          <?php echo e("Accepted"); ?>

                           <?php break; ?>
                        <?php case (2): ?>
                        <?php echo e("Rejected"); ?>

                         <?php break; ?>
                        <?php case (3): ?>
                        <?php echo e("Notification Read"); ?>

                        <?php break; ?>
                        <?php default: ?>
                        <?php echo e("Notification not Read"); ?>


                          <?php endswitch; ?>
                           <?php endif; ?>
      
          	              
				<?php if($studentProfile == 'student_three'): ?>
							<?php switch($getApplicationStatus->s3_candidate_status):
							case (0): ?>
                        <?php echo e("No Response"); ?>

                        <?php break; ?>
                          <?php case (1): ?>

                          <?php echo e("Accepted"); ?>

                           <?php break; ?>
                        <?php case (2): ?>
                        <?php echo e("Rejected"); ?>

                         <?php break; ?>
                        <?php case (3): ?>
                        <?php echo e("Notification Read"); ?>

                        <?php break; ?>
                        <?php default: ?>
                        <?php echo e("Notification not Read"); ?>


                          <?php endswitch; ?>
                           <?php endif; ?>
			       	      <?php endif; ?>
                 </td>
              
                <td>
                    <div class="action__btn">
                        <a class="btn"
                            href="<?php echo e(route('application.show', ['application' => $student['Application_ID']])); ?>">
                            <i class="la la-eye"></i>
                            <?php if($student['status'] == 1): ?>
                                View Submitted Application.
                            <?php else: ?>
                                View Incomplete Application.
                            <?php endif; ?>
                        </a>
                    </div>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="6" class="align-center">No records available</td>
            </tr>
        <?php endif; ?>
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('pagination', null, []); ?> 
        <?php echo e($students->links()); ?>

     <?php $__env->endSlot(); ?>

     <?php $__env->slot('showingEntries', null, []); ?> 
        Showing <?php echo e($students->firstitem() ?? 0); ?> to <?php echo e($students->lastitem() ?? 0); ?> of
        <?php echo e($students->total()); ?>

        entries
     <?php $__env->endSlot(); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php /**PATH /var/www/html/admission-portal-web-1854/resources/views/livewire/admin/application/index.blade.php ENDPATH**/ ?>