<div>
    <form wire:submit.prevent="saveOrUpdate">
        <div class="home-wrap hme-wrp2">
            <div class="progress-outr">
                <ul class="progress-ul">
                    <li class="step-complete">
                        <?php if($studentInfo): ?>
                            <a href="<?php echo e(route('admission-application', ['step' => 'one'])); ?>">
                                <span>1</span>
                                <h6>Student Info</h6>
                            </a>
                        <?php else: ?>
                            <a href="javascript::void(0)">
                                <span>1</span>
                                <h6>Student Info</h6>
                            </a>
                        <?php endif; ?>

                    </li>
                    <li class="step-complete">
                        <?php if($studentInfo): ?>
                            <a href="<?php echo e(route('admission-application', ['step' => 'two'])); ?>">
                                <span>2</span>
                                <h6>Address Info</h6>
                            </a>
                        <?php else: ?>
                            <a href="javascript::void(0)">
                                <span>2</span>
                                <h6>Address Info</h6>
                            </a>
                        <?php endif; ?>
                    </li>
                    <li class="step-complete">
                        <?php if($studentInfo): ?>
                            <a href="<?php echo e(route('admission-application', ['step' => 'three'])); ?>">
                                <span>3</span>
                                <h6>Parent Info</h6>
                            </a>
                        <?php else: ?>
                            <a href="javascript::void(0)">
                                <span>3</span>
                                <h6>Parent Info</h6>
                            </a>
                        <?php endif; ?>
                    </li>
                    <li>
                        <?php if($studentInfo): ?>
                            <a href="<?php echo e(route('admission-application', ['step' => 'four'])); ?>">
                                <span>4</span>
                                <h6>Sibling Info</h6>
                            </a>
                        <?php else: ?>
                            <a href="javascript::void(0)">
                                <span>4</span>
                                <h6>Sibling Info</h6>
                            </a>
                        <?php endif; ?>
                    </li>
                    <li>
                        <?php if($studentInfo): ?>
                            <a href="<?php echo e(route('admission-application', ['step' => 'five'])); ?>">
                                <span>5</span>
                                <h6>Legacy Info</h6>
                            </a>
                        <?php else: ?>
                            <a href="javascript::void(0)">
                                <span>5</span>
                                <h6>Legacy Info</h6>
                            </a>
                        <?php endif; ?>
                    </li>
                    <li>
                        <?php if($studentInfo): ?>
                            <a href="<?php echo e(route('admission-application', ['step' => 'six'])); ?>">
                                <span>6</span>
                                <h6>Parent Statement</h6>
                            </a>
                        <?php else: ?>
                            <a href="javascript::void(0)">
                                <span>6</span>
                                <h6>Parent Statement</h6>
                            </a>
                        <?php endif; ?>
                    </li>
                    <li>
                        <?php if($studentInfo): ?>
                            <a href="<?php echo e(route('admission-application', ['step' => 'seven'])); ?>">
                                <span>7</span>
                                <h6>Spiritual & Community Info</h6>
                            </a>
                        <?php else: ?>
                            <a href="javascript::void(0)">
                                <span>7</span>
                                <h6>Spiritual & Community Info</h6>
                            </a>
                        <?php endif; ?>
                    </li>
                    <li>
                        <?php if($studentInfo): ?>
                            <a href="<?php echo e(route('admission-application', ['step' => 'eight'])); ?>">
                                <span>8</span>
                                <h6>Student Statement</h6>
                            </a>
                        <?php else: ?>
                            <a href="javascript::void(0)">
                                <span>8</span>
                                <h6>Student Statement</h6>
                            </a>
                        <?php endif; ?>
                    </li>
                    <li>
                        <?php if($studentInfo): ?>
                            <a href="<?php echo e(route('admission-application', ['step' => 'nine'])); ?>">
                                <span>9</span>
                                <h6>Writing Sample</h6>
                            </a>
                        <?php else: ?>
                            <a href="javascript::void(0)">
                                <span>9</span>
                                <h6>Writing Sample</h6>
                            </a>
                        <?php endif; ?>
                    </li>
                    <li>
                        <?php if($studentInfo): ?>
                            <a href="<?php echo e(route('admission-application', ['step' => 'ten'])); ?>">
                                <span>10</span>
                                <h6>Final Steps</h6>
                            </a>
                        <?php else: ?>
                            <a href="javascript::void(0)">
                                <span>10</span>
                                <h6>Final Steps</h6>
                            </a>
                        <?php endif; ?>
                    </li>
                </ul>
            </div>

            <div class="school-wrap npb application_step__three">
                <div class="form-outr">
                    <div class="cmn-hdr">
                        <h4>Parent Info</h4>
                    </div>
                    <div class="frm-uppr">
                        <div class="direct">
                            <h5>DIRECTIONS:</h5>
                            <p>
                                <strong>This section is to be completed by a parent/guardian.
                                    Please add all parents/guardians associated with the
                                    student(s). Required fields are in <i class="red">red.</i><br><br>
                                Please make sure every required field is completed before saving your work. To save your work, you must click the <i class="red">Next/Save</i> button at the bottom of the page.
                                </strong>
                            </p>
                        </div>
                    </div>

                    <?php $__currentLoopData = $parentInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $parent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-wrap">
                            <div class="form-group">
                                <label>Relationship:</label>
                                <select
                                    class="form-control <?php echo e($errors->has('parentInfo.' . $key . '.Relationship') ? 'is-invalid' : ''); ?>"
                                    wire:model='parentInfo.<?php echo e($key); ?>.Relationship'>
                                    <option value="">-- Please Choose --</option>
                                    <?php $__currentLoopData = $relationshipList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $relationship): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($relationship['relationship_name']); ?>">
                                            <?php echo e($relationship['relationship_name']); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['parentInfo.*.Relationship'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback error_text"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group">
                                <label class="blck">Salutation:</label>
                                <select
                                    class="form-control <?php echo e($errors->has('parentInfo.' . $key . '.Salutation') ? 'is-invalid' : ''); ?>"
                                    wire:model='parentInfo.<?php echo e($key); ?>.Salutation'>
                                    <option value="">-- Please Choose --</option>
                                    <?php $__currentLoopData = $salutationList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $salutation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($salutation['salutation_name']); ?>">
                                            <?php echo e($salutation['salutation_name']); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['parentInfo.*.Salutation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback error_text"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            </div>

                            <div class="form-group">
                                <label>First Name:</label>
                                <input type="text"
                                    class="form-control <?php echo e($errors->has('parentInfo.' . $key . '.First_Name') ? 'is-invalid' : ''); ?>"
                                    wire:model.defer='parentInfo.<?php echo e($key); ?>.First_Name'>
                                <?php $__errorArgs = ['parentInfo.*.First_Name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback error_text"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group">
                                <label class="blck">Middle Name:</label>
                                <input type="text"
                                    class="form-control <?php echo e($errors->has('parentInfo.' . $key . '.Middle_Name') ? 'is-invalid' : ''); ?>"
                                    wire:model.defer='parentInfo.<?php echo e($key); ?>.Middle_Name'>
                                <?php $__errorArgs = ['parentInfo.*.Middle_Name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback error_text"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group">
                                <label>Last Name:</label>
                                <input type="text"
                                    class="form-control <?php echo e($errors->has('parentInfo.' . $key . '.Last_Name') ? 'is-invalid' : ''); ?>"
                                    wire:model.defer='parentInfo.<?php echo e($key); ?>.Last_Name'>
                                <?php $__errorArgs = ['parentInfo.*.Last_Name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback error_text"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group">
                                <label class="blck">Suffix:</label>
                                <select
                                    class="form-control <?php echo e($errors->has('parentInfo.' . $key . '.Suffix') ? 'is-invalid' : ''); ?>"
                                    wire:model='parentInfo.<?php echo e($key); ?>.Suffix'>
                                    <option value="">-- Please Choose --</option>
                                    <?php $__currentLoopData = $suffixList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $suffix): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($suffix['suffix_name']); ?>">
                                            <?php echo e($suffix['suffix_name']); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['parentInfo.*.Suffix'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback error_text"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group">
                                <label>Address Location:</label>
                                <select
                                    class="form-control <?php echo e($errors->has('parentInfo.' . $key . '.Address_Type') ? 'is-invalid' : ''); ?>"
                                    wire:model='parentInfo.<?php echo e($key); ?>.Address_Type'>
                                    <option value="">-- Please Choose --</option>
                                    <?php $__currentLoopData = $addressList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $addKey => $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($address['name']); ?>"><?php echo e(ucwords($address['name'])); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['parentInfo.*.Address_Type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback error_text"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group">
                                <label>Mobile Phone:</label>
                                <div class="row fr-row for-dash-new">
                                    <div class="col-md-3 fr-col">
                                        <input id="ap<?php echo e($key); ?>" type="text" maxlength="3"
                                            class="form-control "
                                            wire:model.defer='parentInfo.<?php echo e($key); ?>.mobile_phone_number_one'
                                            oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*?)\..*/g, '$1');" />
                                    </div>
                                    <div class="col-md-3 fr-col">
                                        <input id="bq<?php echo e($key); ?>" type="text" maxlength="3"
                                            class="form-control "
                                            wire:model.defer='parentInfo.<?php echo e($key); ?>.mobile_phone_number_two'
                                            oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*?)\..*/g, '$1');" />
                                    </div>
                                    <div class="col-md-6 fr-col mobile_no_display">
                                        <input id="cr<?php echo e($key); ?>" type="text" maxlength="4"
                                            class="form-control "
                                            wire:model.defer='parentInfo.<?php echo e($key); ?>.mobile_phone_number_three'
                                            oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*?)\..*/g, '$1');" />
                                    </div>
                                    <?php $__errorArgs = ['parentInfo.' . $key . '.Mobile_Phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="error error_text"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <script>
                                        let ap = document.getElementById("ap<?php echo e($key); ?>"),
                                            bq = document.getElementById("bq<?php echo e($key); ?>"),
                                            cr = document.getElementById("cr<?php echo e($key); ?>");
                                        ap.onkeyup = function() {
                                            if (this.value.length === parseInt(this.attributes["maxlength"].value)) {
                                                bq.focus();
                                            }
                                        }
                                        bq.onkeyup = function() {
                                            if (this.value.length === parseInt(this.attributes["maxlength"].value)) {
                                                cr.focus();
                                            }
                                        }
                                    </script>
                                </div>
                            </div>

                            <div class="form-group">
                                <label>Personal Email:</label>
                                <input type="text"
                                    class="form-control <?php echo e($errors->has('parentInfo.' . $key . '.Personal_Email') ? 'is-invalid' : ''); ?>"
                                    wire:model.defer='parentInfo.<?php echo e($key); ?>.Personal_Email'>
                                <?php $__errorArgs = ['parentInfo.*.Personal_Email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback error_text"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group">
                                <label class="blck">Employer:</label>
                                <input type="text"
                                    class="form-control <?php echo e($errors->has('parentInfo.' . $key . '.Employer') ? 'is-invalid' : ''); ?>"
                                    wire:model.defer='parentInfo.<?php echo e($key); ?>.Employer'>
                                <?php $__errorArgs = ['parentInfo.*.Employer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback error_text"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group">
                                <label class="blck">Title:</label>
                                <input type="text"
                                    class="form-control <?php echo e($errors->has('parentInfo.' . $key . '.Title') ? 'is-invalid' : ''); ?>"
                                    wire:model.defer='parentInfo.<?php echo e($key); ?>.Title'>
                                <?php $__errorArgs = ['parentInfo.*.Title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback error_text"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group">
                                <label class="blck">Work Email:</label>
                                <input type="text"
                                    class="form-control <?php echo e($errors->has('parentInfo.' . $key . '.Work_Email') ? 'is-invalid' : ''); ?>"
                                    wire:model.defer='parentInfo.<?php echo e($key); ?>.Work_Email'>
                                <?php $__errorArgs = ['parentInfo.*.Work_Email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback error_text"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group">
                                <label class="blck">Work Phone:</label>
                                <div class="row fr-row phnnofields">
                                    <div class="col-md-3 fr-col">
                                        <input id="ax<?php echo e($key + 1); ?>" type="text" maxlength="3"
                                            class="form-control "
                                            wire:model.defer='parentInfo.<?php echo e($key); ?>.work_phone_number_one'
                                            oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*?)\..*/g, '$1');" />
                                    </div>
                                    <div class="col-md-3 fr-col">
                                        <input id="by<?php echo e($key + 1); ?>" type="text" maxlength="3"
                                            class="form-control "
                                            wire:model.defer='parentInfo.<?php echo e($key); ?>.work_phone_number_two'
                                            oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*?)\..*/g, '$1');" />
                                    </div>
                                    <div class="col-md-6 fr-col lastfield">
                                        <input id="cz<?php echo e($key + 1); ?>" type="text" maxlength="4"
                                            class="form-control "
                                            wire:model.defer='parentInfo.<?php echo e($key); ?>.work_phone_number_three'
                                            oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*?)\..*/g, '$1');" />
                                    </div>
                                    <?php $__errorArgs = ['parentInfo.' . $key . '.Work_Phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="error error_text"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <script>
                                        let aa = document.getElementById("ax<?php echo e($key + 1); ?>"),
                                            bb = document.getElementById("by<?php echo e($key + 1); ?>"),
                                            cc = document.getElementById("cz<?php echo e($key + 1); ?>");
                                        aa.onkeyup = function() {
                                            if (this.value.length === parseInt(this.attributes["maxlength"].value)) {
                                                bb.focus();
                                            }
                                        }
                                        bb.onkeyup = function() {
                                            if (this.value.length === parseInt(this.attributes["maxlength"].value)) {
                                                cc.focus();
                                            }
                                        }
                                    </script>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="blck">Work Phone Extension:</label>
                                <input type="text"
                                    class="form-control <?php echo e($errors->has('parentInfo.' . $key . '.Work_Phone_Ext') ? 'is-invalid' : ''); ?>"
                                    wire:model.defer='parentInfo.<?php echo e($key); ?>.Work_Phone_Ext'>
                                <?php $__errorArgs = ['parentInfo.*.Work_Phone_Ext'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback error_text"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group">
                                <label>List all high schools, colleges, or graduate schools you
                                    have attended:</label>
                                <div data-maxcount="125" wire:ignore>
                                    <textarea id="stepThreeTextArea<?php echo e($key); ?>"
                                        class="word_count form-control <?php echo e($errors->has('parentInfo.' . $key . '.Schools') ? 'is-invalid' : ''); ?>"
                                        name="stepThreeTextArea" wire:model.defer='parentInfo.<?php echo e($key); ?>.Schools'></textarea>
                                    <p class="wrds">
                                    <!--    (Max <span class="word_left" id="wordCount<?php echo e($key); ?>">75 </span>words) -->
                                    (Please limit answer to 75 words.)
                                    </p>
                                    <script>
                                        $(document).ready(function() {
                                            console.log("ready!");
                                            let countwords = $.trim($('#stepThreeTextArea<?php echo e($key); ?>').val()).split(' ').filter(function(
                                                v) {
                                                return v !== ''
                                            }).length;
                                            console.log(countwords);
                                            document.getElementById("wordCount<?php echo e($key); ?>").innerHTML = 125 - countwords;
                                        });

                                        $("[data-maxcount]").each(function() {
                                            let _this = $(this);
                                            let _this_count = parseInt(_this.attr("data-maxcount"));
                                            _this.find("#stepThreeTextArea<?php echo e($key); ?>").on("keyup", function() {
                                                let words = 0;
                                                if (this.value.match(/\S+/g) != null) {
                                                    words = this.value.match(/\S+/g).length;
                                                }
                                                if (words > _this_count) {
                                                    let trimmed = $(this).val().split(/\s+/, _this_count).join(" ");
                                                    $(this).val(trimmed + " ");
                                                } else {
                                                    _this.find("#wordCount<?php echo e($key); ?>").text(_this_count - words);
                                                }
                                            });
                                        });
                                    </script>
                                </div>
                                <?php $__errorArgs = ['parentInfo.' . $key . '.Schools'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="error error_text"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group">
                                <label>Living Situation </label>
                                <div class="schl-rdo ml-0">
                                    <div class="form_input_radio">
                                        <?php $__currentLoopData = $livingSituationList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lsKey => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <label class="radio-pro">
                                                <input type="radio" name="radio<?php echo e($key); ?>" value="<?php echo e($item['id']); ?>"
                                                    wire:model.defer="parentInfo.<?php echo e($key); ?>.Living_Situation"/>
                                                <?php echo e(ucwords($item['name'])); ?>

                                                <span class="checkmark"></span>
                                            </label>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php $__errorArgs = ['parentInfo.' . $key . '.Living_Situation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="error error_text"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="blck">Status </label>
                                <div class="check-wrap">
                                    <label class="check-inn">
                                        <input type="checkbox" class="open" value="1"
                                            wire:model="parentInfo.<?php echo e($key); ?>.Status">
                                        Deceased
                                        <span class="checkmark"></span>
                                    </label>
                                    <?php $__errorArgs = ['parentInfo.*.Status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback error_text"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            
                            <div class="form-outr">
                                <div class="schl-btm mt">
                                    <div class="form_input_radio">
                                        <?php if($key < 3 && $i !== 4): ?>
                                            <button class="btn btn-danger btn-sm"
                                                wire:click.prevent="add(<?php echo e($i); ?>)">Add another
                                                parent</button>
                                        <?php endif; ?>
                                        <?php if($key != 0): ?>
                                            <button class="btn btn-danger btn-sm"
                                                wire:click.prevent="remove(<?php echo e($key); ?>)">Remove
                                                parent</button>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        <div class="flx">
            <div class="form-btn">
                <a href="<?php echo e(route('admission-application', ['step' => 'two'])); ?>" class="sub-btn">Previous</a>
            </div>
            <div class="form-btn">
                <button type="submit" value="Next" class="sub-btn">Next/Save</button>
            </div>
        </div>
    </form>
</div>
<?php /**PATH /var/www/html/admission-portal-web-1854/resources/views/livewire/frontend/application/application-three.blade.php ENDPATH**/ ?>