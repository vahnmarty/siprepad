

<form wire:submit.prevent="submit" method="POST">
	<div class="home-wrap hme-wrp2">


            <div class="progress-outr">
                <ul class="progress-ul">
                    <li class="step-complete">
                        <?php if($registeration_student_info): ?>
                            <a href="<?php echo e(route('admission-application', ['step' => 'one'])); ?>">
                                <span>1</span>
                                <h6>Student Info</h6>
                            </a>
                        <?php else: ?>
                            <a href="javascript::void(0)">
                                <span>1</span>
                                <h6>Student Info</h6>
                            </a>
                        <?php endif; ?>

                    </li>
                    <li class="step-complete">
                        <?php if($registeration_student_info): ?>
                            <a href="<?php echo e(route('admission-application', ['step' => 'two'])); ?>">
                                <span>2</span>
                                <h6>Address Info</h6>
                            </a>
                        <?php else: ?>
                            <a href="javascript::void(0)">
                                <span>2</span>
                                <h6>Address Info</h6>
                            </a>
                        <?php endif; ?>
                    </li>
                    <li class="step-complete">
                        <?php if($registeration_student_info): ?>
                            <a href="<?php echo e(route('admission-application', ['step' => 'three'])); ?>">
                                <span>3</span>
                                <h6>Parent Info</h6>
                            </a>
                        <?php else: ?>
                            <a href="javascript::void(0)">
                                <span>3</span>
                                <h6>Parent Info</h6>
                            </a>
                        <?php endif; ?>
                    </li>
                    <li class="step-complete">
                        <?php if($registeration_student_info): ?>
                            <a href="<?php echo e(route('admission-application', ['step' => 'four'])); ?>">
                                <span>4</span>
                                <h6>Sibling Info</h6>
                            </a>
                        <?php else: ?>
                            <a href="javascript::void(0)">
                                <span>4</span>
                                <h6>Sibling Info</h6>
                            </a>
                        <?php endif; ?>
                    </li>
                    <li class="step-complete">
                        <?php if($registeration_student_info): ?>
                            <a href="<?php echo e(route('admission-application', ['step' => 'five'])); ?>">
                                <span>5</span>
                                <h6>Legacy Info</h6>
                            </a>
                        <?php else: ?>
                            <a href="javascript::void(0)">
                                <span>5</span>
                                <h6>Legacy Info</h6>
                            </a>
                        <?php endif; ?>
                    </li>
                    <li class="step-complete">
                        <?php if($registeration_student_info): ?>
                            <a href="<?php echo e(route('admission-application', ['step' => 'six'])); ?>">
                                <span>6</span>
                                <h6>Parent Statement</h6>
                            </a>
                        <?php else: ?>
                            <a href="javascript::void(0)">
                                <span>6</span>
                                <h6>Parent Statement</h6>
                            </a>
                        <?php endif; ?>
                    </li>
                    <li class="step-complete">
                        <?php if($registeration_student_info): ?>
                            <a href="<?php echo e(route('admission-application', ['step' => 'seven'])); ?>">
                                <span>7</span>
                                <h6>Spiritual & Community Info</h6>
                            </a>
                        <?php else: ?>
                            <a href="javascript::void(0)">
                                <span>7</span>
                                <h6>Spiritual & Community Info</h6>
                            </a>
                        <?php endif; ?>
                    </li>
                    <li class="step-complete">
                        <?php if($registeration_student_info): ?>
                            <a href="<?php echo e(route('admission-application', ['step' => 'eight'])); ?>">
                                <span>8</span>
                                <h6>Student Statement</h6>
                            </a>
                        <?php else: ?>
                            <a href="javascript::void(0)">
                                <span>8</span>
                                <h6>Student Statement</h6>
                            </a>
                        <?php endif; ?>
                    </li>
                    <li>
                        <?php if($registeration_student_info): ?>
                            <a href="<?php echo e(route('admission-application', ['step' => 'nine'])); ?>">
                                <span>9</span>
                                <h6>Writing Sample</h6>
                            </a>
                        <?php else: ?>
                            <a href="javascript::void(0)">
                                <span>9</span>
                                <h6>Writing Sample</h6>
                            </a>
                        <?php endif; ?>
                    </li>
                    <li>
                        <?php if($registeration_student_info): ?>
                            <a href="<?php echo e(route('admission-application', ['step' => 'ten'])); ?>">
                                <span>10</span>
                                <h6>Final Steps</h6>
                            </a>
                        <?php else: ?>
                            <a href="javascript::void(0)">
                                <span>10</span>
                                <h6>Final Steps</h6>
                            </a>
                        <?php endif; ?>
                    </li>
                </ul>
            </div>		<div class="form-outr">

			<div class="form-outr">
				<div class="cmn-hdr">
					<h4>Student Info</h4>
					
				</div>

				<div class="school-wrap step__one">
					<div class="form-wrap">
						<div class="row">
							<div class="col-md-4">
								<div class="form-group">
									<label> Legal First Name </label> <input type="text"
										class="form-control" wire:model.defer='first_name' value="<?php echo e($studentinfo->S1_First_Name); ?>"
										 /> <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<p class="text-danger"><?php echo e($message); ?></p>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

								</div>
							</div>
							<div class="col-md-4">
								<div class="form-group">
									<label class="blck">Legal Middle Name </label> <input
										type="text" class="form-control"
										wire:model.defer='middle_name'
										value="<?php echo e(old('middle_name')); ?>" /> <?php $__errorArgs = ['middle_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<p class="text-danger"><?php echo e($message); ?></p>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
								</div>
							</div>
							<div class="col-md-4">
								<div class="form-group">
									<label>Legal Last Name </label> <input type="text"
										class="form-control" wire:model.defer='last_name'
										value="<?php echo e(old('last_name')); ?>" /> <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<p class="text-danger"><?php echo e($message); ?></p>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
								</div>
							</div>

						</div>
						<div class="row">
							<div class="col-md-4">
								<div class="form-group">
									<label class="blck">Preffered First Name </label> <input
										type="text" class="form-control"
										wire:model.defer='preffered_first_name'
										value="<?php echo e(old('preffered_first_name')); ?>" />
									<?php $__errorArgs = ['preffered_first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<p class="text-danger"><?php echo e($message); ?></p>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
								</div>
							</div>
							<div class="col-md-4">
								<div class="form-group">
									<label>Date of Birth </label> <input type="date"
										class="form-control" wire:model.defer='date_of_birth'
										value="<?php echo e(old('date_of_birth')); ?>" name="date_of_birth" />
									<?php $__errorArgs = ['date_of_birth'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<p class="text-danger"><?php echo e($message); ?></p>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
								</div>
							</div>
							<div class="col-md-4">
								<div class="form-group">
									<label>Gender </label> <select
										class="form-control" wire:model.defer='gender'
										value="<?php echo e(old('gender')); ?>">
										<option value="" selected></option>
										<option value="male">Male</option>
										<option value="female">Female</option>

									</select>
									<?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<p class="text-danger"><?php echo e($message); ?></p>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
								</div>
							</div>

						</div>
						<div class="row">
							<div class="col-md-4">
								<div class="form-group">
									<label>Student's Mobile Phone Number </label> <input type="tel"
										class="form-control" wire:model.defer='student_phone_number'
										value="<?php echo e(old('student_phone_number')); ?>" />
									<?php $__errorArgs = ['student_phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<p class="text-danger"><?php echo e($message); ?></p>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
								</div>
							</div>
							<div class="col-md-4">
								<div class="form-group">
									<label>T-Shirt Size(Adult/Unisex) </label> <select
										class="form-control" wire:model.defer='tshirt_size'
										value="<?php echo e(old('tshirt_size')); ?>">
										<option value="">-- Please Choose --</option>
										<option value="small">Small</option>
										<option value="medium">Medium</option>
										<option value="large">Large</option>
									</select> <?php $__errorArgs = ['tshirt_size'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<p class="text-danger"><?php echo e($message); ?></p>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
								</div>
							</div>

						</div>

						<div class="row">
							<div class="col-md-4">
								<div class="form-group">
									<label class="blck">Religion </label><select
										class="form-control" wire:model.defer='religion'
										value="<?php echo e(old('religion')); ?>">
										<option value="">-- Please Choose --</option>

										<option value="christian">Christian</option>
										
									</select> <?php $__errorArgs = ['religion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<p class="text-danger"><?php echo e($message); ?></p>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
								</div>
							</div>


						</div>
						<div class="multiracial mb-3">
							<span>How do you identify racially? if you identify by more than
								one race , Select all that apply to you and also select the<br>
								"multiracial" checkbox.
							</span>
						</div>
						<div class="form-group">
							<label class="blck"><input type="checkbox"
								wire:model.defer="racial" value="Asian">Asian</label><br> <label
								class="blck"><input type="checkbox" wire:model.defer="racial"
								value="Black/African American"> Black/African American</label><br>
							<label class="blck"><input type="checkbox"
								wire:model.defer="racial" value="Native American/Indegenous">
								Native American/Indegenous</label><br> <label class="blck"><input
								type="checkbox" wire:model.defer="racial" value="White"> White</label>
							<br>
							<label class="blck"><input type="checkbox"
								wire:model.defer="racial" value="Multiracial"> Multiracial</label>
							<?php $__errorArgs = ['racial'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							<p class="text-danger"><?php echo e($message); ?></p>
							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
						</div>

						<div class="ethinicity ">
							<span>What is your ethinicity ?if more than one separate
								ethnicities with a comma. Example: Filipino , Hawaiian , Irish ,
								Italian , Middle Eastern , Salvadorian" </span>
						</div>
						<div class="row">
							<div class="col-md-4">
								<div class="form-group">
									<input type="text" class="form-control"
										wire:model.defer='ethnicity' value="<?php echo e(old('ethnicity')); ?>" />
									<?php $__errorArgs = ['ethnicity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<p class="text-danger"><?php echo e($message); ?></p>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

								</div>

							</div>

						</div>
						<div class="row">
							<div class="col-md-4">
								<div class="form-group">
									<label class="blck">Current School </label><select
										class="form-control" wire:model.defer='current_school'
										value="<?php echo e(old('current_school')); ?>">
										<option value="">-- Please Choose --</option>
										<option value="test_school">Test School</option>

									</select> <?php $__errorArgs = ['current_school'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<p class="text-danger"><?php echo e($message); ?></p>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

								</div>
							</div>
						</div>
					</div>
				</div>
			</div>

		</div>
		<div class="form-btn text-end mt">
			<button type="submit" value="Next" class="sub-btn">Next/Save</button>
		</div>


	</div>
</form><?php /**PATH /var/www/html/admission-portal-web-1854/resources/views/livewire/frontend/registeration/registeration-one.blade.php ENDPATH**/ ?>