
<form wire:submit.prevent="Savehousehold">
	<div class="home-wrap hme-wrp2">
		<div class="progress-outr"></div>
		
			<div class="form-outr">
				<div class="cmn-hdr">
					<h4>Student Information</h4>
				</div>

				<div class="school-wrap step__one">
					<div class="form-wrap">
						<div class="form-wrap">
							<div class="row">
								<div class="col-md-4"></div>
								<div class="col-md-4">
									<div class="form-group">
										<label>Student Lives with </label><br> <label class="blck"><input
											type="radio" wire:model="live_with" value="Father"
											id="Father"> Father</label><br> <label class="blck"><input
											type="radio" id="Mother" wire:model="live_with"
											value="Mother">Mother</label><br> <label class="blck"><input
											type="radio" wire:model="live_with" id="StepFather"
											value="StepFather">StepFather</label><br> <label class="blck"><input
											type="radio" wire:model="live_with" value="StepMother"
											id="StepMother"> StepMother</label> <br> <label class="blck"><input
											type="radio" wire:model="live_with" value="Guradians"
											id="Guradians"> Guardians</label> <?php $__errorArgs = ['live_with'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
										<div class="text-danger"><?php echo e($message); ?></div>
										<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
									</div>
								</div>

							</div>


							<div class="cmn-hdr">
								<h4 class="text-center" style="font-size: 25px">Household
									Information</h4>
							</div>
							<div class="row">
								<div class="col-lg-3"></div>
								<div class="col-lg-9">
									<div class="form-group">
										<label>Street</label> <input type="text" class="form-control"
											wire:model='street' /> <?php $__errorArgs = ['street'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
										<p class="text-danger"><?php echo e($message); ?></p>
										<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
									</div>
								</div>
							</div>
							<div class="row">

								<div class="col-lg-3"></div>
								<div class="col-lg-9">
									<div class="form-group">
										<label>City</label> <input type="text" class="form-control"
											wire:model='city' /> <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
										<p class="text-danger"><?php echo e($message); ?></p>
										<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-lg-3"></div>
								<div class="col-lg-9">
									<div class="form-group">
										<label>State</label> <input type="text" class="form-control"
											wire:model='state' /> <?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
										<p class="text-danger"><?php echo e($message); ?></p>
										<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-lg-3"></div>
								<div class="col-lg-9">
									<div class="form-group">
										<label>Zip Code</label> <input type="number"
											class="form-control" wire:model='zip_code' />
										<?php $__errorArgs = ['zip_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
										<p class="text-danger"><?php echo e($message); ?></p>
										<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-lg-3"></div>
								<div class="col-lg-9">
									<div class="form-group">
										<label>Home Phone</label> <input type="tel"
											class="form-control" wire:model='home_phone' />
										<?php $__errorArgs = ['home_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
										<p class="text-danger"><?php echo e($message); ?></p>
										<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-lg-3"></div>
								<div class="col-lg-9">
									<div class="form-group">
										<label>Primary Parent (for SI to contact first regarding
											school matters)</label> <select class="form-control"
											wire:model='primary_parent'>
											<option value="">-- Please Choose --</option>

											<option value="father">Father</option>
											<option value="mother">Mother</option>
											<option value="stepmother">Stepmother</option>
											<option value="stepfather">Stepfather</option>
											<option value="guardians">Guardians</option>
										</select> <?php $__errorArgs = ['primary_parent'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
										<p class="text-danger"><?php echo e($message); ?></p>
										<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
									</div>
								</div>
							</div>

							<div class="cmn-hdr">
								<h4 class="text-center" style="font-size: 22px">Household 1 -
									Parent/Guardian 1</h4>
							</div>
							<div class="form-wrap">
								<div class="row">
									<div class="col-lg-3"></div>
									<div class="col-lg-9">
										<div class="form-group">
											<label class="blck">Relationship to Applicant</label> <select
												class="form-control" wire:model='relation_to_applicant'>
												<option value="">-- Please Choose --</option>

												<option value="father">Father</option>
												<option value="mother">Mother</option>
												<option value="stepmother">Stepmother</option>
												<option value="stepfather">Stepfather</option>
												<option value="guardians">Guardians</option>
											</select> <?php $__errorArgs = ['relation_to_applicant'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<p class="text-danger"><?php echo e($message); ?></p>
											<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-3"></div>
									<div class="col-lg-9">
										<div class="form-group">
											<label class="blck">First Name</label> <input type="text"
												class="form-control" wire:model='parent_first_name' />
											<?php $__errorArgs = ['parent_first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<p class="text-danger"><?php echo e($message); ?></p>
											<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-3"></div>
									<div class="col-lg-9">
										<div class="form-group">
											<label class="blck">Middle Name</label> <input type="text"
												class="form-control" wire:model='parent_middle_name' />
											<?php $__errorArgs = ['parent_middle_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<p class="text-danger"><?php echo e($message); ?></p>
											<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-3"></div>
									<div class="col-lg-9">
										<div class="form-group">
											<label class="blck">Last Name</label> <input type="text"
												class="form-control" wire:model='parent_last_name' />
											<?php $__errorArgs = ['parent_last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<p class="text-danger"><?php echo e($message); ?></p>
											<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-3"></div>
									<div class="col-lg-9">
										<div class="form-group">
											<label class="blck">Cell Phone</label> <input type="tel"
												class="form-control" wire:model='parent_cell_phone' />
											<?php $__errorArgs = ['cell_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<p class="text-danger"><?php echo e($message); ?></p>
											<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-3"></div>
									<div class="col-lg-9">
										<div class="form-group">
											<label class="blck">Email Address</label> <input type="email"
												class="form-control" wire:model='parent_email' />
											<?php $__errorArgs = ['parent_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<p class="text-danger"><?php echo e($message); ?></p>
											<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-3"></div>
									<div class="col-lg-9">
										<div class="form-group">
											<label class="blck">Employer</label> <input type="employer"
												class="form-control" wire:model='parent_employer' />
											<?php $__errorArgs = ['parent_employer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<p class="text-danger"><?php echo e($message); ?></p>
											<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-3"></div>
									<div class="col-lg-9">
										<div class="form-group">
											<label class="blck">Position/Title</label> <input
												type="parent_position" class="form-control"
												wire:model='parent_position' /> <?php $__errorArgs = ['parent_position'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<p class="text-danger"><?php echo e($message); ?></p>
											<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-3"></div>
									<div class="col-lg-9">
										<div class="form-group">
											<label class="blck">Work Phone</label> <input type="tel"
												class="form-control" wire:model='parent_work_phone' />
											<?php $__errorArgs = ['parent_work_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<p class="text-danger"><?php echo e($message); ?></p>
											<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-3"></div>
									<div class="col-lg-9">
										<div class="form-group">
											<label class="blck">School/Colleges Attended</label>
											<textarea rows="25" cols="10" wire:model="parent_school"></textarea>
											<?php $__errorArgs = ['parent_school'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<p class="text-danger"><?php echo e($message); ?></p>
											<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>

				</div>
				  <div class="flx">
				<div class="form-btn text-end mt">
                <a href="<?php echo e(route('registeration-application', ['step' => 'one'])); ?>" class="sub-btn">Previous</a>
            </div>
				<div class="form-btn text-end mt">
					<button type="submit" value="Next" class="sub-btn">Next/Save</button>
				</div>
</div>
</div>
			</div>

</form><?php /**PATH /var/www/html/admission-portal-web-1854/resources/views/livewire/frontend/registeration/registeration-two.blade.php ENDPATH**/ ?>