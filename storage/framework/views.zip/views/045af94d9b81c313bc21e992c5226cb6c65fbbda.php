<div class="kt-subheader__breadcrumbs">
    <a href="#" class="kt-subheader__breadcrumbs-home"><i class="flaticon2-shelter"></i></a>
        <?php echo e($slot); ?>

</div><?php /**PATH /var/www/html/admission-portal-web-1854/resources/views/components/admin/breadcrumbs.blade.php ENDPATH**/ ?>