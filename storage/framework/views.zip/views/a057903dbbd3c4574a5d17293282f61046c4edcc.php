<?php $attributes = $attributes->exceptProps(['search' => null]); ?>
<?php foreach (array_filter((['search' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<div class="kt-portlet kt-portlet--mobile">
    <div class="kt-portlet__body">
        <div id="kt_table_1_wrapper" class="dataTables_wrapper dt-bootstrap4 no-footer">
            <div class="row">
                <div class="col-sm-12 col-md-6">
                    <div class="dataTables_length" id="kt_table_1_length">
                        <?php echo e($perPage); ?>

                        
                    </div>
                </div>
                <div class="col-sm-12 col-md-6">
                    <div id="kt_table_1_filter" class="dataTables_filter">
                        
                        <?php echo e($search); ?>

                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-12">
                    <table
                        class="table table-responsive table-striped- table-bordered table-hover table-checkable dataTable no-footer dtr-inline"
                        id="kt_table_1" role="grid" aria-describedby="kt_table_1_info" style="width: 1115px;">
                        <thead>
                            <?php echo e($thead); ?>

                        </thead>
                        <tbody>
                            <?php echo e($tbody); ?>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-12 col-md-5">
                <div class="dataTables_info" id="kt_table_1_info" role="status" aria-live="polite">
                    <?php echo e($showingEntries); ?>

                </div>
            </div>
            <div class="col-sm-12 col-md-7">
                <div class="dataTables_paginate paging_simple_numbers float-right" id="kt_table_1_paginate">
                    <?php echo e($pagination); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /var/www/html/admission-portal-web-1854/resources/views/components/admin/table.blade.php ENDPATH**/ ?>