
<?php $__env->startSection('title', __('page_title.admission_application_page_title')); ?>
<?php $__env->startPush('css'); ?>
    <script type="text/javascript">
        window.history.forward();

        function noBack() {
            window.history.forward();
        }
    </script>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('frontend.application.application-ten', ['getReleaseAuthorization' => $getReleaseAuthorization])->html();
} elseif ($_instance->childHasBeenRendered('couYYS9')) {
    $componentId = $_instance->getRenderedChildComponentId('couYYS9');
    $componentTag = $_instance->getRenderedChildComponentTagName('couYYS9');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('couYYS9');
} else {
    $response = \Livewire\Livewire::mount('frontend.application.application-ten', ['getReleaseAuthorization' => $getReleaseAuthorization]);
    $html = $response->html();
    $_instance->logRenderedChild('couYYS9', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    <script>
        function formats(ele, e) {
            if (ele.value.length < 19) {
                ele.value = ele.value.replace(/\W/gi, '').replace(/(.{4})/g, '$1 ');
                return true;
            } else {
                return false;
            }
        }

        function numberValidation(e) {
            e.target.value = e.target.value.replace(/[^\d ]/g, '');
            return false;
        }

        window.livewire.on('openPaymentModal', () => {
            $('#staticBackdrop').modal('show');
        })

        window.livewire.on('hidePaymentModal', (data) => {
            console.log(data);

            if (data.status === "error") {
                toastr.options = {
                    "closeButton": true,
                    "progressBar": true
                }
                toastr.error(data.message);
            } else {
                toastr.options = {
                    "closeButton": true,
                    "progressBar": true
                }
                toastr.success(data.message);
                $('#staticBackdrop').modal('hide');
                $('#successPaymentModal').modal('show');
            }

        })

        window.livewire.on('hidePayment', (data) => {
            console.log(data);
            $('#staticBackdrop').modal('hide');
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.frontend-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/admission-portal-web-1854/resources/views/frontend/application/application-ten.blade.php ENDPATH**/ ?>