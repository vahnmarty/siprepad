
<?php $__env->startSection('title', __('page_title.admission_application_page_title')); ?>
<?php $__env->startPush('css'); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('frontend.application.application-eight', ['getStudentStatementInfo' => $getStudentStatementInfo])->html();
} elseif ($_instance->childHasBeenRendered('oPHdHYx')) {
    $componentId = $_instance->getRenderedChildComponentId('oPHdHYx');
    $componentTag = $_instance->getRenderedChildComponentTagName('oPHdHYx');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('oPHdHYx');
} else {
    $response = \Livewire\Livewire::mount('frontend.application.application-eight', ['getStudentStatementInfo' => $getStudentStatementInfo]);
    $html = $response->html();
    $_instance->logRenderedChild('oPHdHYx', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.frontend-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/admission-portal-web-1854/resources/views/frontend/application/application-eight.blade.php ENDPATH**/ ?>