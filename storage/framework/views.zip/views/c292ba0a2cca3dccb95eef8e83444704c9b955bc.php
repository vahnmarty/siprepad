<!-- begin:: Footer -->
<script src='<?php echo e(asset("/admin_assets/js/jquery.min.js")); ?>'></script>
<div class="kt-footer kt-grid__item kt-grid kt-grid--desktop kt-grid--ver-desktop">
    <div class="kt-footer__copyright">
        <?php echo e(date('Y')); ?>&nbsp;&copy;&nbsp;<a href="<?php echo e(route('admin.dashboard')); ?>"
            class="kt-link"><?php echo e(config('app.name', 'Laravel')); ?> </a>
    </div>
    <div class="kt-footer__menu">
        
    </div>
</div>

<!-- end:: Footer -->
<?php /**PATH /var/www/html/admission-portal-web-1854/resources/views/components/admin-includes/admin-footer.blade.php ENDPATH**/ ?>