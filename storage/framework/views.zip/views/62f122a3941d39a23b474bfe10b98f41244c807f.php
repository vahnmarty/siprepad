
<?php $__env->startSection('title', __('page_title.admission_application_page_title')); ?>
<?php $__env->startPush('css'); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('frontend.application.application-two', ['getAddress' => $getAddressInfo])->html();
} elseif ($_instance->childHasBeenRendered('fdwSYY5')) {
    $componentId = $_instance->getRenderedChildComponentId('fdwSYY5');
    $componentTag = $_instance->getRenderedChildComponentTagName('fdwSYY5');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('fdwSYY5');
} else {
    $response = \Livewire\Livewire::mount('frontend.application.application-two', ['getAddress' => $getAddressInfo]);
    $html = $response->html();
    $_instance->logRenderedChild('fdwSYY5', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.frontend-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/admission-portal-web-1854/resources/views/frontend/application/application-two.blade.php ENDPATH**/ ?>