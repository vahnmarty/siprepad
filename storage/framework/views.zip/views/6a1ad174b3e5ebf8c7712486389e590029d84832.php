<div>
    <section class="form_one student_wrapper">
        <div class="student_detail_wrapper">
            <div class="form_student_details">
                <div class="main_heading">
                    <h2>Student Info</h2>
                </div>
                <?php $__empty_1 = true; $__currentLoopData = $studentInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $studentKey=>$student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    
                    <div class="studentWise_details">
                        <h4 class="sub_heading">Student <?php echo e($studentKey + 1); ?></h4>
                        <div class="row">
                            <div class="col-lg-12 col-md-12">
                                <div class="student_box studentProfile">
                                    <?php if($student['Photo']): ?>
                                        <img src="<?php echo e(asset($student['Photo'])); ?>" alt="" />
                                    <?php else: ?>
                                        <img src="<?php echo e(asset($student['Photo'])); ?>" alt="" />
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="col-lg-4 col-md-6">
                                <div class="student_box">
                                    <label>Legal First Name:</label>
                                    <div class="student_box_text">
                                        <?php if($student['First_Name']): ?>
                                            <p><?php echo e($student['First_Name']); ?></p>
                                        <?php else: ?>
                                            <p>---</p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-4 col-md-6">
                                <div class="student_box">
                                    <label>Legal Middle Name:</label>
                                    <div class="student_box_text">
                                        <?php if($student['Middle_Name']): ?>
                                            <p><?php echo e($student['Middle_Name']); ?></p>
                                        <?php else: ?>
                                            <p>---</p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-4 col-md-4">
                                <div class="student_box">
                                    <label>Legal Last Name:</label>
                                    <div class="student_box_text">
                                        <?php if($student['Last_Name']): ?>
                                            <p><?php echo e($student['Last_Name']); ?></p>
                                        <?php else: ?>
                                            <p>---</p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-4 col-md-4">
                                <div class="student_box">
                                    <label>Legal Suffix:</label>
                                    <div class="student_box_text">
                                        <?php if($student['Suffix']): ?>
                                            <p><?php echo e($student['Suffix']); ?></p>
                                        <?php else: ?>
                                            <p>---</p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-4 col-md-4">
                                <div class="student_box">
                                    <label>Preferred First Name:</label>
                                    <div class="student_box_text">
                                        <?php if($student['Preferred_First_Name']): ?>
                                            <p><?php echo e($student['Preferred_First_Name']); ?></p>
                                        <?php else: ?>
                                            <p>---</p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-6 col-md-6">
                                <div class="student_box">
                                    <label>Date of Birth:</label>
                                    <div class="student_box_text">
                                        <?php if($student['Birthdate']): ?>
                                            <p><?php echo e($student['Birthdate']); ?></p>
                                        <?php else: ?>
                                            <p>---</p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-6 col-md-6">
                                <div class="student_box">
                                    <label>Gender:</label>
                                    <div class="student_box_text">
                                        <?php if($student['Gender']): ?>
                                            <p><?php echo e($student['Gender']); ?></p>
                                        <?php else: ?>
                                            <p>---</p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-6 col-md-6">
                                <div class="student_box">
                                    <label>Personal Email:</label>
                                    <div class="student_box_text">
                                        <?php if($student['Personal_Email']): ?>
                                            <p><?php echo e($student['Personal_Email']); ?></p>
                                        <?php else: ?>
                                            <p>---</p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-6 col-md-6">
                                <div class="student_box">
                                    <label>Mobile Phone:</label>
                                    <div class="student_box_text">
                                        <?php if($student['Mobile_Phone']): ?>
                                            <p><?php echo e($student['Mobile_Phone']); ?></p>
                                        <?php else: ?>
                                            <p>---</p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <p><span>NOTE:</span> Text messages may be sent directly to applicant.</P>

                            <div class="col-lg-12 col-md-12">
                                <div class="student_box">
                                    <label>How do you identify racially?</label>
                                    <p><b>If you identify with more than one race, select all that apply to you.</b></p>

                                    <div class="student_box_text">
                                        <ul>
                                            <?php if($student['Race']): ?>
                                                <?php $__empty_2 = true; $__currentLoopData = $student['Race']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                                    <?php
                                                        //$item = App\Models\IdentifyRacially::find($key);
                                                    ?>
                                                    <li><?php echo e($value); ?></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                                    <li>---</li>
                                                <?php endif; ?>
                                            <?php else: ?>
                                                <p>---</p>
                                            <?php endif; ?>
                                        </ul>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-12 col-md-12">
                                <div class="student_box">
                                    <label>What is your ethnicity?</label>
                                    <p><b>If more than one, separate ethnicities with a comma.</b></p>
                                    <div class="student_box_text">
                                        <?php if($student['Ethnicity']): ?>
                                            <p><?php echo e($student['Ethnicity']); ?></p>
                                        <?php else: ?>
                                            <p>---</p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-12 col-md-12">
                                <div class="student_box">
                                    <label>Current School:</label>
                                    <div class="student_box_text">
                                        
                                        <?php if($student['Current_School']): ?>
                                            <p><?php echo e($student['Current_School']); ?></p>
                                        <?php else: ?>
                                            <p>---</p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <?php if($student['Current_School'] == 'Not Listed'): ?>
                                <div class="col-lg-12 col-md-12">
                                    <div class="student_box">
                                        <label>If not listed, add it here:</label>
                                        <div class="student_box_text">
                                            
                                            <?php if($student['Current_School_Not_Listed']): ?>
                                                <p><?php echo e($student['Current_School_Not_Listed']); ?></p>
                                            <?php else: ?>
                                                <p>---</p>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>

                            <div class="col-lg-6 col-md-6">
                                <div class="student_box">
                                    <label>Other High School # 1: <span>(where you plan to apply)</span></label>
                                    <div class="student_box_text">
                                        <?php if($student['Other_High_School_1']): ?>
                                            <p><?php echo e($student['Other_High_School_1']); ?></p>
                                        <?php else: ?>
                                            <p>---</p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-6 col-md-6">
                                <div class="student_box">
                                    <label>Other High School # 2: <span>(where you plan to apply)</span></label>
                                    <div class="student_box_text">
                                        <?php if($student['Other_High_School_2']): ?>
                                            <p><?php echo e($student['Other_High_School_2']); ?></p>
                                        <?php else: ?>
                                            <p>---</p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-6 col-md-6">
                                <div class="student_box">
                                    <label>Other High School # 3: <span>(where you plan to apply)</span></label>
                                    <div class="student_box_text">
                                        <?php if($student['Other_High_School_3']): ?>
                                            <p><?php echo e($student['Other_High_School_3']); ?></p>
                                        <?php else: ?>
                                            <p>---</p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-6 col-md-6">
                                <div class="student_box">
                                    <label>Other High School # 4: <span>(where you plan to apply)</span></label>
                                    <div class="student_box_text">
                                        <?php if($student['Other_High_School_4']): ?>
                                            <p><?php echo e($student['Other_High_School_4']); ?></p>
                                        <?php else: ?>
                                            <p>---</p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="col-md-12">
                        <h1>No Data Found</h1>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <section class="form_two student_wrapper">
        <div class="student_detail_wrapper">
            <div class="form_student_details">
                <div class="main_heading">
                    <h2>Address Info</h2>
                </div>
                <?php $__empty_1 = true; $__currentLoopData = $addressInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $addressKey=>$address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    
                    <div class="studentWise_details">
                        <h4 class="sub_heading"><?php echo e($address['Address_Type']); ?></h4>
                        <div class="row">
                            <div class="col-lg-12 col-md-12">
                                <div class="student_box">
                                    <label>Address:</label>
                                    <div class="student_box_text">
                                        <?php if($address['Address']): ?>
                                            <p><?php echo $address['Address']; ?></p>
                                        <?php else: ?>
                                            <p>---</p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-4 col-md-6">
                                <div class="student_box">
                                    <label>City:</label>
                                    <div class="student_box_text">
                                        <?php if($address['City']): ?>
                                            <p><?php echo e($address['City']); ?></p>
                                        <?php else: ?>
                                            <p>---</p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-4 col-md-4">
                                <div class="student_box">
                                    <label>State:</label>
                                    <div class="student_box_text">
                                        <?php if($address['State']): ?>
                                            <p><?php echo e($address['State']); ?></p>
                                        <?php else: ?>
                                            <p>---</p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-4 col-md-4">
                                <div class="student_box">
                                    <label>Zipcode:</label>
                                    <div class="student_box_text">
                                        <?php if($address['Zipcode']): ?>
                                            <p><?php echo e($address['Zipcode']); ?></p>
                                        <?php else: ?>
                                            <p>---</p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-4 col-md-4">
                                <div class="student_box">
                                    <label>Phone Number:</label>
                                    <div class="student_box_text">
                                        <?php if($address['Address_Phone']): ?>
                                            <p><?php echo e($address['Address_Phone']); ?></p>
                                        <?php else: ?>
                                            <p>---</p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="col-md-12">
                        <h1>No Data Found</h1>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <section class="form_three student_wrapper">
        <div class="student_detail_wrapper">
            <div class="form_student_details">
                <div class="main_heading">
                    <h2>Parent Info</h2>
                </div>
                <?php $__empty_1 = true; $__currentLoopData = $parentInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parentKey=>$parent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    
                    <div class="studentWise_details">
                        
                        <div class="row">
                            <div class="col-lg-12 col-md-12">
                                <div class="student_box">
                                    <label>Relationship:</label>
                                    <div class="student_box_text">
                                        <?php if($parent['Relationship']): ?>
                                            <p><?php echo e($parent['Relationship']); ?></p>
                                        <?php else: ?>
                                            <p>---</p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-2 col-md-6">
                                <div class="student_box">
                                    <label>Salutation:</label>
                                    <div class="student_box_text">
                                        <?php if($parent['Salutation']): ?>
                                            <p><?php echo e($parent['Salutation']); ?></p>
                                        <?php else: ?>
                                            <p>---</p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-3 col-md-4">
                                <div class="student_box">
                                    <label>First Name:</label>
                                    <div class="student_box_text">
                                        <?php if($parent['First_Name']): ?>
                                            <p><?php echo e($parent['First_Name']); ?></p>
                                        <?php else: ?>
                                            <p>---</p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-3 col-md-4">
                                <div class="student_box">
                                    <label>Middle Name:</label>
                                    <div class="student_box_text">
                                        <?php if($parent['Middle_Name']): ?>
                                            <p><?php echo e($parent['Middle_Name']); ?></p>
                                        <?php else: ?>
                                            <p>---</p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-2 col-md-4">
                                <div class="student_box">
                                    <label>Last Name:</label>
                                    <div class="student_box_text">
                                        <?php if($parent['Last_Name']): ?>
                                            <p><?php echo e($parent['Last_Name']); ?></p>
                                        <?php else: ?>
                                            <p>---</p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-2 col-md-4">
                                <div class="student_box">
                                    <label>Suffix:</label>
                                    <div class="student_box_text">
                                        <?php if($parent['Suffix']): ?>
                                            <p><?php echo e($parent['Suffix']); ?></p>
                                        <?php else: ?>
                                            <p>---</p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-4 col-md-4">
                                <div class="student_box">
                                    <label>Address Type:</label>
                                    <div class="student_box_text">
                                        <?php if($parent['Address_Type']): ?>
                                            <p><?php echo e($parent['Address_Type']); ?></p>
                                        <?php else: ?>
                                            <p>---</p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-4 col-md-4">
                                <div class="student_box">
                                    <label>Mobile Phone:</label>
                                    <div class="student_box_text">
                                        <?php if($parent['Mobile_Phone']): ?>
                                            <p><?php echo e($parent['Mobile_Phone']); ?></p>
                                        <?php else: ?>
                                            <p>---</p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-4 col-md-4">
                                <div class="student_box">
                                    <label>Personal Email:</label>
                                    <div class="student_box_text">
                                        <?php if($parent['Personal_Email']): ?>
                                            <p><?php echo e($parent['Personal_Email']); ?></p>
                                        <?php else: ?>
                                            <p>---</p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-4 col-md-4">
                                <div class="student_box">
                                    <label>Employer:</label>
                                    <div class="student_box_text">
                                        <?php if($parent['Employer']): ?>
                                            <p><?php echo e($parent['Employer']); ?></p>
                                        <?php else: ?>
                                            <p>---</p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-8 col-md-4">
                                <div class="student_box">
                                    <label>Title:</label>
                                    <div class="student_box_text">
                                        <?php if($parent['Title']): ?>
                                            <p><?php echo e($parent['Title']); ?></p>
                                        <?php else: ?>
                                            <p>---</p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-4 col-md-4">
                                <div class="student_box">
                                    <label>Work Email:</label>
                                    <div class="student_box_text">
                                        <?php if($parent['Work_Email']): ?>
                                            <p><?php echo e($parent['Work_Email']); ?></p>
                                        <?php else: ?>
                                            <p>---</p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-4 col-md-4">
                                <div class="student_box">
                                    <label>Work Phone:</label>
                                    <div class="student_box_text">
                                        <?php if($parent['Work_Phone']): ?>
                                            <p><?php echo e($parent['Work_Phone']); ?></p>
                                        <?php else: ?>
                                            <p>---</p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-4 col-md-4">
                                <div class="student_box">
                                    <label>Work Phone Ext:</label>
                                    <div class="student_box_text">
                                        <?php if($parent['Work_Phone_Ext']): ?>
                                            <p><?php echo e($parent['Work_Phone_Ext']); ?></p>
                                        <?php else: ?>
                                            <p>---</p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-12 col-md-4">
                                <div class="student_box">
                                    <label>Schools:</label>
                                    <div class="student_box_text">
                                        <?php if($parent['Schools']): ?>
                                            <p><?php echo e($parent['Schools']); ?></p>
                                        <?php else: ?>
                                            <p>---</p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>



                            <div class="col-lg-8 col-md-12">
                                <div class="student_box">
                                    <label>Living Situation:</label>
                                    
                                    
                                    <?php
                                        $item = App\Models\LivingSituation::find($parent['Living_Situation']);
                                    ?>
                                    <div class="student_box_text">
                                        <ul>
                                            <?php if($item): ?>
                                                <li><?php echo e($item->name); ?></li>
                                            <?php else: ?>
                                                <li>---</li>
                                            <?php endif; ?>
                                        </ul>
                                    </div>

                                </div>
                            </div>

                            <div class="col-lg-4 col-md-4">
                                <div class="student_box">
                                    <label>Status:</label>
                                    <div class="student_box_text">
                                        <?php if($parent['Status']): ?>
                                            <p><?php echo e($parent['Status']); ?></p>
                                        <?php else: ?>
                                            <p>---</p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="col-md-12">
                        <h1>No Data Found</h1>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <section class="form_four student_wrapper">
        <div class="student_detail_wrapper">
            <div class="form_student_details">
                <div class="main_heading">
                    <h2>Sibling Info</h2>
                </div>
                <div class="student_box_label">
                    <label>Do you have other children? <span
                            class="children_sec"><?php echo e(count($siblingInfo) > 0 ? 'Yes' : 'No'); ?></span></label>
                </div>

                <?php if(count($siblingInfo) > 0): ?>
                    <?php $__currentLoopData = $siblingInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siblingKey => $sibling): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                        <div class="studentWise_details">
                            <h4 class="sub_heading">Child <?php echo e($siblingKey + 1); ?></h4>
                            <div class="row">
                                <div class="col-lg-3 col-md-4">
                                    <div class="student_box">
                                        <label>First Name:</label>
                                        <div class="student_box_text">
                                            <?php if($sibling['First_Name']): ?>
                                                <p><?php echo e($sibling['First_Name']); ?></p>
                                            <?php else: ?>
                                                <p>---</p>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-3 col-md-4">
                                    <div class="student_box">
                                        <label>Middle Name:</label>
                                        <div class="student_box_text">
                                            <?php if($sibling['Middle_Name']): ?>
                                                <p><?php echo e($sibling['Middle_Name']); ?></p>
                                            <?php else: ?>
                                                <p>---</p>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-3 col-md-4">
                                    <div class="student_box">
                                        <label>Last Name:</label>
                                        <div class="student_box_text">
                                            <?php if($sibling['Last_Name']): ?>
                                                <p><?php echo e($sibling['Last_Name']); ?></p>
                                            <?php else: ?>
                                                <p>---</p>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-3 col-md-4">
                                    <div class="student_box">
                                        <label>Suffix:</label>
                                        <div class="student_box_text">
                                            <?php if($sibling['Suffix']): ?>
                                                <p><?php echo e($sibling['Suffix']); ?></p>
                                            <?php else: ?>
                                                <p>---</p>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-4 col-md-12">
                                    <div class="student_box">
                                        <label>Relationship:</label>
                                        <div class="student_box_text">
                                            <?php if($sibling['Relationship']): ?>
                                                <p><?php echo e($sibling['Relationship']); ?></p>
                                            <?php else: ?>
                                                <p>---</p>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-4 col-md-4">
                                    <div class="student_box">
                                        <label>Current Grade:</label>
                                        <div class="student_box_text">
                                            <?php if($sibling['Current_Grade']): ?>
                                                <p><?php echo e($sibling['Current_Grade']); ?></p>
                                            <?php else: ?>
                                                <p>---</p>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-4 col-md-12">
                                    <div class="student_box">
                                        <label>Current School:</label>
                                        <div class="student_box_text">
                                            <?php if($sibling['Current_School']): ?>
                                                <p><?php echo e($sibling['Current_School']); ?></p>
                                            <?php else: ?>
                                                <p>---</p>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <?php if($sibling['Current_School'] == 'Not Listed'): ?>
                                    <div class="col-lg-6 col-md-12">
                                        <div class="student_box">
                                            <label>If not listed, add it here:</label>
                                            <div class="student_box_text">
                                                <p><?php echo e($sibling['Current_School_Not_Listed']); ?></p>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>

                                <div class="col-lg-6 col-md-4">
                                    <div class="student_box">
                                        <label>HS Graduation Year:</label>
                                        <div class="student_box_text">
                                            <?php if($sibling['HS_Graduation_Year']): ?>
                                                <p><?php echo e($sibling['HS_Graduation_Year']); ?></p>
                                            <?php else: ?>
                                                <p>---</p>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <section class="form_five student_wrapper">
        <div class="student_detail_wrapper">
            <div class="form_student_details">
                <div class="main_heading">
                    <h2>Legacy Info</h2>
                </div>
                <div class="student_box_label">
                    <label>Do you have family members who have attended SI? <span
                            class="children_sec"><?php echo e(count($legacyInfo) > 0 ? 'Yes' : 'No'); ?></span></label>
                </div>

                <?php if(count($legacyInfo) > 0): ?>
                    <?php $__currentLoopData = $legacyInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $legacyKey => $legacy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                        <div class="studentWise_details">
                            <h4 class="sub_heading">Legacy Relative <?php echo e($legacyKey + 1); ?></h4>
                            <div class="row">
                                <div class="col-lg-6 col-md-6">
                                    <div class="student_box">
                                        <label>First Name:</label>
                                        <div class="student_box_text">
                                            <?php if($legacy['First_Name']): ?>
                                                <p><?php echo e($legacy['First_Name']); ?></p>
                                            <?php else: ?>
                                                <p>---</p>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-6 col-md-6">
                                    <div class="student_box">
                                        <label>Last Name:</label>
                                        <div class="student_box_text">
                                            <?php if($legacy['Last_Name']): ?>
                                                <p><?php echo e($legacy['Last_Name']); ?></p>
                                            <?php else: ?>
                                                <p>---</p>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-6 col-md-6">
                                    <div class="student_box">
                                        <label>Relationship:</label>
                                        <div class="student_box_text">
                                            <?php if($legacy['Relationship']): ?>
                                                <p><?php echo e($legacy['Relationship']); ?></p>
                                            <?php else: ?>
                                                <p>---</p>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-6 col-md-6">
                                    <div class="student_box">
                                        <label>Graduation Year:</label>
                                        <div class="student_box_text">
                                            <?php if($legacy['Graduation_Year']): ?>
                                                <p><?php echo e($legacy['Graduation_Year']); ?></p>
                                            <?php else: ?>
                                                <p>---</p>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <section class="form_six student_wrapper">
        <div class="student_detail_wrapper">
            <div class="form_student_details">
                <div class="main_heading">
                    <h2>Parent Statement</h2>
                </div>
                <div class="">
                    <div class="student_box_label">
                        <label>Why do you desire St. Ignatius as a high school option for your child(ren)?</label>
                        <div class="student_box_text">
                            <?php if($parentStatement['Why_SI_for_Child']): ?>
                                <p><?php echo e($parentStatement['Why_SI_for_Child']); ?></p>
                            <?php else: ?>
                                <p>---</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <div class="form_six_parent">
                    <?php $__currentLoopData = $parentStatement['Students']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $psKey => $studentPS): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                        <div class="studentWise_details">
                            <h4 class="sub_heading"><?php echo e($studentPS['Student_name']); ?></h4>
                            <div class="row">
                                <div class="col-lg-6 col-md-6">
                                    <div class="student_box">
                                        <label>Full Name:</label>
                                        <div class="student_box_text">
                                            <?php if($studentPS['Student_name']): ?>
                                                <p><?php echo e($studentPS['Student_name']); ?></p>
                                            <?php else: ?>
                                                <p>---</p>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-12 col-md-6">
                                    <div class="student_box">
                                        <label>Explain your child's most endearing quality and an area of
                                            growth:</label>
                                        <div class="student_box_text">
                                            <?php if($studentPS['Endearing_Quality_and_Growth']): ?>
                                                <p><?php echo e($studentPS['Endearing_Quality_and_Growth']); ?></p>
                                            <?php else: ?>
                                                <p>---</p>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-12 col-md-6">
                                    <div class="student_box">
                                        <label>Please tell us something about your child, but does not appear in the
                                            application:</label>
                                        <div class="student_box_text">
                                            <?php if($studentPS['About_Child_Not_on_App']): ?>
                                                <p><?php echo e($studentPS['About_Child_Not_on_App']); ?></p>
                                            <?php else: ?>
                                                <p>---</p>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <div class="">
                    <div class="student_box_label">
                        <label>Parent Statement Submitted By:</label>
                        <div class="student_box_text">
                            <?php if($parentStatement['Parent_Statement_Submitted_By']): ?>
                                <p><?php echo e($parentStatement['Parent_Statement_Submitted_By']); ?></p>
                            <?php else: ?>
                                <p>---</p>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="student_box_label">
                        <label>Relationship to Student(s):</label>
                        <div class="student_box_text">
                            <?php if($parentStatement['Parent_Statement_Relationship']): ?>
                                <p><?php echo e($parentStatement['Parent_Statement_Relationship']); ?></p>
                            <?php else: ?>
                                <p>---</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="form_seven student_wrapper">
        <div class="student_detail_wrapper">
            <div class="form_student_details">
                <div class="main_heading">
                    <h2>Spiritual & Community Info</h2>
                </div>
                
                <div class="form_seven_box">
                    <div class="studentWise_details">
                        <h4 class="sub_heading">Religious Background</h4>
                        <div class="row">
                            <div class="col-lg-4 col-md-12">
                                <div class="student_box">
                                    <label>Applicant's Religion:</label>
                                    <div class="student_box_text">
                                        <?php if($spiritualCommunityInfo['Applicant_Religion']): ?>
                                            <p><?php echo e($spiritualCommunityInfo['Applicant_Religion']); ?></p>
                                        <?php else: ?>
                                            <p>---</p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-12">
                                <div class="student_box">
                                    <label>Church/Faith Community:</label>
                                    <div class="student_box_text">
                                        <?php if($spiritualCommunityInfo['Church_Faith_Community']): ?>
                                            <p><?php echo e($spiritualCommunityInfo['Church_Faith_Community']); ?></p>
                                        <?php else: ?>
                                            <p>---</p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-12">
                                <div class="student_box">
                                    <label>Church/Faith Community Location:</label>
                                    <div class="student_box_text">
                                        <?php if($spiritualCommunityInfo['Church_Faith_Community_Location']): ?>
                                            <p><?php echo e($spiritualCommunityInfo['Church_Faith_Community_Location']); ?></p>
                                        <?php else: ?>
                                            <p>---</p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form_seven_parent">
                            <?php $__currentLoopData = $spiritualCommunityInfo['Students']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $scKey => $studentSc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                                <div class="studentWise_details">
                                    <h4 class="sub_heading"><?php echo e($studentSc['Student_name']); ?></h4>
                                    <div class="row">
                                        <div class="col-lg-6 col-md-6">
                                            <div class="student_box">
                                                <label>Baptism Year:</label>
                                                <div class="student_box_text">
                                                    <?php if($studentSc['Baptism_Year']): ?>
                                                        <p><?php echo e($studentSc['Baptism_Year']); ?></p>
                                                    <?php else: ?>
                                                        <p>---</p>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-6">
                                            <div class="student_box">
                                                <label>Confirmation Year:</label>
                                                <div class="student_box_text">
                                                    <?php if($studentSc['Confirmation_Year']): ?>
                                                        <p><?php echo e($studentSc['Confirmation_Year']); ?></p>
                                                    <?php else: ?>
                                                        <p>---</p>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>

                <div class="form_seven_box">
                    <div class="studentWise_details">
                        <h4 class="sub_heading">Family Spirituality and Community:</h4>
                        <div class="row">
                            <div class="col-lg-12 col-md-12">
                                <div class="student_box">
                                    <label>What impact does community have in your life and how do you best support your
                                        child's school community?</label>
                                    <div class="student_box_text">
                                        <?php if($spiritualCommunityInfo['Impact_to_Community']): ?>
                                            <p><?php echo e($spiritualCommunityInfo['Impact_to_Community']); ?></p>
                                        <?php else: ?>
                                            <p>---</p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-12 col-md-12">
                                <div class="student_box">
                                    <label>How would you describe your family's spirituality?</label>
                                    <div class="student_box_text">
                                        <ul>
                                            <?php if($spiritualCommunityInfo['Describe_Family_Spirituality']): ?>
                                                <?php $__empty_1 = true; $__currentLoopData = $spiritualCommunityInfo['Describe_Family_Spirituality']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dfsKey => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                    <?php
                                                        //$item = App\Models\Spirituality::find($dfsKey);
                                                    ?>
                                                    <li><?php echo e($value); ?></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                    <li>---</li>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        </ul>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-12 col-md-12">
                                <div class="student_box">
                                    <label>Describe in more detail the practice(s) checked above:</label>
                                    <div class="student_box_text">
                                        <?php if($spiritualCommunityInfo['Describe_Practice_in_Detail']): ?>
                                            <p><?php echo e($spiritualCommunityInfo['Describe_Practice_in_Detail']); ?></p>
                                        <?php else: ?>
                                            <p>---</p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <p>Will you encourage your child to proactively participate in the following activities?</p>

                            <div class="col-lg-6 col-md-6">
                                <div class="student_box">
                                    <label>Religious Studies Classes:</label>
                                    <div class="student_box_text">
                                        <?php if($spiritualCommunityInfo['Religious_Studies_Classes']): ?>
                                            <p><?php echo e($spiritualCommunityInfo['Religious_Studies_Classes']); ?></p>
                                        <?php else: ?>
                                            <p>---</p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <?php if($spiritualCommunityInfo['Religious_Studies_Classes'] == 'No' ||
                                $spiritualCommunityInfo['Religious_Studies_Classes'] == 'Unsure'): ?>
                                <div class="col-lg-6 col-md-6">
                                    <div class="student_box">
                                        <label>Religious Studies Classes Explanation (If No/Unsure):</label>
                                        <div class="student_box_text">
                                            <?php if($spiritualCommunityInfo['Religious_Studies_Classes_Explanation']): ?>
                                                <p><?php echo e($spiritualCommunityInfo['Religious_Studies_Classes_Explanation']); ?>

                                                </p>
                                            <?php else: ?>
                                                <p>---</p>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>

                            <div class="col-lg-6 col-md-6">
                                <div class="student_box">
                                    <label>School Liturgies:</label>
                                    <div class="student_box_text">
                                        <?php if($spiritualCommunityInfo['School_Liturgies']): ?>
                                            <p><?php echo e($spiritualCommunityInfo['School_Liturgies']); ?></p>
                                        <?php else: ?>
                                            <p>---</p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <?php if($spiritualCommunityInfo['School_Liturgies'] == 'No' ||
                                $spiritualCommunityInfo['School_Liturgies'] == 'Unsure'): ?>
                                <div class="col-lg-6 col-md-6">
                                    <div class="student_box">
                                        <label>School Liturgies Explanation (If No/Unsure):</label>
                                        <div class="student_box_text">
                                            <?php if($spiritualCommunityInfo['School_Liturgies_Explanation']): ?>
                                                <p><?php echo e($spiritualCommunityInfo['School_Liturgies_Explanation']); ?></p>
                                            <?php else: ?>
                                                <p>---</p>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>

                            <div class="col-lg-6 col-md-6">
                                <div class="student_box">
                                    <label>Retreats:</label>
                                    <div class="student_box_text">
                                        <?php if($spiritualCommunityInfo['Retreats']): ?>
                                            <p><?php echo e($spiritualCommunityInfo['Retreats']); ?></p>
                                        <?php else: ?>
                                            <p>---</p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <?php if($spiritualCommunityInfo['Retreats'] == 'No' || $spiritualCommunityInfo['Retreats'] == 'Unsure'): ?>
                                <div class="col-lg-6 col-md-6">
                                    <div class="student_box">
                                        <label>Retreats Explanation (If No/Unsure):</label>
                                        <div class="student_box_text">
                                            <?php if($spiritualCommunityInfo['Retreats_Explanation']): ?>
                                                <p><?php echo e($spiritualCommunityInfo['Retreats_Explanation']); ?></p>
                                            <?php else: ?>
                                                <p>---</p>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>

                            <div class="col-lg-6 col-md-6">
                                <div class="student_box">
                                    <label>Community Service:</label>
                                    <div class="student_box_text">
                                        <?php if($spiritualCommunityInfo['Community_Service']): ?>
                                            <p><?php echo e($spiritualCommunityInfo['Community_Service']); ?></p>
                                        <?php else: ?>
                                            <p>---</p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <?php if($spiritualCommunityInfo['Community_Service'] == 'No' ||
                                $spiritualCommunityInfo['Community_Service'] == 'Unsure'): ?>
                                <div class="col-lg-6 col-md-6">
                                    <div class="student_box">
                                        <label>Community Service Explanation (If No/Unsure):</label>
                                        <div class="student_box_text">
                                            <?php if($spiritualCommunityInfo['Community_Service_Explanation']): ?>
                                                <p><?php echo e($spiritualCommunityInfo['Community_Service_Explanation']); ?></p>
                                            <?php else: ?>
                                                <p>---</p>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <div class="form_seven_box">
                    <div class="student_box_label">
                        <label>Religious Form Submitted By:</label>
                        <div class="student_box_text">
                            <?php if($spiritualCommunityInfo['Religious_Form_Submitted_By']): ?>
                                <p><?php echo e($spiritualCommunityInfo['Religious_Form_Submitted_By']); ?></p>
                            <?php else: ?>
                                <p>---</p>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="student_box_label">
                        <label>Relationship to Student(s):</label>
                        <div class="student_box_text">
                            <?php if($spiritualCommunityInfo['Religious_Form_Relationship']): ?>
                                <p><?php echo e($spiritualCommunityInfo['Religious_Form_Relationship']); ?></p>
                            <?php else: ?>
                                <p>---</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="form_eight student_wrapper">
        <div class="student_detail_wrapper">
            <div class="form_student_details">
                <div class="main_heading">
                    <h2>Student Statement</h2>
                </div>
                
                <div class="form_eight_box">
                    <div class="studentWise_details">
                        <h4 class="sub_heading">Student Statement</h4>
                        <div class="form_eight_box-wrapper">
                            <?php $__currentLoopData = $studentStatementInfo['Students_Statement']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ssKey => $studentSS): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="row form_eight_box-wrapper-row">
                                    <h4 class="sub_heading"><?php echo e($studentSS['Student_name']); ?></h4>
                                    <div class="col-lg-12 col-md-12">
                                        <div class="student_box">
                                            <label>Why did you decide to apply to St. Ignatius College
                                                Preparatory?</label>
                                            <div class="student_box_text">
                                                <?php if($studentSS['Why_did_you_decide_to_apply_to_SI']): ?>
                                                    <p><?php echo e($studentSS['Why_did_you_decide_to_apply_to_SI']); ?></p>
                                                <?php else: ?>
                                                    <p>---</p>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-12 col-md-12">
                                        <div class="student_box">
                                            <label>What do you think will be your greatest challenge at SI and how do
                                                you
                                                plan to meet that challenge?</label>
                                            <div class="student_box_text">
                                                <?php if($studentSS['Greatest_Challenge']): ?>
                                                    <p><?php echo e($studentSS['Greatest_Challenge']); ?></p>
                                                <?php else: ?>
                                                    <p>---</p>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-12 col-md-12">
                                        <div class="student_box">
                                            <label>What religious activity(-ies) do you plan on participating in at SI
                                                as
                                                part of your spiritual growth and why?</label>
                                            <div class="student_box_text">
                                                <?php if($studentSS['Religious_Activities_for_Growth']): ?>
                                                    <p><?php echo e($studentSS['Religious_Activities_for_Growth']); ?></p>
                                                <?php else: ?>
                                                    <p>---</p>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-12 col-md-12">
                                        <div class="student_box">
                                            <label>What is your favorite subject in school and why? What subject do you
                                                find
                                                the most difficult and why?</label>
                                            <div class="student_box_text">
                                                <?php if($studentSS['Favorite_and_most_difficult_subjects']): ?>
                                                    <p><?php echo e($studentSS['Favorite_and_most_difficult_subjects']); ?></p>
                                                <?php else: ?>
                                                    <p>---</p>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>

                <div class="form_eight_box">
                    <div class="studentWise_details">
                        <h4 class="sub_heading">Extracurricular Activities</h4>
                        <div class="">
                            <?php $__currentLoopData = $studentStatementInfo['Extracurricular_Activities']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eaKey => $eActivities): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                                <div class="form_eight_box-wrapper">
                                    <h4 class="sub_heading"><?php echo e($eActivities['Student_name']); ?></h4>

                                    <?php $__currentLoopData = $eActivities['Activity']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aKey => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="form_eignt_activity">
                                            <h4 class="sub_heading">Activity <?php echo e($aKey + 1); ?></h4>
                                            <div class="row form_eight_box-wrapper-row">
                                                <div class="col-lg-4 col-md-6">
                                                    <div class="student_box">
                                                        <label>Activity Name:</label>
                                                        <div class="student_box_text">
                                                            <?php if($item['Activity_Name']): ?>
                                                                <p><?php echo e($item['Activity_Name']); ?></p>
                                                            <?php else: ?>
                                                                <p>---</p>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-lg-4 col-md-12">
                                                    <div class="student_box">
                                                        <label>Number of Years:</label>
                                                        <div class="student_box_text">
                                                            <?php if($item['Number_of_Years']): ?>
                                                                <p><?php echo e($item['Number_of_Years']); ?></p>
                                                            <?php else: ?>
                                                                <p>---</p>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-lg-4 col-md-12">
                                                    <div class="student_box">
                                                        <label>Hours per Week:</label>
                                                        <div class="student_box_text">
                                                            <?php if($item['Hours_Per_Week']): ?>
                                                                <p><?php echo e($item['Hours_Per_Week']); ?></p>
                                                            <?php else: ?>
                                                                <p>---</p>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-lg-12 col-md-6">
                                                    <div class="student_box">
                                                        <label>Share a little information about this activity:</label>
                                                        <div class="student_box_text">
                                                            <?php if($item['Info_about_activity']): ?>
                                                                <p><?php echo $item['Info_about_activity']; ?></p>
                                                            <?php else: ?>
                                                                <p>---</p>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>

                <div class="form_eight_box">
                    <div class="studentWise_details">
                        <h4 class="sub_heading">Future Activities at SI</h4>
                        <div class="form_eight_box-wrapper">
                            <?php $__currentLoopData = $studentStatementInfo['Future_Activities']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faKey => $fActivitie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="row form_eignt_activity">
                                    <h4 class="sub_heading"><?php echo e($fActivitie['Student_name']); ?></h4>
                                    <div class="col-lg-12 col-md-12">
                                        <div class="student_box">
                                            <label>From your activities listed above, select the activity you are most
                                                passionate about continuing at SI and describe what you feel you would
                                                contribute to this activity.</label>
                                            <div class="student_box_text">
                                                <?php if($fActivitie['Most_Passionate_Activity']): ?>
                                                    <p><?php echo e($fActivitie['Most_Passionate_Activity']); ?></p>
                                                <?php else: ?>
                                                    <p>---</p>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-12 col-md-12">
                                        <div class="student_box">
                                            <label>Select two more extra-curricular activities that you might like to be
                                                involved in at SI.</label>
                                            <p>Explain why these activities appeal to you. Please make sure at least one
                                                of
                                                these activities is new to you.</p>
                                            <div class="student_box_text">
                                                <?php if($fActivitie['Extracurricular_Activity_at_SI']): ?>
                                                    <p><?php echo e($fActivitie['Extracurricular_Activity_at_SI']); ?></p>
                                                <?php else: ?>
                                                    <p>---</p>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="form_nine student_wrapper">
        <div class="student_detail_wrapper">
            <div class="form_student_details">
                <div class="main_heading">
                    <h2>Applicant Writing Sample</h2>
                </div>
                
                <?php $__empty_1 = true; $__currentLoopData = $writingSample; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wsKey=>$writing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="studentWise_details">
                        <h4 class="sub_heading"><?php echo e($writing['Student_name']); ?></h4>
                        <div class="row">
                            <div class="col-lg-12 col-md-12">
                                <div class="student_box">
                                    <label>What matters to you? How does that motivate you, impact your life, your outlook, and/or your identity?</label>
                                    <p>What matters to you might be an activity, an idea, a goal, a place, and/or a thing.</p>
                                    <center><p><b>&#8212; OR &#8212;</b></p></center>
                                    <label>An obstacle you have overcome.</label>
                                    <p>Explain how the obstacle impacted you and how you handled the situation (i.e.,
                                        positive and/or negative attempts along the way or maybe how you're still
                                        working on it) .</p>
                                    <p>Include what you have learned from the experience and how you have applied (or
                                        might apply) this to another situation in your life.</p>
                                    <div class="student_box_text">
                                        <?php if($writing['Writing_Sample']): ?>
                                            <p><?php echo $writing['Writing_Sample']; ?></p>
                                        <?php else: ?>
                                            <p>---</p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-4">
                                <div class="student_box">
                                    <label>Writing Sample Acknowledgment:</label>
                                    <div class="student_box_text">
                                        <?php if($writing['Writing_Sample_Acknowledgment']): ?>
                                            <p>Yes</p>
                                        <?php else: ?>
                                            <p>---</p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-6 col-md-6">
                                <div class="student_box">
                                    <label>Submitted By:</label>
                                    <div class="student_box_text">
                                        <?php if($writing['Writing_Sample_Submitted_By']): ?>
                                            <p><?php echo e($writing['Writing_Sample_Submitted_By']); ?></p>
                                        <?php else: ?>
                                            <p>---</p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="col-md-12">
                        <h1>No Data Found</h1>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <section class="form_ten student_wrapper">
        <div class="student_detail_wrapper">
            <div class="form_student_details">
                <div class="main_heading">
                    <h2>Final Step</h2>
                </div>
                
                <div class="">
                    <div class="studentWise_details">
                        <h4 class="sub_heading">Entrance Exam Information</h4>
                        <?php $__currentLoopData = $releaseAuthorization['EntranceExamInfo']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $raKey => $authorization): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="final_step_wrapper">
                                <h4 class="sub_heading"><?php echo e($authorization['Student_name']); ?></h4>
                                <p>Indicate the date and the high school where your child(ren) will take the entrance
                                    exam.
                                </p>
                                <?php if($authorization['Entrance_Exam_Reservation'] == '0'): ?>
                                    <div class="row">
                                        <div class="col-lg-12 col-md-12">
                                            <div class="student_box">
                                                <label>At Other Catholic High School</label>
                                            </div>
                                        </div>
                                        <div class="col-lg-12 col-md-12">
                                            <div class="student_box">
                                                <label>Other Catholic School Name:</label>
                                                <div class="student_box_text">
                                                    <?php if($authorization['Other_Catholic_School_Name']): ?>
                                                        <p><?php echo e($authorization['Other_Catholic_School_Name']); ?></p>
                                                    <?php else: ?>
                                                        <p>---</p>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-12 col-md-12">
                                            <div class="student_box">
                                                <label>Other Catholic School Location:</label>
                                                <div class="student_box_text">
                                                    <?php if($authorization['Other_Catholic_School_Location']): ?>
                                                        <p><?php echo e($authorization['Other_Catholic_School_Location']); ?></p>
                                                    <?php else: ?>
                                                        <p>---</p>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-12 col-md-12">
                                            <div class="student_box">
                                                <label>Other Catholic School Date:</label>
                                                <div class="student_box_text">
                                                    <?php if($authorization['Other_Catholic_School_Date']): ?>
                                                        <p><?php echo e($authorization['Other_Catholic_School_Date']); ?></p>
                                                    <?php else: ?>
                                                        <p>---</p>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php else: ?>
                                    <div class="row">
                                        <div class="col-lg-12 col-md-12">
                                            <div class="student_box">
                                                <label>At SI on December 3, 2022</label>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

                <div class="">
                    <div class="studentWise_details">
                        <h4 class="sub_heading">Release Authorization</h4>
                        <div class="row">
                            <div class="col-lg-6 col-md-6">
                                <div class="student_box">
                                    <label>Agree to release record ?</label>
                                    <div class="student_box_text">
                                        <?php if($releaseAuthorization['Agree_to_release_record']): ?>
                                            <p>Agree</p>
                                        <?php else: ?>
                                            <p>---</p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-12 col-md-12">
                                <div class="student_box">
                                    <label>Agree to record is true ?</label>
                                    <div class="student_box_text">
                                        <?php if($releaseAuthorization['Agree_to_record_is_true']): ?>
                                            <p>Agree</p>
                                        <?php else: ?>
                                            <p>---</p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-12 col-md-12">
                                <div class="student_box">
                                    <label>Transaction Amount:</label>
                                    <div class="student_box_text">
                                        <?php if($releaseAuthorization['Amount']): ?>
                                            <p>$<?php echo e($releaseAuthorization['Amount']); ?></p>
                                        <?php else: ?>
                                            <p>---</p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-12 col-md-12">
                                <div class="student_box">
                                    <label>Transaction ID:</label>
                                    <div class="student_box_text">
                                        <?php if($releaseAuthorization['Transaction_ID']): ?>
                                            <p><?php echo e($releaseAuthorization['Transaction_ID']); ?></p>
                                        <?php else: ?>
                                            <p>---</p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
<?php /**PATH /var/www/html/admission-portal-web-1854/resources/views/livewire/frontend/application/view-application.blade.php ENDPATH**/ ?>