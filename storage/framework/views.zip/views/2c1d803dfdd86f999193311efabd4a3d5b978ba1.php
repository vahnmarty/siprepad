
<?php $__env->startSection('title', __('page_title.edit_personal_info_page_title')); ?>
<?php $__env->startSection('content'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('frontend.profile.edit-profile', [])->html();
} elseif ($_instance->childHasBeenRendered('8sfYhM7')) {
    $componentId = $_instance->getRenderedChildComponentId('8sfYhM7');
    $componentTag = $_instance->getRenderedChildComponentTagName('8sfYhM7');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('8sfYhM7');
} else {
    $response = \Livewire\Livewire::mount('frontend.profile.edit-profile', []);
    $html = $response->html();
    $_instance->logRenderedChild('8sfYhM7', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/admission-portal-web-1854/resources/views/frontend/profile/edit-profile.blade.php ENDPATH**/ ?>