<?php $__env->startSection('title', __('page_title.home_page_title')); ?>
<?php $__env->startSection('content'); ?>
	<div class="home-wrap">
        <div class="hme-inr">
        	<h3>Notification</h3>
        	<ul class="ntf-ul">
        	<?php if($notifications->is_read == 1): ?>
        	 <li class='ntf-li'><a href='<?php echo e(url("/notification/show")); ?>/<?php echo e($notifications->id); ?>' class="read"><?php echo e($notifications->message); ?></a></li>
        	<?php else: ?>
        			<li class='ntf-li'><a href='<?php echo e(url("/notification/show")); ?>/<?php echo e($notifications->id); ?>'><?php echo e($notifications->message); ?></a></li>
        	<?php endif; ?>

        	</ul>
        </div>
    </div>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/admission-portal-web-1854/resources/views/frontend/notification.blade.php ENDPATH**/ ?>