<?php $__env->startSection('title', __('page_title.home_page_title')); ?>
<?php $__env->startSection('content'); ?>
    <div class="home-wrap">
        <div class="hme-inr">
            <h3>Welcome, <span><?php echo e(Auth::guard('customer')->user()->full_name); ?></span></h3>
            <ul class="hme-ul">
            <?php
            $uid=Auth::guard('customer')->user()->id;
                 $getProfile = App\Models\Profile::find($uid)->first();
                
            ?>  
         
    
  <?php if(!empty($registerable)): ?>
                       <?php if($registerable == App\Models\GlobalRegisterable::Registeration_ON): ?>
                          <?php if(!empty($application_status)): ?>
                          <?php if($application_status->s1_candidate_status == App\Models\Application::CANDIDATE_ACCEPTED||$application_status->s2_candidate_status == App\Models\Application::CANDIDATE_ACCEPTED
                          ||$application_status->s3_candidate_status == App\Models\Application::CANDIDATE_ACCEPTED): ?>
                          
            <li>
                    
                        <a href="<?php echo e(route('registration.create')); ?>">

                            <em>
                                <img src="<?php echo e(asset('frontend_assets/images/j2.svg')); ?>" alt="" />
                            </em>
                            <p>Online Registeration</p>
                            <span>
                                <img src="<?php echo e(asset('frontend_assets/images/rgt-arrw.svg')); ?>"alt="" />
                            </span>
                        </a>
                    </li>
                      <?php endif; ?>
                        <?php endif; ?>
                    <?php endif; ?>
 <?php endif; ?>
              
                  
            <?php if($notifications  == App\Models\Global_Notifiable::NOTIFICATION_ON): ?>
             <?php if(!empty($application_status)): ?>
             
            <li>
                    <a target="_blank" href="<?php echo e(url('/notification')); ?>">

                        <em>
                            <img src="<?php echo e(asset('frontend_assets/images/j1.svg')); ?>" alt="" />
                        </em>
                        <p>Notification</p>
                        <span>
                            <img src="<?php echo e(asset('frontend_assets/images/rgt-arrw.svg')); ?>" alt="" />
                        </span>
                    </a>
                </li>
<?php endif; ?>
            <?php endif; ?> 	    

                <li>
                    <a target="_blank" href="https://www.siprep.org/admissions/visit/wildcat-experience">
                        <em>
                            <img src="<?php echo e(asset('frontend_assets/images/j1.svg')); ?>" alt="" />
                        </em>
                        <p>Book a Wildcat Experience</p>
                        <span>
                            <img src="<?php echo e(asset('frontend_assets/images/rgt-arrw.svg')); ?>" alt="" />
                        </span>
                    </a>
                </li>
                <?php if($application): ?>
                    <?php if($application->status ==App\Models\Application::CANDIDATE_ACCEPTED): ?>
                        <li>
                            <a href="<?php echo e(route('view-application', ['application_id' => $application->Application_ID])); ?>">
                                <em>
                                    <img src="<?php echo e(asset('frontend_assets/images/j2.svg')); ?>" alt="" />
                                </em>
                                <p>View Application</p>
                                <span>
                                    <img src="<?php echo e(asset('frontend_assets/images/rgt-arrw.svg')); ?>" alt="" />
                                </span>
                            </a>
                        </li>
                    <?php else: ?>
                        <?php
                            if ($application->last_step_complete) {
                                $step = $application->last_step_complete;
                            } else {
                                $step = 'one';
                            }

                        ?>
                        <li>
                            <a href="<?php echo e(route('admission-application', ['step' => $step])); ?>">
                                <em>
                                    <img src="<?php echo e(asset('frontend_assets/images/j2.svg')); ?>" alt="" />
                                </em>
                                <p>Admissions Application</p>
                                <span>
                                    <img src="<?php echo e(asset('frontend_assets/images/rgt-arrw.svg')); ?>" alt="" />
                                </span>
                            </a>
                        </li>
                    <?php endif; ?>
                <?php else: ?>
                    <li>
                        <a href="<?php echo e(route('admission-application')); ?>">
                            <em>
                                <img src="<?php echo e(asset('frontend_assets/images/j2.svg')); ?>" alt="" />
                            </em>
                            <p>Admissions Application</p>
                            <span>
                                <img src="<?php echo e(asset('frontend_assets/images/rgt-arrw.svg')); ?>" alt="" />
                            </span>
                        </a>
                    </li>
                <?php endif; ?>

                <li>
                    <a target="_blank" href="https://www.siprep.org/admissions/apply/admissions-video">
                        <em>
                            <img src="<?php echo e(asset('frontend_assets/images/videoplayer.svg')); ?>" alt="" />
                        </em>
                        <p>Admissions Video</p>
                        <span>
                            <img src="<?php echo e(asset('frontend_assets/images/rgt-arrw.svg')); ?>" alt="" />
                        </span>
                    </a>
                </li>

                <?php if($application): ?>
                    <li>
                        <?php if($getStudentCount == 0): ?>
                            <a class="disabled_btn_text" style="color: #99adef"
                                href="<?php echo e(route('supplemental-recommendation')); ?>">
                                <em>
                                    <img src="<?php echo e(asset('frontend_assets/images/j3.svg')); ?>" alt="" />
                                </em>
                                <p>Supplemental Recommendation</p>
                                <span>
                                    <img src="<?php echo e(asset('frontend_assets/images/rgt-arrw.svg')); ?>"alt="" />
                                </span>
                            </a>
                        <?php else: ?>
                            <a href="<?php echo e(route('supplemental-recommendation')); ?>">
                                <em>
                                    <img src="<?php echo e(asset('frontend_assets/images/j3.svg')); ?>" alt="" />
                                </em>
                                <p>Supplemental Recommendation</p>
                                <span>
                                    <img src="<?php echo e(asset('frontend_assets/images/rgt-arrw.svg')); ?>"alt="" />
                                </span>
                            </a>
                        <?php endif; ?>

                    </li>
                <?php else: ?>
                    <li>
                        <a href="<?php echo e(route('supplemental-recommendation')); ?>">
                            <em>
                                <img src="<?php echo e(asset('frontend_assets/images/j3.svg')); ?>" alt="" />
                            </em>
                            <p>Supplemental Recommendation</p>
                            <span>
                                <img src="<?php echo e(asset('frontend_assets/images/rgt-arrw.svg')); ?>"alt="" />
                            </span>
                        </a>
                    </li>
                <?php endif; ?>

            </ul>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/admission-portal-web-1854/resources/views/frontend/home.blade.php ENDPATH**/ ?>