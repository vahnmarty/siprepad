<?php $__env->startPush('css'); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('frontend.registeration.registeration-seven', ['regId' => $reg_id,'reg_id' => $reg_id])->html();
} elseif ($_instance->childHasBeenRendered('wpYFmox')) {
    $componentId = $_instance->getRenderedChildComponentId('wpYFmox');
    $componentTag = $_instance->getRenderedChildComponentTagName('wpYFmox');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('wpYFmox');
} else {
    $response = \Livewire\Livewire::mount('frontend.registeration.registeration-seven', ['regId' => $reg_id,'reg_id' => $reg_id]);
    $html = $response->html();
    $_instance->logRenderedChild('wpYFmox', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.frontend-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/admission-portal-web-1854/resources/views/frontend/registeration/registeration-seven.blade.php ENDPATH**/ ?>