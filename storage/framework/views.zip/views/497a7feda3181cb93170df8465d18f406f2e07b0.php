<?php $__env->startPush('css'); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('healthInfoUpdate',$profile->id)); ?>" method="POST">
<?php echo csrf_field(); ?>
<?php echo method_field('POST'); ?>
	<div class="home-wrap hme-wrp2">
		<div class="progress-outr"></div>
		<div class="form-outr">

			<div class="form-outr">
				<div class="cmn-hdr">

					<h4>Health Information</h4>
				</div>

				<div class="school-wrap step__two">
					<div class="form-wrap">
						<div class="row">
							<div style="text-align: right" class="col-lg-4">
								<label>Medical Insurance Company</label>
							</div>
							<div class="col-lg-6">
								<div class="form-group">
									<input type="text" class="form-control"
										name='medical_insurance_company'   value="<?php echo e($healthinfo->medical_insurance_company); ?>" />
									<?php $__errorArgs = ['medical_insurance_company'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<p class="text-danger"><?php echo e($message); ?></p>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <?php $__errorArgs = ['live_with'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<p class="text-danger"><?php echo e($message); ?></p>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
								</div>
							</div>

						</div>
						<div class="row">
							<div style="text-align: right" class="col-lg-4">
								<label>Medical Policy Number</label>
							</div>
							<div class="col-lg-6">
								<div class="form-group">
								<input type="text" class="form-control"
										name='medical_policy_number'   value="<?php echo e($healthinfo->medical_policy_number); ?>" />
									<?php $__errorArgs = ['medical_policy_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<p class="text-danger"><?php echo e($message); ?></p>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <?php $__errorArgs = ['live_with'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<p class="text-danger"><?php echo e($message); ?></p>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
								</div>
							</div>

						</div>

						<div class="row">
							<div style="text-align: right" class="col-lg-4">
								<label>Physician's Name</label>
							</div>
							<div class="col-lg-6">
								<div class="form-group">
									<input type="text" class="form-control"
										name='physician_name'  value="<?php echo e($healthinfo->physician_name); ?>" /> <?php $__errorArgs = ['physician_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<p class="text-danger"><?php echo e($message); ?></p>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <?php $__errorArgs = ['live_with'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<p class="text-danger"><?php echo e($message); ?></p>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
								</div>
							</div>

						</div>
						<div class="row">
							<div style="text-align: right" class="col-lg-4">
								<label>Physician's Phone</label>
							</div>
							<div class="col-lg-6">
								<div class="form-group" style="display:flex">
									<input type="number" class="form-control"
										name='physician_phone1'   value=""style="width:25%;margin-right:5px;" max="3"/> <br><?php $__errorArgs = ['physician_phone1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<p class="text-danger" ><?php echo e($message); ?></p>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
									
									<input type="number" class="form-control"
										name='physician_phone2' style="width:25%"   value="" max="3"/><br> <?php $__errorArgs = ['physician_phone2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<p class="text-danger"><?php echo e($message); ?></p>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
									
									<input type="number" class="form-control"
										name='physician_phone3' style="width:25%;margin-left:5px;"   value="" max="4"/><br> <?php $__errorArgs = ['physician_phone3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<p class="text-danger"><?php echo e($message); ?></p>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
									
								</div>						
								
							</div>
						
						</div>
						<div class="row">
							<div class="col-md-2"></div>
							<div class="col-lg-6">
								<label>Prescribed Medications, Time and Dosages (If not
									applicable , type "none"):</label>
								<div class="form-group">
									<textarea rows="8" cols="10" maxlength="1000"
										name='prescribed_medication' ><?php echo e($healthinfo->prescribed_medication); ?>

                                      </textarea>
									<?php $__errorArgs = ['prescribed_medication'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<p class="text-danger"><?php echo e($message); ?></p>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <?php $__errorArgs = ['live_with'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<p class="text-danger"><?php echo e($message); ?></p>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
								</div>
							</div>

						</div>
						<div class="row">
							<div class="col-md-2"></div>
							<div class="col-lg-6">
								<label>Allergies (Drug ,Food , etc.) and other Dietry
									Restrictions (If not applicable , type "none"): </label>
								<div class="form-group">
									<textarea rows="8" cols="10" maxlength="1000"
										name='allergies'> <?php echo e($healthinfo->allergies); ?>

                                      </textarea>
									<?php $__errorArgs = ['allergies'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<p class="text-danger"><?php echo e($message); ?></p>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <?php $__errorArgs = ['live_with'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<p class="text-danger"><?php echo e($message); ?></p>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
								</div>
							</div>

						</div>
						<div class="row">
							<div class="col-md-2"></div>
							<div class="col-lg-6">
								<label>Please list anything that you would like to share with us
									regarding your child's physical or mental health that we should
									know about in order to best support your child. (If not
									applicable, type "none"):</label>
								<div class="form-group">
									<textarea rows="8" cols="10" maxlength="1000"
										name='child_condition'> <?php echo e($healthinfo->child_condition); ?>

                                      </textarea>
									<?php $__errorArgs = ['child_condition'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<p class="text-danger"><?php echo e($message); ?></p>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <?php $__errorArgs = ['live_with'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<p class="text-danger"><?php echo e($message); ?></p>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
								</div>
							</div>

						</div>
					</div>
				</div>
			</div>

		</div>

		<div class="flx">
			<div class="form-btn text-end mt">
				<a href="<?php echo e(route('householdIndex',['id' => $healthinfo->profile_id])); ?>" class="sub-btn">Previous</a>
			</div>
			<div class="form-btn text-end mt">
				<button type="submit" value="Next" class="sub-btn">Next/Save</button>
			</div>
		</div>


	</div>
</form>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.frontend-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/admission-portal-web-1854/resources/views/frontend/registeration/registeration-three-update.blade.php ENDPATH**/ ?>