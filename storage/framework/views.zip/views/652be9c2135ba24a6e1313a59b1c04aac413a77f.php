<footer class="ftr-sec">
    <div class="container">
        <div class="ftr-outr text-center">
            <a href="#" class="ftr-logo">
                <img src="<?php echo e(asset('frontend_assets/images/ftr-logo.png')); ?>" alt="" />
            </a>
            <p class="copyright">
                © 2022 <a href="https://www.siprep.org">St. Ignatius College Preparatory</a>.&nbsp;&nbsp;All rights reserved.
            </p>
        </div>
    </div>
    <div class="ball">
        <img src="<?php echo e(asset('frontend_assets/images/ball.png')); ?>" alt="" />
    </div>
</footer>
<?php /**PATH /var/www/html/admission-portal-web-1854/resources/views/layouts/footer.blade.php ENDPATH**/ ?>