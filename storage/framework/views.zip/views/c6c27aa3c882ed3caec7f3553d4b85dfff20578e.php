<?php $__env->startPush('css'); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('frontend.registeration.registeration-four', ['regId' => $reg_id,'reg_id' => $reg_id])->html();
} elseif ($_instance->childHasBeenRendered('T2DK18L')) {
    $componentId = $_instance->getRenderedChildComponentId('T2DK18L');
    $componentTag = $_instance->getRenderedChildComponentTagName('T2DK18L');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('T2DK18L');
} else {
    $response = \Livewire\Livewire::mount('frontend.registeration.registeration-four', ['regId' => $reg_id,'reg_id' => $reg_id]);
    $html = $response->html();
    $_instance->logRenderedChild('T2DK18L', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.frontend-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/admission-portal-web-1854/resources/views/frontend/registeration/registeration-four.blade.php ENDPATH**/ ?>