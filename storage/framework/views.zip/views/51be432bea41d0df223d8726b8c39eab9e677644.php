<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <title><?php echo e(__('page_title.register_page_title')); ?></title>

    <!-- fabicon -->
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('frontend_assets/images/favi.png')); ?>" />
    <!-- All CSS -->

    <!-- fontawesome -->
    <link rel="stylesheet" href="<?php echo e(asset('frontend_assets/css/all.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('frontend_assets/css/brands.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('frontend_assets/css/fontawesome.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('frontend_assets/css/regular.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('frontend_assets/css/solid.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('frontend_assets/css/slick.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('frontend_assets/css/slick-theme.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('frontend_assets/css/bootstrap.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('frontend_assets/css/style.css')); ?>" />
    <!-- custom css-->
    <?php echo $__env->yieldPushContent('css'); ?>
    <link rel="stylesheet" type="text/css"
        href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <?php echo \Livewire\Livewire::styles(); ?>


</head>

<body>
    <div class="body-wrap" style="background-image: url(<?php echo e(asset('frontend_assets/images/body-back.png')); ?>)">
        <section class="acnt-sec">
            <div class="container">
                <div class="acnt-wrap">
                    <a href="/" class="logo">
                        <img src="<?php echo e(asset('frontend_assets/images/lg2.png')); ?>" alt="" /></a>
                    <div class="form-outr">
                        <div class="cmn-hdr">
                            <h1>Create Account</h1>
                            
                            
                            <p class = "str">
                                NOTE:&nbsp;&nbsp;Please use one username/email for one family account.&nbsp;&nbsp;For example, if you have
                                twins, triplets or a blended family with step-siblings, you may create one family
                                account and submit all applications within that one family account.
                            </p>
                            <div class="cmn-hdr">
                                <p class="str">
                                    Your password must have:
                                </p>
                                <ul>
                                    <li>At least 1 uppercase letter </li>
                                    <li>At least 1 lowercase letter </li>
                                    <li>At least 1 number </li>
                                    <li>At least 1 special character (only use the following characters: ! @ # $ or %) </li>
                                    <li>Must be between 8 – 16 characters long </li>
                                </ul>
                            </div>
                        </div>
                        <div class="form-wrap m-form-wrap">
                            <form method="POST" action="<?php echo e(route('register.post')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <input type="text" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        placeholder="Parent/Guardian First Name" name="first_name"
                                        value="<?php echo e(old('first_name')); ?>" />
                                    <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="error error_text"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        placeholder="Parent/Guardian Last Name" name="last_name"
                                        value="<?php echo e(old('last_name')); ?>" />
                                    <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="error error_text"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        placeholder="Parent/Guardian Email" name="email"
                                        value="<?php echo e(old('email')); ?>" />
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="error error_text"><?php echo $message; ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="form-group">
                                    <input type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        placeholder="Password" name="password" />
                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="error error_text"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group mb-5">
                                    <input type="password"
                                        class="form-control <?php $__errorArgs = ['confirm_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        placeholder="Confirm Password" name="confirm_password" />
                                    <?php $__errorArgs = ['confirm_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="error error_text"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-btn text-center">
                                    <input type="submit" value="Register" class="sub-btn" />
                                </div>
                                <p class="log">Have an account?&nbsp;&nbsp;<a href="<?php echo e(route('login.get')); ?>">Log in</a></p>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <footer class="ftr-sec">
            <div class="container">
                <div class="ftr-outr text-center">
                    <a href="#" class="ftr-logo"><img src="<?php echo e(asset('frontend_assets/images/ftr-logo.png')); ?>" alt="" /></a>
                    <p class="copyright">© 2022 <a href="https://www.siprep.org">St. Ignatius College Preparatory</a>.&nbsp;&nbsp;All rights reserved.</p>
                </div>
            </div>
            <div class="ball">
                <img src="<?php echo e(asset('frontend_assets/images/ball.png')); ?>" alt="">
            </div>
        </footer>
    </div>
    <!-- Jquery-->
    <?php echo \Livewire\Livewire::scripts(); ?>

    <script src="<?php echo e(asset('frontend_assets/js/jquery-3.5.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend_assets/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend_assets/js/slick.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend_assets/js/common.js')); ?>"></script>
    <!-- custom js-->
    <?php echo $__env->yieldPushContent('js'); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
    <script>
        <?php if(Session::has('success')): ?>
            toastr.options = {
                "closeButton": true,
                "progressBar": true
            }
            toastr.success("<?php echo e(session('success')); ?>");
        <?php endif; ?>

        <?php if(Session::has('error')): ?>
            toastr.options = {
                "closeButton": true,
                "progressBar": true
            }
            toastr.error("<?php echo e(session('error')); ?>");
        <?php endif; ?>

        <?php if(Session::has('info')): ?>
            toastr.options = {
                "closeButton": true,
                "progressBar": true
            }
            toastr.info("<?php echo e(session('info')); ?>");
        <?php endif; ?>

        <?php if(Session::has('warning')): ?>
            toastr.options = {
                "closeButton": true,
                "progressBar": true
            }
            toastr.warning("<?php echo e(session('warning')); ?>");
        <?php endif; ?>
    </script>
</body>

</html>
<?php /**PATH /var/www/html/admission-portal-web-1854/resources/views/frontend/auth/register.blade.php ENDPATH**/ ?>