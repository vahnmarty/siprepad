<a href="/">
    
    <img alt="Logo" src="<?php echo e(asset('admin_assets/logo/logo_header2.png')); ?>" width="90px"/>
</a>
<?php /**PATH /var/www/html/admission-portal-web-1854/resources/views/vendor/jetstream/components/authentication-card-logo.blade.php ENDPATH**/ ?>