
<?php $__env->startSection('title', __('page_title.thankyou_page_title')); ?>
<?php $__env->startSection('content'); ?>
    <div class="home-wrap">
        <div class="hme-inr">
            <figure class="hm-fig">
                <img src="<?php echo e(asset('frontend_assets/images/mail.svg')); ?>" alt="" />
            </figure>
            <div class="thank-wrap">
                <h1>Thank <span>You</span></h1>
                <p>
                    Thank you for submitting your application to St. Ignatius
                    College Preparatory. If you have any questions regarding the
                    Admissions process, please visit our website at
                    <a target="_blank" href="https://www.siprep.org/admissions">https://www.siprep.org/admissions</a> or email us at
                    <a href="mailto:admissions@siprep.org">admissions@siprep.org.</a>
                </p>
                <div class="text-center">
                    <a href="<?php echo e(url('/')); ?>" class="back-to">Back to Home</a>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/admission-portal-web-1854/resources/views/frontend/thankyou.blade.php ENDPATH**/ ?>