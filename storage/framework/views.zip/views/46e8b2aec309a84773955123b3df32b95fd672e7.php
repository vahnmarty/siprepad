<?php $__env->startPush('css'); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('frontend.registeration.registeration-six', ['regId' => $reg_id,'reg_id' => $reg_id])->html();
} elseif ($_instance->childHasBeenRendered('3uXTI5S')) {
    $componentId = $_instance->getRenderedChildComponentId('3uXTI5S');
    $componentTag = $_instance->getRenderedChildComponentTagName('3uXTI5S');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('3uXTI5S');
} else {
    $response = \Livewire\Livewire::mount('frontend.registeration.registeration-six', ['regId' => $reg_id,'reg_id' => $reg_id]);
    $html = $response->html();
    $_instance->logRenderedChild('3uXTI5S', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.frontend-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/admission-portal-web-1854/resources/views/frontend/registeration/registeration-six.blade.php ENDPATH**/ ?>