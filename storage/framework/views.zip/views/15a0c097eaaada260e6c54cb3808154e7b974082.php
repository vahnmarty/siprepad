
<?php $__env->startSection('title', __('page_title.admission_application_page_title')); ?>
<?php $__env->startPush('css'); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('frontend.application.application-three', ['getParentInfo' => $getParentInfo])->html();
} elseif ($_instance->childHasBeenRendered('kvyn55K')) {
    $componentId = $_instance->getRenderedChildComponentId('kvyn55K');
    $componentTag = $_instance->getRenderedChildComponentTagName('kvyn55K');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('kvyn55K');
} else {
    $response = \Livewire\Livewire::mount('frontend.application.application-three', ['getParentInfo' => $getParentInfo]);
    $html = $response->html();
    $_instance->logRenderedChild('kvyn55K', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.frontend-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/admission-portal-web-1854/resources/views/frontend/application/application-three.blade.php ENDPATH**/ ?>