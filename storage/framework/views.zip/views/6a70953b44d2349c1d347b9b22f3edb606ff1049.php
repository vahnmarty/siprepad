<div>
    <form wire:submit.prevent="saveOrUpdate">
        <div class="home-wrap hme-wrp2">
            <div class="progress-outr">
                <ul class="progress-ul">
                    <li class="step-complete">
                        <?php if($studentInfo): ?>
                            <a href="<?php echo e(route('admission-application', ['step' => 'one'])); ?>">
                                <span>1</span>
                                <h6>Student Info</h6>
                            </a>
                        <?php else: ?>
                            <a href="javascript::void(0)">
                                <span>1</span>
                                <h6>Student Info</h6>
                            </a>
                        <?php endif; ?>

                    </li>
                    <li class="step-complete">
                        <?php if($studentInfo): ?>
                            <a href="<?php echo e(route('admission-application', ['step' => 'two'])); ?>">
                                <span>2</span>
                                <h6>Address Info</h6>
                            </a>
                        <?php else: ?>
                            <a href="javascript::void(0)">
                                <span>2</span>
                                <h6>Address Info</h6>
                            </a>
                        <?php endif; ?>
                    </li>
                    <li class="step-complete">
                        <?php if($studentInfo): ?>
                            <a href="<?php echo e(route('admission-application', ['step' => 'three'])); ?>">
                                <span>3</span>
                                <h6>Parent Info</h6>
                            </a>
                        <?php else: ?>
                            <a href="javascript::void(0)">
                                <span>3</span>
                                <h6>Parent Info</h6>
                            </a>
                        <?php endif; ?>
                    </li>
                    <li class="step-complete">
                        <?php if($studentInfo): ?>
                            <a href="<?php echo e(route('admission-application', ['step' => 'four'])); ?>">
                                <span>4</span>
                                <h6>Sibling Info</h6>
                            </a>
                        <?php else: ?>
                            <a href="javascript::void(0)">
                                <span>4</span>
                                <h6>Sibling Info</h6>
                            </a>
                        <?php endif; ?>
                    </li>
                    <li class="step-complete">
                        <?php if($studentInfo): ?>
                            <a href="<?php echo e(route('admission-application', ['step' => 'five'])); ?>">
                                <span>5</span>
                                <h6>Legacy Info</h6>
                            </a>
                        <?php else: ?>
                            <a href="javascript::void(0)">
                                <span>5</span>
                                <h6>Legacy Info</h6>
                            </a>
                        <?php endif; ?>
                    </li>
                    <li class="step-complete">
                        <?php if($studentInfo): ?>
                            <a href="<?php echo e(route('admission-application', ['step' => 'six'])); ?>">
                                <span>6</span>
                                <h6>Parent Statement</h6>
                            </a>
                        <?php else: ?>
                            <a href="javascript::void(0)">
                                <span>6</span>
                                <h6>Parent Statement</h6>
                            </a>
                        <?php endif; ?>
                    </li>
                    <li class="step-complete">
                        <?php if($studentInfo): ?>
                            <a href="<?php echo e(route('admission-application', ['step' => 'seven'])); ?>">
                                <span>7</span>
                                <h6>Spiritual & Community Info</h6>
                            </a>
                        <?php else: ?>
                            <a href="javascript::void(0)">
                                <span>7</span>
                                <h6>Spiritual & Community Info</h6>
                            </a>
                        <?php endif; ?>
                    </li>
                    <li>
                        <?php if($studentInfo): ?>
                            <a href="<?php echo e(route('admission-application', ['step' => 'eight'])); ?>">
                                <span>8</span>
                                <h6>Student Statement</h6>
                            </a>
                        <?php else: ?>
                            <a href="javascript::void(0)">
                                <span>8</span>
                                <h6>Student Statement</h6>
                            </a>
                        <?php endif; ?>
                    </li>
                    <li>
                        <?php if($studentInfo): ?>
                            <a href="<?php echo e(route('admission-application', ['step' => 'nine'])); ?>">
                                <span>9</span>
                                <h6>Writing Sample</h6>
                            </a>
                        <?php else: ?>
                            <a href="javascript::void(0)">
                                <span>9</span>
                                <h6>Writing Sample</h6>
                            </a>
                        <?php endif; ?>
                    </li>
                    <li>
                        <?php if($studentInfo): ?>
                            <a href="<?php echo e(route('admission-application', ['step' => 'ten'])); ?>">
                                <span>10</span>
                                <h6>Final Steps</h6>
                            </a>
                        <?php else: ?>
                            <a href="javascript::void(0)">
                                <span>10</span>
                                <h6>Final Steps</h6>
                            </a>
                        <?php endif; ?>
                    </li>
                </ul>
            </div>

            <div class="school-wrap application_step__seven">
                <div class="form-outr">
                    <div class="cmn-hdr">
                        <h4>Religious Background</h4>
                    </div>
                    <div class="frm-uppr">
                        <div class="direct">
                            <h5>DIRECTIONS:</h5>
                            <p>
                                <strong>This section is to be completed by a parent/guardian.
                                    Please prepare and save your answers in a word document
                                    first. Then, copy and paste your answers on this page.
                                    This will ensure you will always have a back up of your
                                    work. Required fields are in <i class="red">red.</i><br><br>
                                Please make sure every required field is completed before saving your work. To save your work, you must click the <i class="red">Next/Save</i> button at the bottom of the page.
                                </strong>
                            </p>
                        </div>
                    </div>

                    <div class="form-wrap">
                        <div class="student_parent_statement">
                            <div class="form-group">
                                <label>Applicant(s)'s Religion:</label>
                                <select
                                    class="form-control <?php echo e($errors->has('spiritualCommunityInfo.Applicant_Religion') ? 'is-invalid' : ''); ?>"
                                    wire:model=spiritualCommunityInfo.Applicant_Religion>
                                    <option value="">-- Please Choose --</option>
                                    <?php $__currentLoopData = $religionList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $religion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($religion['religion_name']); ?>">
                                            <?php echo e($religion['religion_name']); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['spiritualCommunityInfo.Applicant_Religion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback error_text"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <?php if($spiritualCommunityInfo['Applicant_Religion'] == 'Other'): ?>
                                <div class="form-group">
                                    <label class="blck">If "Other," add it here:</label>
                                    <input type="text"
                                        class="form-control <?php echo e($errors->has('spiritualCommunityInfo.Applicant_Religion_Other') ? 'is-invalid' : ''); ?>"
                                        wire:model.defer='spiritualCommunityInfo.Applicant_Religion_Other'>
                                    <?php $__errorArgs = ['spiritualCommunityInfo.Applicant_Religion_Other'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback error_text"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            <?php endif; ?>
                            <div class="form-group">
                                <label class="blck">Church/Faith Community:</label>
                                <input type="text"
                                    class="form-control <?php echo e($errors->has('spiritualCommunityInfo.Church_Faith_Community') ? 'is-invalid' : ''); ?>"
                                    wire:model.defer='spiritualCommunityInfo.Church_Faith_Community'>
                                <?php $__errorArgs = ['spiritualCommunityInfo.Church_Faith_Community'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback error_text"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label class="blck">Church/Faith Community Location:</label>
                                <input type="text"
                                    class="form-control <?php echo e($errors->has('spiritualCommunityInfo.Church_Faith_Community_Location') ? 'is-invalid' : ''); ?>"
                                    wire:model.defer='spiritualCommunityInfo.Church_Faith_Community_Location'>
                                <?php $__errorArgs = ['spiritualCommunityInfo.Church_Faith_Community_Location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback error_text"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <?php $__currentLoopData = $spiritualCommunityInfo['Students']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="student_parent_statement">
                                <h4><?php echo e($student['Student_name']); ?></h4>

                                <div class="form-group">
                                    <label class="blck">Baptism Year:</label>
                                    <input type="text" maxlength="4"
                                        class="form-control <?php echo e($errors->has('spiritualCommunityInfo.students.' . $key . '.S' . ($key + 1) . '_Baptism_Year') ? 'is-invalid' : ''); ?>"
                                        wire:model.defer='spiritualCommunityInfo.Students.<?php echo e($key); ?>.S<?php echo e($key + 1); ?>_Baptism_Year'
                                        oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*?)\..*/g, '$1');" />
                                    
                                    <?php $__errorArgs = ['spiritualCommunityInfo.students.*.S' . ($key + 1) . '_Baptism_Year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback error_text"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="form-group">
                                    <label class="blck">Confirmation Year:</label>
                                    <input type="text" maxlength="4"
                                        class="form-control <?php echo e($errors->has('spiritualCommunityInfo.students.' . $key . '.S' . ($key + 1) . '_Confirmation_Year') ? 'is-invalid' : ''); ?>"
                                        wire:model.defer='spiritualCommunityInfo.Students.<?php echo e($key); ?>.S<?php echo e($key + 1); ?>_Confirmation_Year'
                                        oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*?)\..*/g, '$1');" />
                                    
                                    <?php $__errorArgs = ['spiritualCommunityInfo.students.*.S' . ($key + 1) . '_Confirmation_Year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback error_text"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>

            <div class="school-wrap application_step__seven">
                <div class="form-outr">
                    <div class="cmn-hdr">
                        <h4>Family Spirituality and Community:</h4>
                    </div>

                    <div class="form-wrap">
                        <div class="student_parent_statement">
                            <div class="form-group">
                                <label>What impact does community have in your life and how do
                                    you best support your child's school community?</label>
                                <div data-maxcount="125" wire:ignore>
                                    <textarea id="stepSevenTextAreaOne"
                                        class="word_count form-control <?php echo e($errors->has('spiritualCommunityInfo.Impact_to_Community') ? 'is-invalid' : ''); ?>"
                                        name="first_name" wire:model.defer='spiritualCommunityInfo.Impact_to_Community'></textarea>
                                    
                                    <p class="wrds">
                                     <!--   (Max <span class="word_left" id="wordCountOne">75 </span> words) -->
                                     (Please limit answer to 75 words.)
                                    </p>
                                    <script>
                                        $(document).ready(function() {
                                            console.log("ready!");
                                            let countwords = $.trim($('#stepSevenTextAreaOne').val()).split(' ').filter(function(
                                                v) {
                                                return v !== ''
                                            }).length;
                                            console.log(countwords);
                                            document.getElementById("wordCountOne").innerHTML = 125 - countwords;
                                        });

                                        $("[data-maxcount]").each(function() {
                                            let _this = $(this);
                                            let _this_count = parseInt(_this.attr("data-maxcount"));
                                            _this.find("#stepSevenTextAreaOne").on("keyup", function() {
                                                let words =0;
                                                if (this.value.match(/\S+/g) != null) {
                                                    words = this.value.match(/\S+/g).length;
                                                }
                                                if (words > _this_count) {
                                                    let trimmed = $(this).val().split(/\s+/, _this_count).join(" ");
                                                    $(this).val(trimmed + " ");
                                                } else {
                                                    _this.find("#wordCountOne").text(_this_count - words);
                                                }
                                            }); 
                                        });  
                                    </script>
                                </div>
                                <?php $__errorArgs = ['spiritualCommunityInfo.Impact_to_Community'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="error error_text"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group">
                                <label>How would you describe your family's spirituality?
                                    <span class="lbl-spn">Check all that apply.</span></label>
                                <div class="check-wrap">
                                    <?php $__currentLoopData = $spiritualitiesList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $spkey => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <label class="check-inn"><?php echo e(ucwords($item['name'])); ?>

                                            <input type="checkbox" class="open"
                                                wire:model="spiritualCommunityInfo.Describe_Family_Spirituality.<?php echo e($item['id']); ?>">
                                            <span class="checkmark"></span>
                                        </label>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php $__errorArgs = ['spiritualCommunityInfo.Describe_Family_Spirituality'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="error error_text"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="form-group">
                                <label>Describe in more detail the practice(s) checked
                                    above:</label>
                                <div data-maxcount="125" wire:ignore>
                                    <textarea id="stepSevenTextAreaTwo"
                                        class="word_count form-control <?php echo e($errors->has('spiritualCommunityInfo.Describe_Practice_in_Detail') ? 'is-invalid' : ''); ?>"
                                        name="first_name" wire:model.defer='spiritualCommunityInfo.Describe_Practice_in_Detail'></textarea>
                                    
                                    <p class="wrds">
                                    <!--    (Max <span class="word_left" id="wordCountTwo">75 </span> words) -->
                                     (Please limit answer to 75 words.)                                        
                                    </p> 
                                    <script>
                                        $(document).ready(function() {
                                            console.log("ready!");
                                            let countwords = $.trim($('#stepSevenTextAreaTwo').val()).split(' ').filter(function(
                                                v) {
                                                return v !== ''
                                            }).length;
                                            console.log(countwords);
                                            document.getElementById("wordCountTwo").innerHTML = 125 - countwords;
                                        });
                                        $("[data-maxcount]").each(function() {
                                            let _this = $(this);
                                            let _this_count = parseInt(_this.attr("data-maxcount"));
                                            _this.find("#stepSevenTextAreaTwo").on("keyup", function() {
                                                let words = 0;
                                                if (this.value.match(/\S+/g) != null) {
                                                    words = this.value.match(/\S+/g).length;
                                                }
                                                if (words > _this_count) {
                                                    let trimmed = $(this).val().split(/\s+/, _this_count).join(" ");
                                                    $(this).val(trimmed + " ");
                                                } else {
                                                    _this.find("#wordCountTwo").text(_this_count - words);
                                                }
                                            }); 
                                        }); 
                                    </script>
                                </div>
                                <?php $__errorArgs = ['spiritualCommunityInfo.Describe_Practice_in_Detail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="error error_text"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
                            </div>

                            <div class="form-group">
                                <label>Will you encourage your child to proactively participate
                                    in the following activities?</label>
                            </div>

                            <div class="form-group">
                                <label>Religious Studies Classes:</label>
                                <select
                                    class="form-control <?php echo e($errors->has('spiritualCommunityInfo.Religious_Studies_Classes') ? 'is-invalid' : ''); ?>"
                                    wire:model='spiritualCommunityInfo.Religious_Studies_Classes'>
                                    <option value="">-- Please Choose --</option>
                                    <?php $__currentLoopData = $religionsStudiesList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $religions): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($religions['religions_name']); ?>">
                                            <?php echo e($religions['religions_name']); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['spiritualCommunityInfo.Religious_Studies_Classes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback error_text"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <?php if($spiritualCommunityInfo['Religious_Studies_Classes'] == 'Unsure' ||
                                $spiritualCommunityInfo['Religious_Studies_Classes'] == 'No'): ?>
                                <div class="form-group">
                                    <label class="blck">If No/Unsure, please explain:</label>
                                    <input type="text"
                                        class="form-control <?php echo e($errors->has('spiritualCommunityInfo.Religious_Studies_Classes_Explanation') ? 'is-invalid' : ''); ?>"
                                        wire:model.defer='spiritualCommunityInfo.Religious_Studies_Classes_Explanation'>
                                    <?php $__errorArgs = ['spiritualCommunityInfo.Religious_Studies_Classes_Explanation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback error_text"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            <?php endif; ?>

                            <div class="form-group">
                                <label> School Liturgies:</label>
                                <select
                                    class="form-control <?php echo e($errors->has('spiritualCommunityInfo.School_Liturgies') ? 'is-invalid' : ''); ?>"
                                    wire:model='spiritualCommunityInfo.School_Liturgies'>
                                    <option value="">-- Please Choose --</option>
                                    <?php $__currentLoopData = $liturgiesList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $liturgies): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($liturgies['liturgies_name']); ?>">
                                            <?php echo e($liturgies['liturgies_name']); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['spiritualCommunityInfo.School_Liturgies'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback error_text"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <?php if($spiritualCommunityInfo['School_Liturgies'] == 'Unsure' ||
                                $spiritualCommunityInfo['School_Liturgies'] == 'No'): ?>
                                <div class="form-group">
                                    <label class="blck">If No/Unsure, please explain:</label>
                                    <input type="text"
                                        class="form-control <?php echo e($errors->has('spiritualCommunityInfo.School_Liturgies_Explanation') ? 'is-invalid' : ''); ?>"
                                        wire:model.defer='spiritualCommunityInfo.School_Liturgies_Explanation'>
                                    <?php $__errorArgs = ['spiritualCommunityInfo.School_Liturgies_Explanation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback error_text"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            <?php endif; ?>

                            <div class="form-group">
                                <label> Retreats:</label>
                                <select
                                    class="form-control <?php echo e($errors->has('spiritualCommunityInfo.Retreats') ? 'is-invalid' : ''); ?>"
                                    wire:model='spiritualCommunityInfo.Retreats'>
                                    <option value="">-- Please Choose --</option>
                                    <?php $__currentLoopData = $retreatsList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $retreats): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($retreats['retreats_name']); ?>">
                                            <?php echo e($retreats['retreats_name']); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['spiritualCommunityInfo.Retreats'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback error_text"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <?php if($spiritualCommunityInfo['Retreats'] == 'Unsure' || $spiritualCommunityInfo['Retreats'] == 'No'): ?>
                                <div class="form-group">
                                    <label class="blck">If No/Unsure, please explain:</label>
                                    <input type="text"
                                        class="form-control <?php echo e($errors->has('spiritualCommunityInfo.Retreats_Explanation') ? 'is-invalid' : ''); ?>"
                                        wire:model.defer='spiritualCommunityInfo.Retreats_Explanation'>
                                    <?php $__errorArgs = ['spiritualCommunityInfo.Retreats_Explanation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback error_text"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            <?php endif; ?>

                            <div class="form-group">
                                <label> Community Service:</label>
                                <select
                                    class="form-control <?php echo e($errors->has('spiritualCommunityInfo.Community_Service') ? 'is-invalid' : ''); ?>"
                                    wire:model='spiritualCommunityInfo.Community_Service'>
                                    <option value="">-- Please Choose --</option>
                                    <?php $__currentLoopData = $communityServiceList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $communityService): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($communityService['communityService_name']); ?>">
                                            <?php echo e($communityService['communityService_name']); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['spiritualCommunityInfo.Community_Service'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback error_text"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <?php if($spiritualCommunityInfo['Community_Service'] == 'Unsure' ||
                                $spiritualCommunityInfo['Community_Service'] == 'No'): ?>
                                <div class="form-group">
                                    <label class="blck">If No/Unsure, please explain:</label>
                                    <input type="text"
                                        class="form-control <?php echo e($errors->has('spiritualCommunityInfo.Community_Service_Explanation') ? 'is-invalid' : ''); ?>"
                                        wire:model.defer='spiritualCommunityInfo.Community_Service_Explanation'>
                                    <?php $__errorArgs = ['spiritualCommunityInfo.Community_Service_Explanation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback error_text"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>

            <div class="school-wrap pt application_step__seven">
                <div class="form-outr">
                    <div class="form-wrap">
                        <div class="form-group">
                            <label>Religious Form Submitted By:</label>
                            <input type="text"
                                class="form-control <?php echo e($errors->has('spiritualCommunityInfo.Religious_Form_Submitted_By') ? 'is-invalid' : ''); ?>"
                                wire:model.defer='spiritualCommunityInfo.Religious_Form_Submitted_By'>
                            <?php $__errorArgs = ['spiritualCommunityInfo.Religious_Form_Submitted_By'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback error_text"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group">
                            <label> Relationship to Student(s):</label>
                            <select
                                class="form-control <?php echo e($errors->has('spiritualCommunityInfo.Religious_Form_Relationship') ? 'is-invalid' : ''); ?>"
                                wire:model='spiritualCommunityInfo.Religious_Form_Relationship'>
                                <option value="">-- Please Choose --</option>
                                <?php $__currentLoopData = $relationshipList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $relationship): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($relationship['relationship_name']); ?>">
                                        <?php echo e($relationship['relationship_name']); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['spiritualCommunityInfo.Religious_Form_Relationship'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback error_text"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="flx">
            <div class="form-btn">
                <a href="<?php echo e(route('admission-application', ['step' => 'six'])); ?>" class="sub-btn">Previous</a>
            </div>
            <div class="form-btn">
                <button type="submit" value="Next" class="sub-btn">Next/Save</button>
            </div>
        </div>

    </form>
</div>
<?php /**PATH /var/www/html/admission-portal-web-1854/resources/views/livewire/frontend/application/application-seven.blade.php ENDPATH**/ ?>