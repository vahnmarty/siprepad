<div>
    <form wire:submit.prevent="saveOrUpdate">
        <div class="home-wrap hme-wrp2">
            <div class="progress-outr">
                <ul class="progress-ul">
                    <li class="step-complete">
                        <?php if($studentInfo): ?>
                            <a href="<?php echo e(route('admission-application', ['step' => 'one'])); ?>">
                                <span>1</span>
                                <h6>Student Info</h6>
                            </a>
                        <?php else: ?>
                            <a href="javascript::void(0)">
                                <span>1</span>
                                <h6>Student Info</h6>
                            </a>
                        <?php endif; ?>

                    </li>
                    <li class="step-complete">
                        <?php if($studentInfo): ?>
                            <a href="<?php echo e(route('admission-application', ['step' => 'two'])); ?>">
                                <span>2</span>
                                <h6>Address Info</h6>
                            </a>
                        <?php else: ?>
                            <a href="javascript::void(0)">
                                <span>2</span>
                                <h6>Address Info</h6>
                            </a>
                        <?php endif; ?>
                    </li>
                    <li class="step-complete">
                        <?php if($studentInfo): ?>
                            <a href="<?php echo e(route('admission-application', ['step' => 'three'])); ?>">
                                <span>3</span>
                                <h6>Parent Info</h6>
                            </a>
                        <?php else: ?>
                            <a href="javascript::void(0)">
                                <span>3</span>
                                <h6>Parent Info</h6>
                            </a>
                        <?php endif; ?>
                    </li>
                    <li class="step-complete">
                        <?php if($studentInfo): ?>
                            <a href="<?php echo e(route('admission-application', ['step' => 'four'])); ?>">
                                <span>4</span>
                                <h6>Sibling Info</h6>
                            </a>
                        <?php else: ?>
                            <a href="javascript::void(0)">
                                <span>4</span>
                                <h6>Sibling Info</h6>
                            </a>
                        <?php endif; ?>
                    </li>
                    <li class="step-complete">
                        <?php if($studentInfo): ?>
                            <a href="<?php echo e(route('admission-application', ['step' => 'five'])); ?>">
                                <span>5</span>
                                <h6>Legacy Info</h6>
                            </a>
                        <?php else: ?>
                            <a href="javascript::void(0)">
                                <span>5</span>
                                <h6>Legacy Info</h6>
                            </a>
                        <?php endif; ?>
                    </li>
                    <li>
                        <?php if($studentInfo): ?>
                            <a href="<?php echo e(route('admission-application', ['step' => 'six'])); ?>">
                                <span>6</span>
                                <h6>Parent Statement</h6>
                            </a>
                        <?php else: ?>
                            <a href="javascript::void(0)">
                                <span>6</span>
                                <h6>Parent Statement</h6>
                            </a>
                        <?php endif; ?>
                    </li>
                    <li>
                        <?php if($studentInfo): ?>
                            <a href="<?php echo e(route('admission-application', ['step' => 'seven'])); ?>">
                                <span>7</span>
                                <h6>Spiritual & Community Info</h6>
                            </a>
                        <?php else: ?>
                            <a href="javascript::void(0)">
                                <span>7</span>
                                <h6>Spiritual & Community Info</h6>
                            </a>
                        <?php endif; ?>
                    </li>
                    <li>
                        <?php if($studentInfo): ?>
                            <a href="<?php echo e(route('admission-application', ['step' => 'eight'])); ?>">
                                <span>8</span>
                                <h6>Student Statement</h6>
                            </a>
                        <?php else: ?>
                            <a href="javascript::void(0)">
                                <span>8</span>
                                <h6>Student Statement</h6>
                            </a>
                        <?php endif; ?>
                    </li>
                    <li>
                        <?php if($studentInfo): ?>
                            <a href="<?php echo e(route('admission-application', ['step' => 'nine'])); ?>">
                                <span>9</span>
                                <h6>Writing Sample</h6>
                            </a>
                        <?php else: ?>
                            <a href="javascript::void(0)">
                                <span>9</span>
                                <h6>Writing Sample</h6>
                            </a>
                        <?php endif; ?>
                    </li>
                    <li>
                        <?php if($studentInfo): ?>
                            <a href="<?php echo e(route('admission-application', ['step' => 'ten'])); ?>">
                                <span>10</span>
                                <h6>Final Steps</h6>
                            </a>
                        <?php else: ?>
                            <a href="javascript::void(0)">
                                <span>10</span>
                                <h6>Final Steps</h6>
                            </a>
                        <?php endif; ?>
                    </li>
                </ul>
            </div>
            <div class="school-wrap">
                <div class="form-outr">
                    <div class="cmn-hdr">
                        <h4>Legacy Info</h4>
                    </div>

                    <div class="frm-uppr">
                        <div class="direct">
                            <h5>DIRECTIONS:</h5>
                            <p>
                                <strong>This section is to be completed by a parent/guardian.
                                    Please add all relatives that went to SI associated with
                                    the student(s). Required fields are in
                                    <i class="red">red.</i><br><br>
                                Please make sure every required field is completed before saving your work. To save your work, you must click the <i class="red">Next/Save</i> button at the bottom of the page.
                                </strong>
                            </p>
                        </div>
                    </div>

                    <div class="schl-btm mb-1">
                        <h6 class="red">
                            Do you have family members who have attended SI?
                        </h6>
                        <div class="schl-rdo ml-n">
                            <div class="form_input_radio">
                                <label class="radio-pro">Yes
                                    <input type="radio" name="radio" wire:click="showHideDiv('yes')"
                                        wire:model="is_any_attended_si" value="1" />
                                    <span class="checkmark"></span>
                                </label>
                                <label class="radio-pro">No
                                    <input type="radio" name="radio" wire:click="showHideDiv('no')"
                                        wire:model="is_any_attended_si" value="0" />
                                    <span class="checkmark"></span>
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="note">
                        <p>
                            <strong>
                                <span>NOTE:</span> Sibling alums should be listed in
                                the Sibling Info section.</strong>
                        </p>
                    </div>


                    <?php if($is_any_attended_si): ?>
                        <?php $__currentLoopData = $legacyInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $legacy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="form-wrap">
                                <div>
                                    <h4>Legacy Relative <?php echo e($key + 1); ?></h4>

                                    <div class="form-group">
                                        <label class="blck">First Name:</label>
                                        <input type="text"
                                            class="form-control <?php echo e($errors->has('legacyInfo.' . $key . 'First_Name') ? 'is-invalid' : ''); ?>"
                                            wire:model.defer='legacyInfo.<?php echo e($key); ?>.First_Name'>
                                        <?php $__errorArgs = ['legacyInfo.*First_Name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback error_text"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="form-group">
                                        <label class="blck">Last Name:</label>
                                        <input type="text"
                                            class="form-control <?php echo e($errors->has('legacyInfo.' . $key . 'Last_Name') ? 'is-invalid' : ''); ?>"
                                            wire:model.defer='legacyInfo.<?php echo e($key); ?>.Last_Name'>
                                        <?php $__errorArgs = ['legacyInfo.*Last_Name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback error_text"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="form-group">
                                        <label class="blck">Relationship:</label>
                                        <select
                                            class="form-control <?php echo e($errors->has('legacyInfo.' . $key . 'Relationship') ? 'is-invalid' : ''); ?>"
                                            wire:model.defer='legacyInfo.<?php echo e($key); ?>.Relationship'>
                                            <option value="">-- Please Choose --</option>
                                            <?php $__currentLoopData = $relationshipList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $relationship): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($relationship['relationship_name']); ?>">
                                                    <?php echo e($relationship['relationship_name']); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['legacyInfo.*Relationship'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback error_text"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="form-group">
                                        <label class="blck"> Graduation year:</label>
                                        <input type="text" maxlength="4"
                                            class="form-control <?php echo e($errors->has('legacyInfo.' . $key . 'Graduation_Year') ? 'is-invalid' : ''); ?>"
                                            wire:model.defer='legacyInfo.<?php echo e($key); ?>.Graduation_Year'
                                            oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*?)\..*/g, '$1');" />
                                        
                                        <?php $__errorArgs = ['legacyInfo.*Graduation_Year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback error_text"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-outr">
                                    <div class="schl-btm mt">
                                        
                                        <div class="form_input_radio">
                                            <?php if($key < 4 && $i !== 5): ?>
                                                <button class="btn btn-danger btn-sm"
                                                    wire:click.prevent="add(<?php echo e($i); ?>)">Add another
                                                    legacy
                                                </button>
                                            <?php endif; ?>
                                            <?php if($key != 0): ?>
                                                <button class="btn btn-danger btn-sm"
                                                    wire:click.prevent="remove(<?php echo e($key); ?>)">Remove legacy
                                                </button>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="flx">
            <div class="form-btn">
                <a href="<?php echo e(route('admission-application', ['step' => 'four'])); ?>" class="sub-btn">Previous</a>
            </div>
            <div class="form-btn">
                <button type="submit" value="Next" class="sub-btn">Next/Save</button>
            </div>
        </div>
    </form>
</div>
<?php /**PATH /var/www/html/admission-portal-web-1854/resources/views/livewire/frontend/application/application-five.blade.php ENDPATH**/ ?>