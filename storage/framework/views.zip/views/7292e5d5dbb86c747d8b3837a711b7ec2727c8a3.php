<div class="email-template-main-sec" style="margin-top: 100px; margin-bottom: 50px;">
    <div class="email-template"
        style="max-width: 75%;
    margin: 0 auto;
    box-shadow: 0 0 20px #adadad;
    padding: 30px;
    border-radius: 10px;">
        <div class="heading" style="padding-bottom: 20px;">
            <h2
                style="font-size:20px;font-style:normal;font-weight: 600;letter-spacing: 0.9px;margin:0;line-height: 25px;">
                Hi, <?php echo e($parent->P1_First_Name); ?> <?php echo e($parent->P1_Last_Name); ?>,</h2>
        </div>
        <div class="all-txt">
            <?php if($status == 1): ?>
            	<p
                    style="font-size:16px;font-style:normal;font-weight: 400;letter-spacing: 0.2px;;margin:0;line-height: 22px;margin-bottom: 25px;">
                    Congratulations, Your child <?php echo e($student->S1_First_Name); ?> <?php echo e($student->S1_Last_Name); ?> has accepted the proposal of joining our university. 
                    So, Kindly Click on the button given below to do payment.
                </p>
            <?php else: ?>
            	<p
                    style="font-size:16px;font-style:normal;font-weight: 400;letter-spacing: 0.2px;;margin:0;line-height: 22px;margin-bottom: 25px;">
                    Sorry, Your child <?php echo e($student->S1_First_Name); ?> <?php echo e($student->S1_Last_Name); ?> has rejected the proposal of joining our university. 
                    Thankyou for your precious time.
                </p> 
            <?php endif; ?>
        </div>
    </div>
</div><?php /**PATH /var/www/html/admission-portal-web-1854/resources/views/emails/candidateStatusMail.blade.php ENDPATH**/ ?>