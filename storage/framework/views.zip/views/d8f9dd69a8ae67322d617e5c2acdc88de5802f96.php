 <?php $__env->startPush('css'); ?> <?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('registration.update',$studentinfo->id)); ?>" method="POST">
	<?php echo csrf_field(); ?> 
	<?php echo method_field('PUT'); ?>
	<div class="home-wrap hme-wrp2">


		<div class="form-outr">

			<div class="form-outr">
				<div class="cmn-hdr">
					<h4>Student Info</h4>

				</div>
				<div class="school-wrap step__one">
					<div class="form-wrap">
						<div class="row">
							<div class="col-md-4">
								<div class="form-group">
									<label> Legal First Name </label> <input type="text"

										class="form-control" name='S1_first_name' value="<?php echo e($studentinfo->S1_First_Name); ?>" />
										<?php $__errorArgs = ['S1_first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-danger"><?php echo e('First name is required'); ?></p>
										<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
								</div>
							</div>
							<div class="col-md-4">
								<div class="form-group">
									<label class="blck">Legal Middle Name </label> <input
										type="text" class="form-control" name='S1_middle_name'
										value="<?php echo e($studentinfo->S1_Middle_Name); ?>" /> <?php $__errorArgs = ['S1_middle_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<p class="text-danger"><?php echo e('Enter a valid middle name'); ?></p>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
								</div>
							</div>
							<div class="col-md-4">
								<div class="form-group">
									<label>Legal Last Name </label> <input type="text"
										class="form-control" name='S1_last_name'
										value="<?php echo e($studentinfo->S1_Last_Name); ?>" /> <?php $__errorArgs = ['S1_last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<p class="text-danger"><?php echo e('Last name is required'); ?></p>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
								</div>
							</div>

						</div>
						<div class="row">
							<div class="col-md-4">
								<div class="form-group">
									<label class="blck">Preffered First Name </label> <input
										type="text" class="form-control" name='S1_preffered_first_name'
										value="<?php echo e($studentinfo->S1_Preferred_First_Name); ?>" />
									<?php $__errorArgs = ['preffered_first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<p class="text-danger"><?php echo e('Enter a valid preferred name'); ?></p>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
								</div>
							</div>
							<div class="col-md-4">
								<div class="form-group">
									<label>Date of Birth </label> <input type="date"
										class="form-control" name='S1_date_of_birth'
										value="<?php echo e($studentinfo->S1_Birthdate); ?>" name="date_of_birth" />
									<?php $__errorArgs = ['S1_date_of_birth'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<p class="text-danger"><?php echo e('A valid D.O.B is required before today'); ?></p>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
								</div>
							</div>
							<div class="col-md-4">
								<div class="form-group">
									<label>Gender </label> <select class="form-control"
										name='S1_gender'>
										<option value="male" <?php echo e($studentinfo->S1_Gender == 'male' ? 'selected' : ''); ?>>Male</option>
										<option value="female" <?php echo e($studentinfo->S1_Gender == 'female' ? 'selected' : ''); ?>>Female</option>

									</select> <?php $__errorArgs = ['S1_gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<p class="text-danger"><?php echo e('Gender is required'); ?></p>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
								</div>
							</div>

						</div>
						<div class="row">
							<div class="col-md-4">
								<div class="form-group">
									<label>Student's Mobile Phone Number </label> <input type="tel"
										class="form-control" name='S1_student_phone_number'
										value="<?php echo e($studentinfo->S1_Mobile_Phone); ?>" />
									<?php $__errorArgs = ['S1_student_phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<p class="text-danger"><?php echo e('Enter a valid mobile number'); ?></p>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
								</div>
							</div>
							<div class="col-md-4">
								<div class="form-group">
									<label>T-Shirt Size(Adult/Unisex) </label> 
									<select class="form-control" name='S1_tshirt_size'>
										<option value="small" <?php echo e($studentinfo->s1_tshirt_size == 'small' ? 'selected' : ''); ?>>Small</option>
										<option value="medium" <?php echo e($studentinfo->s1_tshirt_size == 'medium' ? 'selected' : ''); ?>>Medium</option>
										<option value="large" <?php echo e($studentinfo->s1_tshirt_size == 'large' ? 'selected' : ''); ?>>Large</option>
									</select> <?php $__errorArgs = ['S1_tshirt_size'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<p class="text-danger"><?php echo e('Please select a T-shirt size'); ?></p>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
								</div>
							</div>

						</div>

						<div class="row">
							<div class="col-md-4">
								<div class="form-group">
									<label class="blck">Religion </label><select
										class="form-control" name='S1_religion'
										value="">
										<option value="hindu"<?php echo e($studentinfo->s1_religion == 'hindu' ? 'selected' : ''); ?>>Hindu</option>
										<option value="christian"<?php echo e($studentinfo->s1_religion == 'christian' ? 'selected' : ''); ?>>Christian</option>
										<option value="none"<?php echo e($studentinfo->s1_religion == 'none' ? 'selected' : ''); ?>>None</option>

									</select> <?php $__errorArgs = ['S1_religion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<p class="text-danger"><?php echo e('Please select a valid religion'); ?></p>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
								</div>
							</div>


						</div>
						<div class="multiracial mb-3">
							<span>How do you identify racially ? If more than one select separate
								races with a comma. Example: White, Black , Race x,
								Race y, Race z"<br>
								
							</span>
						</div>
						
						<div class="row">
							<div class="col-md-4">
								<div class="form-group">
									<input type="text" class="form-control" name='S1_racial'
										value="<?php echo e($studentinfo->S1_Race); ?>" /> <?php $__errorArgs = ['S1_racial'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<p class="text-danger"><?php echo e('Please select a valid race'); ?></p>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

								</div>

							</div>

						</div>
						
<!-- 						<div class="form-group"> -->
<!-- 							<label class="blck"><input type="checkbox" name="racial" -->
<!-- 								value="Asian"<?php echo e($studentinfo->S1_Race == 'Asian' ? 'checked' : ''); ?>>Asian</label><br> <label class="blck"><input -->
<!-- 								type="checkbox" name="racial" value="Black/African American"<?php echo e($studentinfo->S1_Race == 'Black/African American' ? 'checked' : ''); ?>> -->
<!-- 								Black/African American</label><br> <label class="blck"><input -->
<!-- 								type="checkbox" name="racial" value="Native American/Indegenous"<?php echo e($studentinfo->S1_Race == 'Native American/Indegenous' ? 'checked' : ''); ?>> -->
<!-- 								Native American/Indegenous</label><br> <label class="blck"><input -->
<!-- 								type="checkbox" name="racial" value="White"<?php echo e($studentinfo->S1_Race == 'White' ? 'checked' : ''); ?>> White</label> <br> -->
<!-- 							<label class="blck"><input type="checkbox" name="racial" -->
<!-- 								value="Multiracial"<?php echo e($studentinfo->S1_Race == 'Multiracial' ? 'checked' : ''); ?>> Multiracial</label> <?php $__errorArgs = ['racial'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> -->
<!-- 							<p class="text-danger"><?php echo e($message); ?></p> -->
<!-- 							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> -->
<!-- 						</div> -->

						<div class="ethinicity ">
							<span>What is your ethinicity ? If more than one select separate
								ethnicities with a comma. Example: Filipino , Hawaiian , Irish ,
								Italian , Middle Eastern , Salvadorian" </span>
						</div>
						<div class="row">
							<div class="col-md-4">
								<div class="form-group">
									<input type="text" class="form-control" name='S1_ethnicity'
										value="<?php echo e($studentinfo->S1_Ethnicity); ?>" /> <?php $__errorArgs = ['S1_ethnicity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<p class="text-danger"><?php echo e('Please select a valid ethnicity'); ?></p>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

								</div>

							</div>

						</div>
						<div class="row">
							<div class="col-md-4">
								<div class="form-group">
									<label class="blck">Current School </label><select
										class="form-control" name='S1_current_school'
										value="">
										<option value="school_one" <?php echo e($studentinfo->S1_Current_School == 'school_one' ? 'selected' : ''); ?> >School one</option>
										<option value="school_two" <?php echo e($studentinfo->S1_Current_School == 'school_two' ? 'selected' : ''); ?> >School two</option>
										<option value="school_three" <?php echo e($studentinfo->S1_Current_School == 'school_three' ? 'selected' : ''); ?>>School three</option>

									</select> <?php $__errorArgs = ['S1_current_school'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<p class="text-danger"><?php echo e('Please select a valid school'); ?></p>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

								</div>
							</div>
						</div>
				<?php if(!empty($studentinfo->S2_First_Name)): ?>
					<div class = student-2>

					<div class ="row">
					<div class ="col-md-4">
					<h4>Student 2</h4>
					</div>
					</div>
						<div class="row">
							<div class="col-md-4">
								<div class="form-group">
									<label> Legal First Name </label> <input type="text"
										class="form-control" name='S2_first_name' value="<?php echo e($studentinfo->S2_First_Name); ?>" />
									<?php $__errorArgs = ['S2_first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<p class="text-danger"><?php echo e('First name is required'); ?></p>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

								</div>
							</div>
							<div class="col-md-4">
								<div class="form-group">
									<label class="blck">Legal Middle Name </label> <input
										type="text" class="form-control" name='S2_middle_name'
										value="<?php echo e($studentinfo->S2_Middle_Name); ?>" /> <?php $__errorArgs = ['S2_middle_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<p class="text-danger"><?php echo e('Enter a valid middle name'); ?></p>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
								</div>
							</div>
							<div class="col-md-4">
								<div class="form-group">
									<label>Legal Last Name </label> <input type="text"
										class="form-control" name='S2_last_name'
										value="<?php echo e($studentinfo->S2_Last_Name); ?>" /> <?php $__errorArgs = ['S2_last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<p class="text-danger"><?php echo e('Last name is required'); ?></p>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
								</div>
							</div>

						</div>
						<div class="row">
							<div class="col-md-4">
								<div class="form-group">
									<label class="blck">Preffered First Name </label> <input
										type="text" class="form-control" name='S2_preffered_first_name'
										value="<?php echo e($studentinfo->S2_Preferred_First_Name); ?>" />
									<?php $__errorArgs = ['S2_preffered_first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<p class="text-danger"><?php echo e('Enter a valid preferred name'); ?></p>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
								</div>
							</div>
							<div class="col-md-4">
								<div class="form-group">
									<label>Date of Birth </label> <input type="date"
										class="form-control"
										value="<?php echo e($studentinfo->S2_Birthdate); ?>" name="S2_date_of_birth" />
									<?php $__errorArgs = ['S2_date_of_birth'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<p class="text-danger"><?php echo e('A valid D.O.B is required before today'); ?></p>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
								</div>
							</div>
							<div class="col-md-4">
								<div class="form-group">
									<label>Gender </label> <select class="form-control"
										name='S2_gender'>
										<option value="male" <?php echo e($studentinfo->S2_Gender == 'male' ? 'selected' : ''); ?>>Male</option>
										<option value="female" <?php echo e($studentinfo->S2_Gender == 'female' ? 'selected' : ''); ?>>Female</option>

									</select> <?php $__errorArgs = ['S2_gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<p class="text-danger"><?php echo e('Gender is required'); ?></p>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
								</div>
							</div>

						</div>
						<div class="row">
							<div class="col-md-4">
								<div class="form-group">
									<label>Student's Mobile Phone Number </label> <input type="tel"
										class="form-control" name='S2_student_phone_number'
										value="<?php echo e($studentinfo->S2_Mobile_Phone); ?>" />
									<?php $__errorArgs = ['S2_student_phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<p class="text-danger"><?php echo e('Enter a valid mobile number'); ?></p>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
								</div>
							</div>
							<div class="col-md-4">
								<div class="form-group">
									<label>T-Shirt Size(Adult/Unisex) </label> 
									<select class="form-control" name='S2_tshirt_size'>
										<option value="small" <?php echo e($studentinfo->s2_tshirt_size == 'small' ? 'selected' : ''); ?>>Small</option>
										<option value="medium" <?php echo e($studentinfo->s2_tshirt_size == 'medium' ? 'selected' : ''); ?>>Medium</option>
										<option value="large" <?php echo e($studentinfo->s2_tshirt_size == 'large' ? 'selected' : ''); ?>>Large</option>
									</select> <?php $__errorArgs = ['S2_tshirt_size'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<p class="text-danger"><?php echo e('Please select a T-shirt size'); ?></p>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
								</div>
							</div>

						</div>

						<div class="row">
							<div class="col-md-4">
								<div class="form-group">
									<label class="blck">Religion </label><select
										class="form-control" name='S2_religion'
										value="">
										<option value="hindu"<?php echo e($studentinfo->s2_religion == 'hindu' ? 'selected' : ''); ?>>Hindu</option>
										<option value="christian"<?php echo e($studentinfo->s2_religion == 'christian' ? 'selected' : ''); ?>>Christian</option>
										<option value="none"<?php echo e($studentinfo->s2_religion == 'none' ? 'selected' : ''); ?>>None</option>

									</select> <?php $__errorArgs = ['S2_religion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<p class="text-danger"><?php echo e('Please select a valid religion'); ?></p>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
								</div>
							</div>


						</div>
						<div class="multiracial mb-3">
							<span>How do you identify racially ? If more than one select separate
								races with a comma. Example: White, Black , Race x,
								Race y, Race z"<br>
								
							</span>
						</div>
						
						<div class="row">
							<div class="col-md-4">
								<div class="form-group">
									<input type="text" class="form-control" name='S2_racial'
										value="<?php echo e($studentinfo->S2_Race); ?>" /> <?php $__errorArgs = ['S2_racial'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<p class="text-danger"><?php echo e('Please select a valid race'); ?></p>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

								</div>

							</div>

						</div>
						
<!-- 						<div class="form-group"> -->
<!-- 							<label class="blck"><input type="checkbox" name="racial" -->
<!-- 								value="Asian"<?php echo e($studentinfo->S2_Race == 'Asian' ? 'checked' : ''); ?>>Asian</label><br> <label class="blck"><input -->
<!-- 								type="checkbox" name="racial" value="Black/African American"<?php echo e($studentinfo->S2_Race == 'Black/African American' ? 'checked' : ''); ?>> -->
<!-- 								Black/African American</label><br> <label class="blck"><input -->
<!-- 								type="checkbox" name="racial" value="Native American/Indegenous"<?php echo e($studentinfo->S2_Race == 'Native American/Indegenous' ? 'checked' : ''); ?>> -->
<!-- 								Native American/Indegenous</label><br> <label class="blck"><input -->
<!-- 								type="checkbox" name="racial" value="White"<?php echo e($studentinfo->S2_Race == 'White' ? 'checked' : ''); ?>> White</label> <br> -->
<!-- 							<label class="blck"><input type="checkbox" name="racial" -->
<!-- 								value="Multiracial"<?php echo e($studentinfo->S2_Race == 'Multiracial' ? 'checked' : ''); ?>> Multiracial</label> <?php $__errorArgs = ['racial'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> -->
<!-- 							<p class="text-danger"><?php echo e($message); ?></p> -->
<!-- 							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> -->
<!-- 						</div> -->

						<div class="ethinicity ">
							<span>What is your ethinicity ? If more than one separate
								ethnicities with a comma. Example: Filipino , Hawaiian , Irish ,
								Italian , Middle Eastern , Salvadorian" </span>
						</div>
						<div class="row">
							<div class="col-md-4">
								<div class="form-group">
									<input type="text" class="form-control" name='S2_ethnicity'
										value="<?php echo e($studentinfo->S2_Ethnicity); ?>" /> <?php $__errorArgs = ['S2_ethnicity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<p class="text-danger"><?php echo e('Please select a valid ethnicity'); ?></p>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

								</div>

							</div>

						</div>
						<div class="row">
							<div class="col-md-4">
								<div class="form-group">
									<label class="blck">Current School </label><select
										class="form-control" name='S2_current_school'
										value="<?php echo e($studentinfo->S2_Current_School); ?>">
										<option value="test_school">Test School</option>

									</select> <?php $__errorArgs = ['S2_current_school'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<p class="text-danger"><?php echo e('Please select a valid school'); ?></p>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

								</div>
							</div>
						</div>
					</div>
				<?php endif; ?>
				<?php if(!empty($studentinfo->S3_First_Name)): ?>
							<div class = student-3>
					<div class ="row">
					<div class ="col-md-4">
					<h4>Student 3</h4>
					</div>
					</div>
						<div class="row">
							<div class="col-md-4">
								<div class="form-group">
									<label> Legal First Name </label> <input type="text"
										class="form-control" name='S3_first_name' value="<?php echo e($studentinfo->S3_First_Name); ?>" />
									<?php $__errorArgs = ['S3_first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<p class="text-danger"><?php echo e('First name is required'); ?></p>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

								</div>
							</div>
							<div class="col-md-4">
								<div class="form-group">
									<label class="blck">Legal Middle Name </label> <input
										type="text" class="form-control" name='S3_middle_name'
										value="<?php echo e($studentinfo->S3_Middle_Name); ?>" /> <?php $__errorArgs = ['S3_middle_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<p class="text-danger"><?php echo e('Enter a valid middle name'); ?></p>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
								</div>
							</div>
							<div class="col-md-4">
								<div class="form-group">
									<label>Legal Last Name </label> <input type="text"
										class="form-control" name='S3_last_name'
										value="<?php echo e($studentinfo->S3_Last_Name); ?>" /> <?php $__errorArgs = ['S3_last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<p class="text-danger"><?php echo e('Last name is required'); ?></p>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
								</div>
							</div>

						</div>
						<div class="row">
							<div class="col-md-4">
								<div class="form-group">
									<label class="blck">Preffered First Name </label> <input
										type="text" class="form-control" name='S3_preffered_first_name'
										value="<?php echo e($studentinfo->S3_Preferred_First_Name); ?>" />
									<?php $__errorArgs = ['S3_preffered_first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<p class="text-danger"><?php echo e('Enter a valid preferred name'); ?></p>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
								</div>
							</div>
							<div class="col-md-4">
								<div class="form-group">
									<label>Date of Birth </label> <input type="date"
										class="form-control" name='S3_date_of_birth'
										value="<?php echo e($studentinfo->S3_Birthdate); ?>" name="date_of_birth" />
									<?php $__errorArgs = ['S3_date_of_birth'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<p class="text-danger"><?php echo e('A valid D.O.B is required before today'); ?></p>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
								</div>
							</div>
							<div class="col-md-4">
								<div class="form-group">
									<label>Gender </label> <select class="form-control"
										name='S3_gender'>
										<option value="male" <?php echo e($studentinfo->S3_Gender == 'male' ? 'selected' : ''); ?>>Male</option>
										<option value="female" <?php echo e($studentinfo->S3_Gender == 'female' ? 'selected' : ''); ?>>Female</option>

									</select> <?php $__errorArgs = ['S3_gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<p class="text-danger"><?php echo e('Gender is required'); ?></p>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
								</div>
							</div>

						</div>
						<div class="row">
							<div class="col-md-4">
								<div class="form-group">
									<label>Student's Mobile Phone Number </label> <input type="tel"
										class="form-control" name='S3_student_phone_number'
										value="<?php echo e($studentinfo->S3_Mobile_Phone); ?>" />
									<?php $__errorArgs = ['S3_student_phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<p class="text-danger"><?php echo e('Enter a valid mobile number'); ?></p>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
								</div>
							</div>
							<div class="col-md-4">
								<div class="form-group">
									<label>T-Shirt Size(Adult/Unisex) </label> 
									<select class="form-control" name='S3_tshirt_size'>
										<option value="small" <?php echo e($studentinfo->s3_tshirt_size == 'small' ? 'selected' : ''); ?>>Small</option>
										<option value="medium" <?php echo e($studentinfo->s3_tshirt_size == 'medium' ? 'selected' : ''); ?>>Medium</option>
										<option value="large" <?php echo e($studentinfo->s3_tshirt_size == 'large' ? 'selected' : ''); ?>>Large</option>
									</select> <?php $__errorArgs = ['S3_tshirt_size'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<p class="text-danger"><?php echo e('Please select a T-shirt size'); ?></p>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
								</div>
							</div>

						</div>

						<div class="row">
							<div class="col-md-4">
								<div class="form-group">
									<label class="blck">Religion </label><select
										class="form-control" name='S3_religion'
										value="">
										<option value="hindu"<?php echo e($studentinfo->s3_religion == 'hindu' ? 'selected' : ''); ?>>Hindu</option>
										<option value="christian"<?php echo e($studentinfo->s3_religion == 'christian' ? 'selected' : ''); ?>>Christian</option>
										<option value="none"<?php echo e($studentinfo->s3_religion == 'none' ? 'selected' : ''); ?>>None</option>

									</select> <?php $__errorArgs = ['S3_religion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<p class="text-danger"><?php echo e('Please select a valid religion'); ?></p>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
								</div>
							</div>


						</div>
						<div class="multiracial mb-3">
							<span>How do you identify racially ? If more than one select separate
								races with a comma. Example: White, Black , Race x,
								Race y, Race z"<br>
								
							</span>
						</div>
						
						<div class="row">
							<div class="col-md-4">
								<div class="form-group">
									<input type="text" class="form-control" name='S3_racial'
										value="<?php echo e($studentinfo->S3_Race); ?>" /> <?php $__errorArgs = ['S3_racial'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<p class="text-danger"><?php echo e('Please select a valid race'); ?></p>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

								</div>

							</div>

						</div>
						
<!-- 						<div class="form-group"> -->
<!-- 							<label class="blck"><input type="checkbox" name="racial" -->
<!-- 								value="Asian"<?php echo e($studentinfo->S3_Race == 'Asian' ? 'checked' : ''); ?>>Asian</label><br> <label class="blck"><input -->
<!-- 								type="checkbox" name="racial" value="Black/African American"<?php echo e($studentinfo->S3_Race == 'Black/African American' ? 'checked' : ''); ?>> -->
<!-- 								Black/African American</label><br> <label class="blck"><input -->
<!-- 								type="checkbox" name="racial" value="Native American/Indegenous"<?php echo e($studentinfo->S3_Race == 'Native American/Indegenous' ? 'checked' : ''); ?>> -->
<!-- 								Native American/Indegenous</label><br> <label class="blck"><input -->
<!-- 								type="checkbox" name="racial" value="White"<?php echo e($studentinfo->S3_Race == 'White' ? 'checked' : ''); ?>> White</label> <br> -->
<!-- 							<label class="blck"><input type="checkbox" name="racial" -->
<!-- 								value="Multiracial"<?php echo e($studentinfo->S3_Race == 'Multiracial' ? 'checked' : ''); ?>> Multiracial</label> <?php $__errorArgs = ['racial'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> -->
<!-- 							<p class="text-danger"><?php echo e($message); ?></p> -->
<!-- 							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> -->
<!-- 						</div> -->

						<div class="ethinicity ">
							<span>What is your ethinicity ? If more than one separate
								ethnicities with a comma. Example: Filipino , Hawaiian , Irish ,
								Italian , Middle Eastern , Salvadorian" </span>
						</div>
						<div class="row">
							<div class="col-md-4">
								<div class="form-group">
									<input type="text" class="form-control" name='S3_ethnicity'
										value="<?php echo e($studentinfo->S3_Ethnicity); ?>" /> <?php $__errorArgs = ['S3_ethnicity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<p class="text-danger"><?php echo e('Please select a valid ethnicity'); ?></p>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

								</div>

							</div>

						</div>
						<div class="row">
							<div class="col-md-4">
								<div class="form-group">
									<label class="blck">Current School </label><select
										class="form-control" name='S3_current_school'
										value="<?php echo e($studentinfo->S3_Current_School); ?>">
										<option value="test_school">Test School</option>

									</select> <?php $__errorArgs = ['S3_current_school'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<p class="text-danger"><?php echo e('Please select a valid school'); ?></p>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

								</div>
							</div>
						</div>
					</div>
				<?php endif; ?>
					</div>
				</div>
			</div>

		</div>
		<div class="form-btn text-end mt">
			<button type="submit" value="Next" class="sub-btn" >Next/Save</button>
		</div>

	</div>
</form>
<?php $__env->stopSection(); ?> <?php $__env->startPush('js'); ?> <?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.frontend-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/admission-portal-web-1854/resources/views/frontend/registeration/registeration-one.blade.php ENDPATH**/ ?>