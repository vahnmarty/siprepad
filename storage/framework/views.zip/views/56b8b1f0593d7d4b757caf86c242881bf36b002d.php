<?php if (isset($component)) { $__componentOriginal7ce8c80d39dcae62541d83a1651a8e66b3a7b908 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Layouts\AdminLayout::class, ['title' => 'Dashboard']); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('subHeader', null, []); ?> 
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.admin.sub-header','data' => ['headerTitle' => 'Dashboard']]); ?>
<?php $component->withName('admin.sub-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['headerTitle' => 'Dashboard']); ?>
            
             <?php $__env->slot('toolbar', null, []); ?> 
             <?php $__env->endSlot(); ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
     <?php $__env->endSlot(); ?>
    <div class="kt-portlet">
        <div class="kt-portlet__body  kt-portlet__body--fit">
            <div class="row row-no-padding row-col-separator-xl">
                <div class="col-md-6 col-lg-4">
                    <div class="kt-widget24">
                        <div class="kt-widget24__details">
                            <div class="kt-widget24__info">
                                <h4 class="kt-widget24__title">
                                    Total Applications
                                </h4>
                                
                            </div>
                            <span class="kt-widget24__stats kt-font-danger">
                                <?php echo e($count['applicationCount']); ?>

                            </span>
                        </div>
                        <div class="progress progress--sm">
                            <div class="progress-bar kt-bg-danger" role="progressbar"
                                style="width: <?php echo e($count['applicationCount']); ?>%;" aria-valuenow="50" aria-valuemin="0"
                                aria-valuemax="100"></div>
                        </div>
                        <div class="kt-widget24__action">
                            <a class="kt-widget24__change" href="<?php echo e(route('application.index')); ?>">
                                View
                            </a>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="kt-widget24">
                        <div class="kt-widget24__details">
                            <div class="kt-widget24__info">
                                <h4 class="kt-widget24__title">
                                     Applications Accepted
                                </h4>
                            
                            </div>
                            <span class="kt-widget24__stats kt-font-danger">
                                <?php echo e($count['applicationCount']); ?>

                            </span>
                        </div>
                        <div class="progress progress--sm">
                            <div class="progress-bar kt-bg-danger" role="progressbar"
                                style="width: <?php echo e($count['applicationCount']); ?>%;" aria-valuenow="50" aria-valuemin="0"
                                aria-valuemax="100"></div>
                        </div>
                        <div class="kt-widget24__action">
                            <a class="kt-widget24__change" href="<?php echo e(route('application.index')); ?>">
                                View
                            </a>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="kt-widget24">
                        <div class="kt-widget24__details">
                            <div class="kt-widget24__info">
                                <h4 class="kt-widget24__title">
                                     Applications Rejected
                                </h4>
                              
                            </div>
                            <span class="kt-widget24__stats kt-font-danger">
                                <?php echo e($count['applicationCount']); ?>

                            </span>
                        </div>
                        <div class="progress progress--sm">
                            <div class="progress-bar kt-bg-danger" role="progressbar"
                                style="width: <?php echo e($count['applicationCount']); ?>%;" aria-valuenow="50" aria-valuemin="0"
                                aria-valuemax="100"></div>
                        </div>
                        <div class="kt-widget24__action">
                            <a class="kt-widget24__change" href="<?php echo e(route('application.index')); ?>">
                                View
                            </a>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="kt-widget24">
                        <div class="kt-widget24__details">
                            <div class="kt-widget24__info">
                                <h4 class="kt-widget24__title">
                                    Total Submitted Applications
                                </h4>
                               
                            </div>
                            <span class="kt-widget24__stats kt-font-danger">
                                <?php echo e($count['applicationCompleteCount']); ?>

                            </span>
                        </div>
                        <div class="progress progress--sm">
                            <div class="progress-bar kt-bg-danger" role="progressbar"
                                style="width: <?php echo e($count['applicationCompleteCount']); ?>%;" aria-valuenow="50"
                                aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                        <div class="kt-widget24__action">
                            <a class="kt-widget24__change" href="<?php echo e(route('application.index')); ?>">
                                View
                            </a>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="kt-widget24">
                        <div class="kt-widget24__details">
                            <div class="kt-widget24__info">
                                <h4 class="kt-widget24__title">
                                    Total Incomplete Applications
                                </h4>
                               
                            </div>
                            <span class="kt-widget24__stats kt-font-danger">
                                <?php echo e($count['applicationIncompleteCount']); ?>

                            </span>
                        </div>
                        <div class="progress progress--sm">
                            <div class="progress-bar kt-bg-danger" role="progressbar"
                                style="width: <?php echo e($count['applicationIncompleteCount']); ?>%;" aria-valuenow="50"
                                aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                        <div class="kt-widget24__action">
                            <a class="kt-widget24__change" href="<?php echo e(route('application.index')); ?>">
                                View
                            </a>
                        </div>
                    </div>
                </div>
                  <div class="col-md-6 col-lg-4">
                    <div class="kt-widget24">
                        <div class="kt-widget24__details">
                            <div class="kt-widget24__info">
                                <h4 class="kt-widget24__title">
                                     Applications Accepted
                                </h4>
                               
                            </div>
                            <span class="kt-widget24__stats kt-font-danger">
                                <?php echo e($count['applicationAcceptedCount']); ?>

                            </span>
                        </div>
                        <div class="progress progress--sm">
                            <div class="progress-bar kt-bg-danger" role="progressbar"
                                style="width: <?php echo e($count['applicationIncompleteCount']); ?>%;" aria-valuenow="50"
                                aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                        <div class="kt-widget24__action">
                            <a class="kt-widget24__change" href="<?php echo e(route('application.index')); ?>">
                                View
                            </a>
                        </div>
                    </div>
                </div>
                   <div class="col-md-6 col-lg-4">
                    <div class="kt-widget24">
                        <div class="kt-widget24__details">
                            <div class="kt-widget24__info">
                                <h4 class="kt-widget24__title">
                                     Applications Rejected
                                </h4>
                               
                            </div>
                            <span class="kt-widget24__stats kt-font-danger">
                               <?php echo e($count['applicationRejectedCount']); ?>

                            </span>
                        </div>
                        <div class="progress progress--sm">
                            <div class="progress-bar kt-bg-danger" role="progressbar"
                                style="width: <?php echo e($count['applicationIncompleteCount']); ?>%;" aria-valuenow="50"
                                aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                        <div class="kt-widget24__action">
                            <a class="kt-widget24__change" href="<?php echo e(route('application.index')); ?>">
                                View
                            </a>
                        </div>
                    </div>
                </div>
                 <div class="col-md-6 col-lg-4">
                    <div class="kt-widget24">
                        <div class="kt-widget24__details">
                            <div class="kt-widget24__info">
                                <h4 class="kt-widget24__title">
                                    Applications Read
                                </h4>
                               
                            </div>
                            <span class="kt-widget24__stats kt-font-danger">
                               <?php echo e($count['applicationReadCount']); ?>

                            </span>
                        </div>
                        <div class="progress progress--sm">
                            <div class="progress-bar kt-bg-danger" role="progressbar"
                                style="width: <?php echo e($count['applicationIncompleteCount']); ?>%;" aria-valuenow="50"
                                aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                        <div class="kt-widget24__action">
                            <a class="kt-widget24__change" href="<?php echo e(route('application.index')); ?>">
                                View
                            </a>
                        </div>
                    </div>
                </div>
                 <div class="col-md-6 col-lg-4">
                    <div class="kt-widget24">
                        <div class="kt-widget24__details">
                            <div class="kt-widget24__info">
                                <h4 class="kt-widget24__title">
                                     Applications Not Read
                                </h4>
                               
                            </div>
                            <span class="kt-widget24__stats kt-font-danger">
                               <?php echo e($count['applicationNotReadCount']); ?>

                            </span>
                        </div>
                        <div class="progress progress--sm">
                            <div class="progress-bar kt-bg-danger" role="progressbar"
                                style="width: <?php echo e($count['applicationIncompleteCount']); ?>%;" aria-valuenow="50"
                                aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                        <div class="kt-widget24__action">
                            <a class="kt-widget24__change" href="<?php echo e(route('application.index')); ?>">
                                View
                            </a>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="kt-widget24">
                        <div class="kt-widget24__details">
                            <div class="kt-widget24__info">
                                <h4 class="kt-widget24__title">
                                    Total Users
                                </h4>
                                
                            </div>
                            <span class="kt-widget24__stats kt-font-brand">
                                <?php echo e($count['userCount']); ?>

                            </span>
                        </div>
                        <div class="progress progress--sm">
                            <div class="progress-bar kt-bg-brand" role="progressbar"
                                style="width: <?php echo e($count['userCount']); ?>%;" aria-valuenow="50" aria-valuemin="0"
                                aria-valuemax="100"></div>
                        </div>
                        <div class="kt-widget24__action">
                            <a class="kt-widget24__change" href="<?php echo e(route('users.index')); ?>">
                                View
                            </a>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="kt-widget24">
                        <div class="kt-widget24__details">
                            <div class="kt-widget24__info">
                                <h4 class="kt-widget24__title">
                                    Total Student
                                </h4>
                                
                            </div>
                            <span class="kt-widget24__stats kt-font-warning">
                                <?php echo e($count['studentCount']); ?>

                            </span>
                        </div>
                        <div class="progress progress--sm">
                            <div class="progress-bar kt-bg-warning" role="progressbar"
                                style="width: <?php echo e($count['studentCount']); ?>%;" aria-valuenow="50" aria-valuemin="0"
                                aria-valuemax="100"></div>
                        </div>
                        <div class="kt-widget24__action">
                            <a class="kt-widget24__change" href="<?php echo e(route('application.index')); ?>">
                                View
                            </a>
                        </div>
                    </div>
                </div>
                
                
            </div>
        </div>
    </div>

    

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7ce8c80d39dcae62541d83a1651a8e66b3a7b908)): ?>
<?php $component = $__componentOriginal7ce8c80d39dcae62541d83a1651a8e66b3a7b908; ?>
<?php unset($__componentOriginal7ce8c80d39dcae62541d83a1651a8e66b3a7b908); ?>
<?php endif; ?>
<?php /**PATH /var/www/html/admission-portal-web-1854/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>