
<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.admin.table','data' => []]); ?>
<?php $component->withName('admin.table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
 
    <?php $__env->slot('perPage', null, []); ?> 
        <label>Show
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.admin.dropdown','data' => ['wire:model' => 'perPage','class' => 'custom-select custom-select-sm form-control form-control-sm']]); ?>
<?php $component->withName('admin.dropdown'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:model' => 'perPage','class' => 'custom-select custom-select-sm form-control form-control-sm']); ?>
                <?php $__currentLoopData = $perPageList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.admin.dropdown-item','data' => ['value' => $page['value'],'text' => $page['text']]]); ?>
<?php $component->withName('admin.dropdown-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($page['value']),'text' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($page['text'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?> entries
        </label>
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('thead', null, []); ?> 
        <tr role="row">
            <th class="align-center" tabindex="0" aria-controls="kt_table_1" rowspan="1" colspan="1"
                style="width: 20%;" aria-sort="ascending" aria-label="Agent: activate to sort column descending">First Name

                <i class="fa fa-fw fa-sort pull-right" style="cursor: pointer;"
                    wire:click="sortBy('Pro_First_Name')"></i>
            </th>
            <th class="align-center" tabindex="0" aria-controls="kt_table_1" rowspan="1" colspan="1"

                style="width: 20%;" aria-sort="ascending" aria-label="Agent: activate to sort column descending">Last

                Name<i class="fa fa-fw fa-sort pull-right" style="cursor: pointer;"
                    wire:click="sortBy('Pro_Last_Name')"></i>
            </th>
            <th class="align-center" tabindex="0" aria-controls="kt_table_1" rowspan="1" colspan="1"
                style="width: 15%;" aria-label="Company Email: activate to sort column ascending">Email</th>
            <th class="align-center" tabindex="0" aria-controls="kt_table_1" rowspan="1" colspan="1"
                style="width: 15%;" aria-label="Company Agent: activate to sort column ascending">Phone</th>

            
                

                
            <th class="align-center" rowspan="1" colspan="1" style="width: 20%;" aria-label="Actions">Actions</th>
        </tr>

        <tr class="filter">
            <th>
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.admin.input','data' => ['type' => 'search','wire:model.defer' => 'searchFirstName','placeholder' => '','autocomplete' => 'off','class' => 'form-control-sm form-filter']]); ?>
<?php $component->withName('admin.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['type' => 'search','wire:model.defer' => 'searchFirstName','placeholder' => '','autocomplete' => 'off','class' => 'form-control-sm form-filter']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            </th>
            <th>
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.admin.input','data' => ['type' => 'search','wire:model.defer' => 'searchLastName','placeholder' => '','autocomplete' => 'off','class' => 'form-control-sm form-filter']]); ?>
<?php $component->withName('admin.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['type' => 'search','wire:model.defer' => 'searchLastName','placeholder' => '','autocomplete' => 'off','class' => 'form-control-sm form-filter']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            </th>
            <th>
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.admin.input','data' => ['type' => 'search','wire:model.defer' => 'searchEmail','placeholder' => '','autocomplete' => 'off','class' => 'form-control-sm form-filter']]); ?>
<?php $component->withName('admin.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['type' => 'search','wire:model.defer' => 'searchEmail','placeholder' => '','autocomplete' => 'off','class' => 'form-control-sm form-filter']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            </th>
            <th>
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.admin.input','data' => ['type' => 'search','wire:model.defer' => 'searchPhone','placeholder' => '','autocomplete' => 'off','class' => 'form-control-sm form-filter']]); ?>
<?php $component->withName('admin.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['type' => 'search','wire:model.defer' => 'searchPhone','placeholder' => '','autocomplete' => 'off','class' => 'form-control-sm form-filter']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            </th>
         
            <th>
        
            
                <div class="row">
                    <div class="col-2">
                       
                    </div>
                    <div class="col-6">
                     <button class="btn btn-brand kt-btn btn-sm kt-btn--icon" wire:click="search">
                          Search
                        </button>
                        <button class="btn btn-secondary kt-btn btn-sm kt-btn--icon" wire:click="resetSearch">Reset</button>
                    </div>
                </div>
            </th>
        </tr>
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('tbody', null, []); ?> 
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr role="row" class="odd">
            	<td class="align-center"><?php echo e($user->Pro_First_Name ?? '---'); ?></td>

                <td class="align-center"><?php echo e($user->Pro_Last_Name ?? '---'); ?></td>

                <td class="align-center"><a class="kt-link" href="mailto:adingate15@furl.net"><?php echo e($user->email); ?></a>
                </td>
                <td class="align-center"><?php echo e($user->Pro_Mobile ?? '---'); ?></td>
                <?php
                    $getApplication = App\Models\Application::where('Profile_ID', $user->id)->first();
                ?>
                <?php if($getApplication): ?>
                    <td>
                        <div class="action__btn">
                            <a class="btn"
                                href="<?php echo e(route('application.show', ['application' => $getApplication->Application_ID])); ?>">
                                <i class="la la-eye"></i>
                                <?php if($getApplication->status == 1): ?>
                                    View Submitted Application.
                                <?php else: ?>
                                    View Incomplete Application.
                                <?php endif; ?>
                            </a>
                        </div>
                    </td>
                <?php else: ?>
                    <td>No Application Found</td>
                <?php endif; ?>
            </tr>
      
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       
       
     <?php $__env->endSlot(); ?>
    <?php $__env->slot('pagination', null, []); ?> 
        	 <?php echo e($users->links()); ?>

    	 <?php $__env->endSlot(); ?>

     <?php $__env->slot('showingEntries', null, []); ?> 
        Showing <?php echo e($users->firstitem() ?? 0); ?> to <?php echo e($users->lastitem() ?? 0); ?> of
        <?php echo e($users->total()); ?>

        entries
     <?php $__env->endSlot(); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php /**PATH /var/www/html/admission-portal-web-1854/resources/views/livewire/admin/user-list.blade.php ENDPATH**/ ?>