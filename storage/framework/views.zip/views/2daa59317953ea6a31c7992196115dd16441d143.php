<?php $attributes = $attributes->exceptProps(['headerTitle']); ?>
<?php foreach (array_filter((['headerTitle']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<!-- begin:: Subheader -->
<div class="kt-subheader kt-grid__item" id="kt_subheader">
    <div class="kt-subheader__main">
    <h3 class="kt-subheader__title">
    <?php echo e($headerTitle); ?> </h3>
    <?php echo e($slot); ?>

    <span class="kt-subheader__separator kt-hidden"></span>
    
    </div>
    <div class="kt-subheader__toolbar">
        <div class="kt-subheader__wrapper">
            <div class="dropdown dropdown-inline" data-toggle="kt-tooltip"  data-placement="left">
                    <?php echo e($toolbar); ?>

            </div>
        </div>
    </div>
</div>
<!-- end:: Subheader --><?php /**PATH /var/www/html/admission-portal-web-1854/resources/views/components/admin/sub-header.blade.php ENDPATH**/ ?>