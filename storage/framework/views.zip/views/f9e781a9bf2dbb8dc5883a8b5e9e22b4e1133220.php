<?php $__env->startPush('css'); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('frontend.registeration.registeration-five', ['regId' => $reg_id,'reg_id' => $reg_id])->html();
} elseif ($_instance->childHasBeenRendered('ZlEahJu')) {
    $componentId = $_instance->getRenderedChildComponentId('ZlEahJu');
    $componentTag = $_instance->getRenderedChildComponentTagName('ZlEahJu');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ZlEahJu');
} else {
    $response = \Livewire\Livewire::mount('frontend.registeration.registeration-five', ['regId' => $reg_id,'reg_id' => $reg_id]);
    $html = $response->html();
    $_instance->logRenderedChild('ZlEahJu', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.frontend-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/admission-portal-web-1854/resources/views/frontend/registeration/registeration-five.blade.php ENDPATH**/ ?>