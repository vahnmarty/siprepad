<div>
    <form wire:submit.prevent="saveOrUpdate">
        <div class="home-wrap hme-wrp2">
            <div class="progress-outr">
                <ul class="progress-ul">
                    <li class="step-complete">
                        <?php if($studentInfo): ?>
                            <a href="<?php echo e(route('admission-application', ['step' => 'one'])); ?>">
                                <span>1</span>
                                <h6>Student Info</h6>
                            </a>
                        <?php else: ?>
                            <a href="javascript::void(0)">
                                <span>1</span>
                                <h6>Student Info</h6>
                            </a>
                        <?php endif; ?>
                    </li>
                    <li class="step-complete">
                        <?php if($studentInfo): ?>
                            <a href="<?php echo e(route('admission-application', ['step' => 'two'])); ?>">
                                <span>2</span>
                                <h6>Address Info</h6>
                            </a>
                        <?php else: ?>
                            <a href="javascript::void(0)">
                                <span>2</span>
                                <h6>Address Info</h6>
                            </a>
                        <?php endif; ?>
                    </li>
                    <li>
                        <?php if($studentInfo): ?>
                            <a href="<?php echo e(route('admission-application', ['step' => 'three'])); ?>">
                                <span>3</span>
                                <h6>Parent Info</h6>
                            </a>
                        <?php else: ?>
                            <a href="javascript::void(0)">
                                <span>3</span>
                                <h6>Parent Info</h6>
                            </a>
                        <?php endif; ?>
                    </li>
                    <li>
                        <?php if($studentInfo): ?>
                            <a href="<?php echo e(route('admission-application', ['step' => 'four'])); ?>">
                                <span>4</span>
                                <h6>Sibling Info</h6>
                            </a>
                        <?php else: ?>
                            <a href="javascript::void(0)">
                                <span>4</span>
                                <h6>Sibling Info</h6>
                            </a>
                        <?php endif; ?>
                    </li>
                    <li>
                        <?php if($studentInfo): ?>
                            <a href="<?php echo e(route('admission-application', ['step' => 'five'])); ?>">
                                <span>5</span>
                                <h6>Legacy Info</h6>
                            </a>
                        <?php else: ?>
                            <a href="javascript::void(0)">
                                <span>5</span>
                                <h6>Legacy Info</h6>
                            </a>
                        <?php endif; ?>
                    </li>
                    <li>
                        <?php if($studentInfo): ?>
                            <a href="<?php echo e(route('admission-application', ['step' => 'six'])); ?>">
                                <span>6</span>
                                <h6>Parent Statement</h6>
                            </a>
                        <?php else: ?>
                            <a href="javascript::void(0)">
                                <span>6</span>
                                <h6>Parent Statement</h6>
                            </a>
                        <?php endif; ?>
                    </li>
                    <li>
                        <?php if($studentInfo): ?>
                            <a href="<?php echo e(route('admission-application', ['step' => 'seven'])); ?>">
                                <span>7</span>
                                <h6>Spiritual & Community Info</h6>
                            </a>
                        <?php else: ?>
                            <a href="javascript::void(0)">
                                <span>7</span>
                                <h6>Spiritual & Community Info</h6>
                            </a>
                        <?php endif; ?>
                    </li>
                    <li>
                        <?php if($studentInfo): ?>
                            <a href="<?php echo e(route('admission-application', ['step' => 'eight'])); ?>">
                                <span>8</span>
                                <h6>Student Statement</h6>
                            </a>
                        <?php else: ?>
                            <a href="javascript::void(0)">
                                <span>8</span>
                                <h6>Student Statement</h6>
                            </a>
                        <?php endif; ?>
                    </li>
                    <li>
                        <?php if($studentInfo): ?>
                            <a href="<?php echo e(route('admission-application', ['step' => 'nine'])); ?>">
                                <span>9</span>
                                <h6>Writing Sample</h6>
                            </a>
                        <?php else: ?>
                            <a href="javascript::void(0)">
                                <span>9</span>
                                <h6>Writing Sample</h6>
                            </a>
                        <?php endif; ?>
                    </li>
                    <li>
                        <?php if($studentInfo): ?>
                            <a href="<?php echo e(route('admission-application', ['step' => 'ten'])); ?>">
                                <span>10</span>
                                <h6>Final Steps</h6>
                            </a>
                        <?php else: ?>
                            <a href="javascript::void(0)">
                                <span>10</span>
                                <h6>Final Steps</h6>
                            </a>
                        <?php endif; ?>
                    </li>
                </ul>
            </div>
            <div class="school-wrap application_step__two">
                <div class="form-outr">
                    <div class="cmn-hdr">
                        <h4>Address Info</h4>
                    </div>
                    <div class="frm-uppr">
                        <div class="direct">
                            <h5>DIRECTIONS:</h5>
                            <p>
                                <strong>This section is to be completed by a parent/guardian.
                                    Please add (up to 4) addresses associated with the
                                    student(s). Required fields are in <i class="red">red.</i><br><br>
                                Please make sure every required field is completed before saving your work. To save your work, you must click the <i class="red">Next/Save</i> button at the bottom of the page.
                                </strong>
                            </p>
                        </div>
                    </div>

                    <?php $__currentLoopData = $addressInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-wrap">
                            <div class="custom-step-two">
                                <h4>
                                    <?php if($key + 1 == 1): ?>
                                        Primary Address
                                    <?php elseif($key + 1 == 2): ?>
                                        Secondary Address
                                    <?php else: ?>
                                        Other Address <?php echo e($key - 1); ?>

                                    <?php endif; ?>
                                </h4>

                                

                                <div class="form-group">
                                    <label class="<?php echo e($key + 1 > 1 ? 'blck' : 'red'); ?>">Address:</label>
                                    <input type="text"
                                        class="form-control <?php echo e($errors->has('addressInfo.' . $key . '.Address') ? 'is-invalid' : ''); ?>"
                                        wire:model.defer='addressInfo.<?php echo e($key); ?>.Address' />
                                    <?php $__errorArgs = ['addressInfo.' . $key . '.Address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback error_text"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="form-group">
                                    <label class="<?php echo e($key + 1 > 1 ? 'blck' : 'red'); ?>">City:</label>
                                    <input type="text"
                                        class="form-control <?php echo e($errors->has('addressInfo.' . $key . '.City') ? 'is-invalid' : ''); ?>"
                                        wire:model.defer='addressInfo.<?php echo e($key); ?>.City' />
                                    <?php $__errorArgs = ['addressInfo.' . $key . '.City'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback error_text"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <?php
                                    //$getState = App\Models\State::where('country_id', $address['Country'])
                                    $getState = App\Models\State::where('country_id', 1)
                                        ->get()
                                        ->toArray();
                                ?>

                                <?php if($getState): ?>
                                    <div class="form-group">
                                        <label class="<?php echo e($key + 1 > 1 ? 'blck' : 'red'); ?>">State:</label>
                                        <select
                                            class="form-control <?php echo e($errors->has('addressInfo.' . $key . '.State') ? 'is-invalid' : ''); ?>"
                                            wire:model='addressInfo.<?php echo e($key); ?>.State'>
                                            <option value="">-- Please Choose --</option>
                                            <?php $__currentLoopData = $getState; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($state['name']); ?>"><?php echo e($state['name']); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['addressInfo.' . $key . '.State'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback error_text"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                <?php endif; ?>

                                <div class="form-group">
                                    <label class="<?php echo e($key + 1 > 1 ? 'blck' : 'red'); ?>">Zipcode:</label>
                                    <input type="text"
                                        class="form-control <?php echo e($errors->has('addressInfo.' . $key . '.Zipcode') ? 'is-invalid' : ''); ?>"
                                        wire:model.defer='addressInfo.<?php echo e($key); ?>.Zipcode'
                                        onKeyPress="if(this.value.length==11) return false;" />
                                    <?php $__errorArgs = ['addressInfo.' . $key . '.Zipcode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback error_text"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="form-group">
                                    <label class="<?php echo e($key + 1 > 1 ? 'blck' : 'red'); ?>">Primary Phone Number at
                                        Location:</label>
                                    <div class="row fr-row">
                                        <div class="col-md-3 fr-col">
                                            <input id="a<?php echo e($key); ?>" type="text" maxlength="3"
                                                class="form-control "
                                                wire:model.defer='addressInfo.<?php echo e($key); ?>.phone_number_one'
                                                oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*?)\..*/g, '$1');" />
                                        </div>
                                        <div class="col-md-3 fr-col">
                                            <input id="b<?php echo e($key); ?>" type="text" maxlength="3"
                                                class="form-control "
                                                wire:model.defer='addressInfo.<?php echo e($key); ?>.phone_number_two'
                                                oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*?)\..*/g, '$1');" />
                                        </div>
                                        <div class="col-md-6 fr-col">
                                            <input id="c<?php echo e($key); ?>" type="text" maxlength="4"
                                                class="form-control "
                                                wire:model.defer='addressInfo.<?php echo e($key); ?>.phone_number_three'
                                                oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*?)\..*/g, '$1');" />
                                        </div>
                                    </div>
                                    <?php $__errorArgs = ['addressInfo.' . $key . '.Address_Phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="error error_text"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <script>

                                        var a = document.getElementById("a<?php echo e($key); ?>"),
                                            b = document.getElementById("b<?php echo e($key); ?>"),
                                            c = document.getElementById("c<?php echo e($key); ?>");
                                            console.log(a,b,c);

                                        a.onkeyup = function() {
                                            if (this.value.length === parseInt(this.attributes["maxlength"].value)) {
                                                b.focus();
                                            }
                                        }
                                        b.onkeyup = function() {
                                            if (this.value.length === parseInt(this.attributes["maxlength"].value)) {
                                                c.focus();
                                            }
                                        }
                                    </script>
                                </div>
                                <div class="schl-btm">
                                    <div class="form_input_radio">
                                        <?php if($key < 3 && $i !== 4): ?>
                                            <button class="btn btn-danger btn-sm"
                                                wire:click.prevent="add(<?php echo e($i); ?>)">Add another
                                                address</button>
                                        <?php endif; ?>
                                        <?php if($key != 0): ?>
                                            <button class="btn btn-danger btn-sm"
                                                wire:click.prevent="remove(<?php echo e($key); ?>)">Remove
                                                address</button>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        <div class="flx">
            <div class="form-btn">
                <a href="<?php echo e(route('admission-application', ['step' => 'one'])); ?>" class="sub-btn">Previous</a>
            </div>
            <div class="form-btn">
                <button type="submit" value="Next" class="sub-btn">Next/Save</button>
            </div>
        </div>
    </form>
</div>
<?php /**PATH /var/www/html/admission-portal-web-1854/resources/views/livewire/frontend/application/application-two.blade.php ENDPATH**/ ?>