<?php $__env->startSection('title', __('page_title.home_page_title')); ?>
<?php $__env->startSection('content'); ?>
	<div class="home-wrap">
        <div class="hme-inr">
       
        	<h3 class ="mb-4">Notifications</h3>
        
        <div class = "row mb-3">
        <div class ="col-md-4">
        </div>
          <div class ="col-md-8">

          
          <?php if(!empty($application_status->s1_notification_id)): ?>
        	   <a href="<?php echo e(route('studentNotification',$application_status->s1_notification_id)); ?>" class ="btn btn-sm  btn-danger" style="font-size:33px;width:55%;" ><?php echo e(ucfirst($studentinfo->S1_First_Name) .' '. ucfirst($studentinfo->S1_Last_Name)); ?> Notification </a>

        	   <?php endif; ?>
        </div>
        </div>
            <div class = "row  mb-3">
        <div class ="col-md-4">
        </div>
          <div class ="col-md-8">
        	<?php if(!empty($application_status->s2_notification_id)): ?> 

        	  <a href="<?php echo e(route('studentNotification',$application_status->s2_notification_id)); ?>" class ="btn btn-sm  btn-danger"style="font-size:33px;width:55%;" ><?php echo e(ucfirst($studentinfo->S2_First_Name) .' '.ucfirst($studentinfo->S2_Last_Name)); ?> Notification</a>

        	  <?php endif; ?>
        </div>
        </div>
              <div class = "row  mb-3">
        <div class ="col-md-4">
        </div>
          <div class ="col-md-8">
       <?php if(!empty($application_status->s3_notification_id)): ?>

        	   <a href="<?php echo e(route('studentNotification',$application_status->s3_notification_id)); ?>" class ="btn btn-sm btn-danger"style="font-size:33px;width:55%;" ><?php echo e(ucfirst($studentinfo->S3_First_Name) .' '. ucfirst($studentinfo->S3_Last_Name)); ?> Notification</a>

        <?php endif; ?>
        </div>
        </div> 
        
      
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/admission-portal-web-1854/resources/views/frontend/notification_list.blade.php ENDPATH**/ ?>