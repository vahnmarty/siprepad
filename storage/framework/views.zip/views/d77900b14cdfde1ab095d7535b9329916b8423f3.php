<?php $__env->startPush('css'); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('householdUpdate',['id' => $parentinfo->Profile_ID])); ?>" method="POST">
<?php echo csrf_field(); ?>
	<div class="home-wrap hme-wrp2">
		<div class="progress-outr"></div>
		
			<div class="form-outr">


				<div class="school-wrap step__one">
					<div class="form-wrap">
						<div class="form-wrap">

							<div class="cmn-hdr">
								<h4 class="text-center" style="font-size: 25px">Household
									Information</h4>
							</div>
							<div class="row">
								<div class="col-lg-2"></div>
								<div class="col-lg-9">
									<div class="form-group">
										<label>Street</label> <input type="text" value="<?php echo e($addressinfo->Address_1); ?>" class="form-control"
											name='A1_street' /> <?php $__errorArgs = ['A1_street'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
										<p class="text-danger"><?php echo e('The street field is required.'); ?></p>
										<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
									</div>
								</div>
							</div>
							<div class="row">

								<div class="col-lg-2"></div>
								<div class="col-lg-9">
									<div class="form-group">
										<label>City</label> <input type="text" value="<?php echo e($addressinfo->City_1); ?>" class="form-control"
											name='A1_city' /> <?php $__errorArgs = ['A1_city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
										<p class="text-danger"><?php echo e('The city field is required.'); ?></p>
										<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-lg-2"></div>
								<div class="col-lg-9">
									<div class="form-group">
										<label>State</label> <input type="text" value="<?php echo e($addressinfo->State_1); ?>" class="form-control"
											name='A1_state' /> <?php $__errorArgs = ['A1_state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
										<p class="text-danger"><?php echo e('The state field is required.'); ?></p>
										<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-lg-2"></div>
								<div class="col-lg-9">
									<div class="form-group">
										<label>Zip Code</label> <input type="number"  value="<?php echo e($addressinfo->Zipcode_1); ?>"
											class="form-control" name='A1_zip_code' />
										<?php $__errorArgs = ['A1_zip_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
										<p class="text-danger"><?php echo e('The zip code field is required.'); ?></p>
										<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-lg-2"></div>
								<div class="col-lg-9">
									<div class="form-group">
										<label>Home Phone</label> <input type="number"
											class="form-control" name='A1_home_phone'  value="<?php echo e($addressinfo->Address_Phone_1); ?>" />
										<?php $__errorArgs = ['A1_home_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
										<p class="text-danger"><?php echo e('The home phone should not be greater than 10 digits'); ?></p>
										<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
									</div>
								</div>
							</div>
			

							<div class="cmn-hdr">
								<h4 class="text-center" style="font-size: 22px">Household 1 -
									Parent/Guardian 1</h4>
							</div>
							
							<div class="form-wrap">
								<div class="row">
									<div class="col-lg-2"></div>
									<div class="col-lg-9">
										<div class="form-group">
											<label class="blck">Relationship to Applicant</label> <select
												class="form-control" name='P1_relation_to_applicant'>
												<option selected disabled>-- Please Choose --</option>

												<option value="Father" <?php echo e($parentinfo->P1_Relationship == 'Father' ? 'selected' : ''); ?>>Father</option>
												<option value="Mother" <?php echo e($parentinfo->P1_Relationship == 'Mother' ? 'selected' : ''); ?>>Mother</option>
												<option value="Stepmother" <?php echo e($parentinfo->P1_Relationship == 'Stepmother' ? 'selected' : ''); ?>>Stepmother</option>
												<option value="Stepfather" <?php echo e($parentinfo->P1_Relationship == 'Stepfather' ? 'selected' : ''); ?>>Stepfather</option>
												<option value="Guardians" <?php echo e($parentinfo->P1_Relationship == 'Guardians' ? 'selected' : ''); ?>>Guardians</option>
											</select> <?php $__errorArgs = ['P1_relation_to_applicant'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<p class="text-danger"><?php echo e($message); ?></p>
											<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
										</div>
									</div>
								</div>
								
								<div class="row">
									<div class="col-lg-2"></div>
									<div class="col-lg-9">
										<div class="form-group">
											<label class="blck">Prefix</label> <select
												class="form-control" name='P1_prefix'>
												<option selected disabled>-- Please Choose --</option>

												<option value="Jr." <?php echo e($parentinfo->P1_Salutation == 'Jr.' ? 'selected' : ''); ?>>Jr.</option>
												<option value="Sr." <?php echo e($parentinfo->P1_Salutation == 'Sr.' ? 'selected' : ''); ?>>Sr.</option>
												<option value="Hon." <?php echo e($parentinfo->P1_Salutation == 'Hon.' ? 'selected' : ''); ?>>Hon.</option>
											</select> <?php $__errorArgs = ['P1_prefix'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<p class="text-danger"><?php echo e($message); ?></p>
											<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
										</div>
									</div>
								</div>
								
								<div class="row">
									<div class="col-lg-2"></div>
									<div class="col-lg-9">
										<div class="form-group">
											<label class="blck">First Name</label> <input type="text"
												class="form-control" name='P1_parent_first_name' value="<?php echo e($parentinfo->P1_First_Name); ?>"/>
											<?php $__errorArgs = ['P1_parent_first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<p class="text-danger"><?php echo e('The first name field is required.'); ?></p>
											<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-2"></div>
									<div class="col-lg-9">
										<div class="form-group">
											<label class="blck">Middle Name</label> <input type="text"
												class="form-control" name='P1_parent_middle_name' value="<?php echo e($parentinfo->P1_Middle_Name); ?>"/>
											<?php $__errorArgs = ['P1_parent_middle_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<p class="text-danger"><?php echo e($message); ?></p>
											<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-2"></div>
									<div class="col-lg-9">
										<div class="form-group">
											<label class="blck">Last Name</label> <input type="text" value="<?php echo e($parentinfo->P1_Last_Name); ?>"
												class="form-control" name='P1_parent_last_name' />
											<?php $__errorArgs = ['P1_parent_last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<p class="text-danger"><?php echo e($message); ?></p>
											<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-2"></div>
									<div class="col-lg-9">
										<div class="form-group">
											<label class="blck">Cell Phone</label> <input type="tel"
												class="form-control" name='P1_parent_cell_phone' value="<?php echo e($parentinfo->P1_Mobile_Phone); ?>" />
											<?php $__errorArgs = ['P1_parent_cell_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<p class="text-danger"><?php echo e('A valid cell phone number of 10 digits is required.'); ?></p>
											<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-2"></div>
									<div class="col-lg-9">
										<div class="form-group">
											<label class="blck">Email Address</label> <input type="email"
												class="form-control" name='P1_parent_email' value="<?php echo e($parentinfo->P1_Personal_Email); ?>" />
											<?php $__errorArgs = ['P1_parent_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<p class="text-danger"><?php echo e('A valid email is required.'); ?></p>
											<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-2"></div>
									<div class="col-lg-9">
										<div class="form-group">
											<label class="blck">Employer</label> <input type="employer"
												class="form-control" name='P1_parent_employer' value="<?php echo e($parentinfo->P1_Employer); ?>" />
											<?php $__errorArgs = ['P1_parent_employer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<p class="text-danger"><?php echo e($message); ?></p>
											<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-2"></div>
									<div class="col-lg-9">
										<div class="form-group">
											<label class="blck">Position/Title</label> <input
												type="parent_position" class="form-control"
												name="P1_parent_position" value="<?php echo e($parentinfo->P1_Title); ?>" /> <?php $__errorArgs = ['P1_parent_position'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<p class="text-danger"><?php echo e($message); ?></p>
											<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-2"></div>
									<div class="col-lg-9">
										<div class="form-group">
											<label class="blck">Work Phone</label> <input type="tel"
												class="form-control" name='p1_parent_work_phone' value="<?php echo e($parentinfo->P1_Work_Phone); ?>" />
											<?php $__errorArgs = ['p1_parent_work_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<p class="text-danger"><?php echo e($message); ?></p>
											<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-2"></div>
									<div class="col-lg-9">
										<div class="form-group">
											<label class="blck">School/Colleges Attended</label>
											<textarea rows="25" cols="10" name="P1_parent_school"><?php echo e($parentinfo->P1_Schools); ?></textarea>
											<?php $__errorArgs = ['P1_parent_schools'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<p class="text-danger"><?php echo e($message); ?></p>
											<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
										</div>
									</div>
								</div>
							</div>
							
							<?php if($parentinfo->P2_First_Name): ?>
							
							<div class="cmn-hdr">
								<h4 class="text-center" style="font-size: 22px">Household 1 -
									Parent/Guardian 2</h4>
							</div>
							
							<div class="form-wrap">
								<div class="row">
									<div class="col-lg-2"></div>
									<div class="col-lg-9">
										<div class="form-group">
											<label class="blck">Relationship to Applicant</label> <select
												class="form-control" name='P2_relation_to_applicant'>
												<option selected disabled>-- Please Choose --</option>

												<option value="Father" <?php echo e($parentinfo->P2_Relationship == 'Father' ? 'selected' : ''); ?>>Father</option>
												<option value="Mother" <?php echo e($parentinfo->P2_Relationship == 'Mother' ? 'selected' : ''); ?>>Mother</option>
												<option value="Stepmother" <?php echo e($parentinfo->P2_Relationship == 'Stepmother' ? 'selected' : ''); ?>>Stepmother</option>
												<option value=Stepfather" <?php echo e($parentinfo->P2_Relationship == 'Stepfather' ? 'selected' : ''); ?>>Stepfather</option>
												<option value="Guardians" <?php echo e($parentinfo->P2_Relationship == 'Guardians' ? 'selected' : ''); ?>>Guardians</option>
											</select> <?php $__errorArgs = ['P2_relation_to_applicant'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<p class="text-danger"><?php echo e($message); ?></p>
											<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
										</div>
									</div>
								</div>
								
								<div class="row">
									<div class="col-lg-2"></div>
									<div class="col-lg-9">
										<div class="form-group">
											<label class="blck">Prefix</label> <select
												class="form-control" name='P2_prefix'>
												<option selected disabled>-- Please Choose --</option>

												<option value="Jr." <?php echo e($parentinfo->P2_Salutation == 'Jr.' ? 'selected' : ''); ?>>Jr.</option>
												<option value="Sr." <?php echo e($parentinfo->P2_Salutation == 'Sr.' ? 'selected' : ''); ?>>Sr.</option>
												<option value="Hon." <?php echo e($parentinfo->P2_Salutation == 'Hon.' ? 'selected' : ''); ?>>Hon.</option>
											</select> <?php $__errorArgs = ['P2_prefix'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<p class="text-danger"><?php echo e($message); ?></p>
											<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
										</div>
									</div>
								</div>
								
								<div class="row">
									<div class="col-lg-2"></div>
									<div class="col-lg-9">
										<div class="form-group">
											<label class="blck">First Name</label> <input type="text"
												class="form-control" name='P2_parent_first_name' value="<?php echo e($parentinfo->P2_First_Name); ?>"/>
											<?php $__errorArgs = ['P2_parent_first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<p class="text-danger"><?php echo e($message); ?></p>
											<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-2"></div>
									<div class="col-lg-9">
										<div class="form-group">
											<label class="blck">Middle Name</label> <input type="text"
												class="form-control" name='P2_parent_middle_name' value="<?php echo e($parentinfo->P2_Middle_Name); ?>"/>
											<?php $__errorArgs = ['P2_parent_middle_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<p class="text-danger"><?php echo e($message); ?></p>
											<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-2"></div>
									<div class="col-lg-9">
										<div class="form-group">
											<label class="blck">Last Name</label> <input type="text" value="<?php echo e($parentinfo->P2_Last_Name); ?>"
												class="form-control" name='P2_parent_last_name' />
											<?php $__errorArgs = ['P2_parent_last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<p class="text-danger"><?php echo e($message); ?></p>
											<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-2"></div>
									<div class="col-lg-9">
										<div class="form-group">
											<label class="blck">Cell Phone</label> <input type="tel"
												class="form-control" name='P2_parent_cell_phone' value="<?php echo e($parentinfo->P2_Mobile_Phone); ?>" />
											<?php $__errorArgs = ['P2_parent_cell_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<p class="text-danger"><?php echo e($message); ?></p>
											<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-2"></div>
									<div class="col-lg-9">
										<div class="form-group">
											<label class="blck">Email Address</label> <input type="email"
												class="form-control" name='P2_parent_email' value="<?php echo e($parentinfo->P2_Personal_Email); ?>" />
											<?php $__errorArgs = ['P2_parent_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<p class="text-danger"><?php echo e($message); ?></p>
											<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-2"></div>
									<div class="col-lg-9">
										<div class="form-group">
											<label class="blck">Employer</label> <input type="employer"
												class="form-control" name='P2_parent_employer' value="<?php echo e($parentinfo->P2_Employer); ?>" />
											<?php $__errorArgs = ['P1_parent_employer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<p class="text-danger"><?php echo e($message); ?></p>
											<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-2"></div>
									<div class="col-lg-9">
										<div class="form-group">
											<label class="blck">Position/Title</label> <input
												type="parent_position" class="form-control"
												name="P2_parent_position" value="<?php echo e($parentinfo->P2_Title); ?>" /> <?php $__errorArgs = ['P2_parent_position'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<p class="text-danger"><?php echo e($message); ?></p>
											<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-2"></div>
									<div class="col-lg-9">
										<div class="form-group">
											<label class="blck">Work Phone</label> <input type="tel"
												class="form-control" name='p2_parent_work_phone' value="<?php echo e($parentinfo->P2_Work_Phone); ?>" />
											<?php $__errorArgs = ['p2_parent_work_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<p class="text-danger"><?php echo e($message); ?></p>
											<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-2"></div>
									<div class="col-lg-9">
										<div class="form-group">
											<label class="blck">School/Colleges Attended</label>
											<textarea rows="25" cols="10" name="P2_parent_school"><?php echo e($parentinfo->P2_Schools); ?></textarea>
											<?php $__errorArgs = ['P2_parent_schools'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<p class="text-danger"><?php echo e($message); ?></p>
											<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
										</div>
									</div>
								</div>
							</div>
						<?php endif; ?>
						
						
							<?php if($parentinfo->P3_First_Name): ?>
							
							<div class="cmn-hdr">
								<h4 class="text-center" style="font-size: 22px">Household 1 -
									Parent/Guardian 3</h4>
							</div>
							
							<div class="form-wrap">
								<div class="row">
									<div class="col-lg-2"></div>
									<div class="col-lg-9">
										<div class="form-group">
											<label class="blck">Relationship to Applicant</label> <select
												class="form-control" name='P3_relation_to_applicant'>
												<option selected disabled>-- Please Choose --</option>

												<option value="Father" <?php echo e($parentinfo->P3_Relationship == 'Father' ? 'selected' : ''); ?>>Father</option>
												<option value="Mother" <?php echo e($parentinfo->P3_Relationship == 'Mother' ? 'selected' : ''); ?>>Mother</option>
												<option value="Stepmother" <?php echo e($parentinfo->P3_Relationship == 'Stepmother' ? 'selected' : ''); ?>>Stepmother</option>
												<option value=Stepfather" <?php echo e($parentinfo->P3_Relationship == 'Stepfather' ? 'selected' : ''); ?>>Stepfather</option>
												<option value="Guardians" <?php echo e($parentinfo->P3_Relationship == 'Guardians' ? 'selected' : ''); ?>>Guardians</option>
											</select> <?php $__errorArgs = ['P3_relation_to_applicant'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<p class="text-danger"><?php echo e($message); ?></p>
											<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
										</div>
									</div>
								</div>
								
								<div class="row">
									<div class="col-lg-2"></div>
									<div class="col-lg-9">
										<div class="form-group">
											<label class="blck">Prefix</label> <select
												class="form-control" name='P3_prefix'>
												<option selected disabled>-- Please Choose --</option>

												<option value="Jr." <?php echo e($parentinfo->P3_Salutation == 'Jr.' ? 'selected' : ''); ?>>Jr.</option>
												<option value="Sr." <?php echo e($parentinfo->P3_Salutation == 'Sr.' ? 'selected' : ''); ?>>Sr.</option>
												<option value="Hon." <?php echo e($parentinfo->P3_Salutation == 'Hon.' ? 'selected' : ''); ?>>Hon.</option>
											</select> <?php $__errorArgs = ['P3_prefix'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<p class="text-danger"><?php echo e($message); ?></p>
											<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
										</div>
									</div>
								</div>
								
								<div class="row">
									<div class="col-lg-2"></div>
									<div class="col-lg-9">
										<div class="form-group">
											<label class="blck">First Name</label> <input type="text"
												class="form-control" name='P3_parent_first_name' value="<?php echo e($parentinfo->P3_First_Name); ?>"/>
											<?php $__errorArgs = ['P3_parent_first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<p class="text-danger"><?php echo e($message); ?></p>
											<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-2"></div>
									<div class="col-lg-9">
										<div class="form-group">
											<label class="blck">Middle Name</label> <input type="text"
												class="form-control" name='P3_parent_middle_name' value="<?php echo e($parentinfo->P3_Middle_Name); ?>"/>
											<?php $__errorArgs = ['P3_parent_middle_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<p class="text-danger"><?php echo e($message); ?></p>
											<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-2"></div>
									<div class="col-lg-9">
										<div class="form-group">
											<label class="blck">Last Name</label> <input type="text" value="<?php echo e($parentinfo->P3_Last_Name); ?>"
												class="form-control" name='P3_parent_last_name' />
											<?php $__errorArgs = ['P3_parent_last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<p class="text-danger"><?php echo e($message); ?></p>
											<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-2"></div>
									<div class="col-lg-9">
										<div class="form-group">
											<label class="blck">Cell Phone</label> <input type="tel"
												class="form-control" name='P3_parent_cell_phone' value="<?php echo e($parentinfo->P3_Mobile_Phone); ?>" />
											<?php $__errorArgs = ['P3_parent_cell_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<p class="text-danger"><?php echo e($message); ?></p>
											<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-2"></div>
									<div class="col-lg-9">
										<div class="form-group">
											<label class="blck">Email Address</label> <input type="email"
												class="form-control" name='P3_parent_email' value="<?php echo e($parentinfo->P3_Personal_Email); ?>" />
											<?php $__errorArgs = ['P3_parent_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<p class="text-danger"><?php echo e($message); ?></p>
											<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-2"></div>
									<div class="col-lg-9">
										<div class="form-group">
											<label class="blck">Employer</label> <input type="employer"
												class="form-control" name='P3_parent_employer' value="<?php echo e($parentinfo->P3_Employer); ?>" />
											<?php $__errorArgs = ['P3_parent_employer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<p class="text-danger"><?php echo e($message); ?></p>
											<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-2"></div>
									<div class="col-lg-9">
										<div class="form-group">
											<label class="blck">Position/Title</label> <input
												type="parent_position" class="form-control"
												name="P3_parent_position" value="<?php echo e($parentinfo->P3_Title); ?>" /> <?php $__errorArgs = ['P3_parent_position'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<p class="text-danger"><?php echo e($message); ?></p>
											<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-2"></div>
									<div class="col-lg-9">
										<div class="form-group">
											<label class="blck">Work Phone</label> <input type="tel"
												class="form-control" name='p3_parent_work_phone' value="<?php echo e($parentinfo->P3_Work_Phone); ?>" />
											<?php $__errorArgs = ['p3_parent_work_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<p class="text-danger"><?php echo e($message); ?></p>
											<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-2"></div>
									<div class="col-lg-9">
										<div class="form-group">
											<label class="blck">School/Colleges Attended</label>
											<textarea rows="25" cols="10" name="P3_parent_school"><?php echo e($parentinfo->P3_Schools); ?></textarea>
											<?php $__errorArgs = ['P3_parent_schools'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<p class="text-danger"><?php echo e($message); ?></p>
											<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
										</div>
									</div>
								</div>
							</div>
						<?php endif; ?>
						
						
						</div>
					</div>

				</div>
				  <div class="flx">
				<div class="form-btn text-end mt">
                <a href="<?php echo e(route('registration.create')); ?>" class="sub-btn">Previous</a>
            </div>
				<div class="form-btn text-end mt">
					<button type="submit" value="Next" class="sub-btn">Next/Save</button>
				</div>
</div>
</div>
			</div>

</form>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.frontend-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/admission-portal-web-1854/resources/views/frontend/registeration/registeration-two.blade.php ENDPATH**/ ?>