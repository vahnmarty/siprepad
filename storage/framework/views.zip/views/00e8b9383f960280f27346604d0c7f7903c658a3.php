<?php $attributes = $attributes->exceptProps(['value'=>"",'text'=>"Please select one",'selected'=>false]); ?>
<?php foreach (array_filter((['value'=>"",'text'=>"Please select one",'selected'=>false]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<option value="<?php echo e($value); ?>" selected="<?php echo e($selected); ?>" > <?php echo e($text); ?></option><?php /**PATH /var/www/html/admission-portal-web-1854/resources/views/components/admin/dropdown-item.blade.php ENDPATH**/ ?>