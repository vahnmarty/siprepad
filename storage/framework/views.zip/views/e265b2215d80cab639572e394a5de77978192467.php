    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />

<?php if (isset($component)) { $__componentOriginal7ce8c80d39dcae62541d83a1651a8e66b3a7b908 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Layouts\AdminLayout::class, ['title' => 'Application Management']); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('subHeader', null, []); ?> 
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.admin.sub-header','data' => ['headerTitle' => '']]); ?>
<?php $component->withName('admin.sub-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['headerTitle' => '']); ?>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.admin.breadcrumbs','data' => []]); ?>
<?php $component->withName('admin.breadcrumbs'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.admin.breadcrumbs-item','data' => ['href' => ''.e(route('admin.dashboard')).'','value' => 'Dashboard']]); ?>
<?php $component->withName('admin.breadcrumbs-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['href' => ''.e(route('admin.dashboard')).'','value' => 'Dashboard']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.admin.breadcrumbs-separator','data' => []]); ?>
<?php $component->withName('admin.breadcrumbs-separator'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.admin.breadcrumbs-item','data' => ['href' => ''.e(route('application.index')).'','value' => 'Applications']]); ?>
<?php $component->withName('admin.breadcrumbs-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['href' => ''.e(route('application.index')).'','value' => 'Applications']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

             <?php $__env->slot('toolbar', null, []); ?> 
                
             <?php $__env->endSlot(); ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
     <?php $__env->endSlot(); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.application.index', ['applications' => $app, 'notificationButton' => $notifications, 'register' =>$registerable])->html();
} elseif ($_instance->childHasBeenRendered('fWWSmo8')) {
    $componentId = $_instance->getRenderedChildComponentId('fWWSmo8');
    $componentTag = $_instance->getRenderedChildComponentTagName('fWWSmo8');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('fWWSmo8');
} else {
    $response = \Livewire\Livewire::mount('admin.application.index', ['applications' => $app, 'notificationButton' => $notifications, 'register' =>$registerable]);
    $html = $response->html();
    $_instance->logRenderedChild('fWWSmo8', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>;
    
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7ce8c80d39dcae62541d83a1651a8e66b3a7b908)): ?>
<?php $component = $__componentOriginal7ce8c80d39dcae62541d83a1651a8e66b3a7b908; ?>
<?php unset($__componentOriginal7ce8c80d39dcae62541d83a1651a8e66b3a7b908); ?>
<?php endif; ?>
<script>
	   $.ajaxSetup({  

        headers: {

            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')

        }

    });
	$('document').ready(function(){

	  $(".state_select-box").change(function() {
     var app_type_id = $(this).val();
     var email =$(this).prev().val();
     var dob =$(this).prev().prev().val();
     var last_name =$(this).prev().prev().prev().val();
     var first_name =$(this).prev().prev().prev().prev().val();
     var app_id =$(this).prev().prev().prev().prev().prev().val();
    var profile_id =$(this).prev().prev().prev().prev().prev().prev().val();
       
    
 $.ajax({

           type:'POST',

           url:"<?php echo e(route('statusSubmit')); ?>",

           data:{app_type_id:app_type_id, app_id:app_id,first_name:first_name,last_name:last_name,dob:dob,email:email,profile_id:profile_id},
           
           success:function(data){

              window.alert(data);

           }


        });

  });
    });


</script><?php /**PATH /var/www/html/admission-portal-web-1854/resources/views/admin/application/index.blade.php ENDPATH**/ ?>